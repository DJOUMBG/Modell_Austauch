/*ITI_FixStep.c : constant step size ODE solver*/
#include "ITI_crt.h"
#include "ITI_Declarations_pneAux_rebuild_generic_std_sf.h"
#include "ITI_FixStep_pneAux_rebuild_generic_std_sf.h"
#include "ITI_ModelInclude_pneAux_rebuild_generic_std_sf.h"
#include "ITI_big_uint.h"
#include "ITI_NonLinSolver_pneAux_rebuild_generic_std_sf.h"

static int InitModelData(ITI_FixStepData* fsd, int nParams, double* pValues);
static int InitSolverData(ITI_FixStepData* fsd);
static int FreeModelData(ITI_FixStepData* fsd);
static int FreeSolverData(ITI_FixStepData* fsd);
static void InitWorkData(ITI_FixStepData* fsd);
static void FreeWorkData(ITI_FixStepData* fsd);
static void Euphor_DoIntegration(void* pData);
static void EuphorMin_DoIntegration(void* pData);
static void ITI_FixStep_DoIntegration(void* pData);
static void ITI_FixStepMin_DoIntegration(void* pData);
static void ITI_FixStep_PostIntegration(void* pData);
static void ITI_FixStep_Reinit(void* pData);
static void Rkfh_DoIntegration(void* pData);
static void RkfhMin_DoIntegration(void* pData);
static void Rkf23_DoIntegration(void* pData);
static void Dopri5_DoIntegration(void* pData);

#define _MEMCPY

#if (defined _MSC_VER && !defined _M_X64)
#if _M_IX86_FP != 2
#define SLOW_DENORMAL
#endif
#endif

#if (defined __i386__ && !defined __x86_64__)
#define SLOW_DENORMAL
#endif

#ifdef ITI_DSPACE
#undef _x
#undef _y
#endif

#if (defined(_OPENMP) )
/* Visual Studio breaks the openmp 2.0 rules, so it need an extra treatment: */
#if (defined(_MSC_VER) )
  extern _declspec(thread) ITI_SolverInfo* g_sInfo;
  extern _declspec(thread) ITI_MemoryObject* g_currMem;
  extern _declspec(thread) ITI_real g_tStart;
#else /* not defined _MSC_VER */
  extern ITI_SolverInfo* g_sInfo;
  extern ITI_MemoryObject* g_currMem;
  extern ITI_real g_tStart;
  #pragma omp threadprivate(g_currMem)
  #pragma omp threadprivate(g_sInfo)
  #pragma omp threadprivate(g_tStart)
#endif /* defined _MSC_VER */
#else /* not defined _OPENMP */
  extern ITI_SolverInfo* g_sInfo;
  extern ITI_MemoryObject* g_currMem;
  extern ITI_real g_tStart;
#endif

/*#define _JOURNAL*/
/*#define _PERFMEA*/
/*#define _EVENTIT*/
/*#define _SAVE_STATES*/

/*#define _ROOT_MESSAGE_SCREEN*/
/*#define _ROOT_MESSAGE_FILE*/
/*#define _EVENT_STEP*/

#if defined _ROOT_MESSAGE_SCREEN || defined _ROOT_MESSAGE_FILE
double _ROOT_PROT_BEGIN[] = {0.0, 30.0, 80.0};
double _ROOT_PROT_END[] = {10.0, 40.0, 120.0};
/*
  for one interval [a,b]: set {0.0, a, 0.0} , {0.0, b, 0.0}
  for two intervals [a,b], [c,d]: set {a, c, 0.0} , {b, d, 0.0}
*/
#endif

#ifdef _EVENTIT
static FILE* eventit;
#endif

#ifdef _SAVE_STATES
FILE* states;
#include "ITI_SolverHelpers.h"
#endif

#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
#include "ITI_SolverHelpers.h"
#define CYCLES_PER_MUESEC 3200
#define size_Add 2
FILE* perfmea;

static __int64 temp_time_start;
static __int64 Measure_Cycl()
{
	unsigned int time_low, time_high;
	unsigned __int64 cycles;

	_asm{
		pushad
		cpuid
		rdtsc
		mov time_low, eax
		mov time_high, edx
		popad
		}

	cycles =(__int64)(((unsigned __int64)time_high << 32) | time_low);

	return cycles;
}
#endif

#ifdef _JOURNAL
FILE* journal;
#endif

#ifdef _ROOT_MESSAGE_FILE
FILE* roots;
#endif

/*Model info data*/
extern ITI_inputData inputs_pneAux_rebuild_generic_std_sf[];
extern ITI_outputData outputData_pneAux_rebuild_generic_std_sf[];
extern ITI_parameterData parameters_pneAux_rebuild_generic_std_sf[];
/*
extern ITI_CurveSetData curveSets_pneAux_rebuild_generic_std_sf[];
extern ITI_CurveData_ND curveNDs_pneAux_rebuild_generic_std_sf[];
extern ITI_BlockSizes blockSizes_pneAux_rebuild_generic_std_sf[];
extern ITI_uint seqCsSizes_pneAux_rebuild_generic_std_sf[];
extern ITI_VarAttributes stateAttributes_pneAux_rebuild_generic_std_sf[];
extern ITI_DelayInfo delayInfos_pneAux_rebuild_generic_std_sf[];
extern ITI_int numJacColsData_pneAux_rebuild_generic_std_sf[];
extern ITI_uint DPBlockSizes_pneAux_rebuild_generic_std_sf[];
extern ITI_zerofunctionData dataZF_pneAux_rebuild_generic_std_sf[];
extern ITI_ArrayData arrayData_pneAux_rebuild_generic_std_sf[];
*/
static ITI_uint CheckMinMax(ITI_SimVar *sv);

#if !defined ITI_DSPACE && !defined ITI_NI_RT && !defined ITI_SCALERT && !defined ITI_SFuncSolver && !defined ITI_CE_ETAS_LABCAR && !defined ITI_FMI_CS && !defined ITI_FMI_CS2

#include "ITI_SolverHelpers.h"

int ITI_FixStep(ITI_SolverSettings* settings, int nParams, double* pValues, int iVariation, SetInputsFunc SetInputs, char *outputFileName)
{
	void* pData;
	ITI_real t;
	FILE *outputs = NULL;
	ITI_int iPlaces = 15;
	clock_t cLast = clock();
	int iRet = 0;

	fprintf(stdout, "\nInitializing Solver...\n");

	#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
	/*initialization of cycle counter*/
	temp_time_start = Measure_Cycl();
	#endif

	if (settings)
		g_tStart = settings->tStart;

	if (CreateSolverInstance(&pData, nParams, pValues))
	{
		int ret;
		char fOutputs[FILENAME_MAX];
		if (settings->saveMode == SaveOutputsAll){
			/*calc number of decimal places for dtMin*/
			iPlaces = GetNumberOfDecimalPlaces(settings->dtMin);
			settings->dtProtMin = settings->dtMin;
		}
		else {
			/*calc number of decimal places for dtProtMin*/
			iPlaces = GetNumberOfDecimalPlaces(settings->dtProtMin);
		}

		/*prepare result file*/
		GetOutputFileName(fOutputs, outputFileName, iVariation);
		outputs = fopen(fOutputs, "w+");

		/*write file header*/
		WriteOutputStreamHeader(outputs, &outputData_pneAux_rebuild_generic_std_sf[0], GetSizeY(pData));

		SetSolverSettings(pData, settings);

		if (SetInputs)
			SetInputs(Get_Comp_u(pData), settings->tStart);

		ret = InitializeModel(pData);
		if (ret == _STATE_SUCCESS_CONTINUE) {
			ret = InitializeConditionsModelOnly(pData);
			if (ret == _STATE_SUCCESS_CONTINUE) {
				if (settings->saveMode == SaveOutputsAtleastwithdtProtPrePostEvents)
					WriteOutput2Stream(outputs, outputData_pneAux_rebuild_generic_std_sf, &(((ITI_FixStepData*)pData)->pData), GetSizeY(pData), iPlaces, 15);
				ret = InitializeConditionsModelFinish(pData);
			}
		}

		t = Get_t(pData);
		if (ret == _STATE_SUCCESS_CONTINUE)
		{
			fprintf(stdout, "\nRunning...\n");
			ShowActTime(&cLast, t, settings->tStop, 1);
			do
			{
				if (SetInputs)
					SetInputs(Get_Comp_u(pData), Get_t(pData));

				CalcOneStep(pData);

				if (Get_ErrorState(pData))
					iRet = -1;
				HandleTrace(&((ITI_FixStepData*)pData)->pData.sInfo);

				/*the internal time is set automatically*/
				t=Get_t(pData);

				/*Now you can access to the result array by
				Get_y(pData);
				*/
				/*Check if anything happened*/
				if (Get_TerminateState(pData)==1)
				{
					HandleWarnings(&((ITI_FixStepData*)pData)->pData.sInfo);
					fprintf(stdout, "\n\nSimulation run canceled at t = %.15f s\n\n", t);
					break;
				}
				if((settings->saveMode != SaveOutputsLastValue)&&(t<settings->tStop))
				{
					WriteOutput2Stream(outputs, outputData_pneAux_rebuild_generic_std_sf, &(((ITI_FixStepData*)pData)->pData),GetSizeY(pData), iPlaces, 15);
				}
				ShowActTime(&cLast, t, settings->tStop, 0);
			}
			while(t<settings->tStop); /*H08971*/
		} else
			iRet = -1;
	} else {
		iRet = -1;
		t = settings->tStart;
	}

	ShowActTime(&cLast, t, settings->tStop, 1);

	fprintf(stdout, "\nReleasing Solver...\n");

	/*Call the Termination function of the model*/
	if (TerminateModel(pData) == 0)
		iRet = -1;

	HandleTrace(&((ITI_FixStepData*)pData)->pData.sInfo);

	if (iRet == 0) {
		WriteOutput2Stream(outputs, outputData, &(((ITI_FixStepData*)pData)->pData), GetSizeY(pData), iPlaces, 15);
		PrintSolverStatistics(pData);
	}

	/*Free solver and model*/
	FreeSolverInstance(pData);

	if (outputs)
		fclose(outputs);

	return iRet;
}
#endif

int CreateSolverInstance_pneAux_rebuild_generic_std_sf(void** pData, int nParams, double* pValues)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)calloc(1, sizeof(ITI_FixStepData));

	*pData = 0;

	fsd->stat.iValidSteps = 0;
	fsd->stat.iRhsCalls = 0;
	fsd->stat.iRoots = 0;
	fsd->stat.iTimeEvents = 0;

#ifdef _EVENTIT
	eventit = fopen("eventit.txt", "w+");
#endif
#ifdef _SAVE_STATES
	states = fopen("states.txt", "w+");
#endif
#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
	perfmea = fopen("perfmea.txt", "w+");
#endif
#ifdef _JOURNAL
	journal = fopen("journal.txt", "w+");
#endif
#ifdef _ROOT_MESSAGE_FILE
	roots = fopen("roots.txt", "w+");
#endif

	if (InitModelData(fsd, nParams, pValues))
	{
		if (InitSolverData(fsd))
		{
			*pData = (void*)fsd;
			#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
			WriteStreamHeader(perfmea, "t[s]","duration", "", 1, 1, 0);
			#endif
			#ifdef _JOURNAL
			WriteStreamHeader(journal, "t[s]","component error", "", 1, fsd->pData.size.ix, 0);
			#endif
			return 1;
		}
		FreeModelData(fsd);
	}
	free(fsd);
	return 0;
}

static int InitModelData(ITI_FixStepData* fsd, int nParams, double* pValues)
{
	if (!fsd)
		return 0;
	else
	{
		ITI_int i = 0;

		ITI_SimData* sd=&fsd->data;
		ITI_SimVar* sv=&fsd->pData;
		ITI_Model* model = &fsd->model;

		sv->sInfo.bInitializeFuncCalled = 0;
		sv->sInfo.isFirstRhsCall = 0;
		sv->sInfo.bDPHappened = 0;
		sv->sInfo.pContainer = 0;
		sv->sInfo.sSettings = &fsd->ss;

		/*Dimensions*/
		InitModelSizes(&sv->size);
		GetModelSizes_pneAux_rebuild_generic_std_sf(calloc, &sv->size);

		/*Partitions*/
		model->fpartitions = (ITI_PartitionFunctionAccess*)calloc(fsd->pData.size.ipart, sizeof(ITI_PartitionFunctionAccess));
		GetPartitionAccess_pneAux_rebuild_generic_std_sf(model->fpartitions);
		sv->_hyst_init_data = model->fpartitions[0]._hyst_init_data; /*TODO HystInitData to SimData of partitions*/

		model->fpartitions[0].GetModelInfo(&sv->modelInfo);

#ifndef ITI_COMP_SIM
		if ((pValues != 0) && (nParams != (sv->size.ip_int + sv->size.ip_real + sv->size.ip_str)))
		{
			printf("\nERROR: The number of parameters from parameter file (%d) is not equal to the number of model parameters (%d).\nPlease check the parameter file.\n\n", nParams, sv->size.ip_int + sv->size.ip_real + sv->size.ip_str);
			return -1;
		}
#endif
		model->parameters=parameters_pneAux_rebuild_generic_std_sf;
		model->outputData=outputData_pneAux_rebuild_generic_std_sf;
		model->inputData=inputs_pneAux_rebuild_generic_std_sf;
		/*
		model->curveSets=curveSets_pneAux_rebuild_generic_std_sf;
		model->curveNDs=curveNDs_pneAux_rebuild_generic_std_sf;
		model->blockSizes = blockSizes_pneAux_rebuild_generic_std_sf;
		model->stateAttributes=stateAttributes_pneAux_rebuild_generic_std_sf;
		model->seqCsSizes=seqCsSizes_pneAux_rebuild_generic_std_sf;
		model->delayInfos=delayInfos_pneAux_rebuild_generic_std_sf;
		model->numJacColsData = numJacColsData_pneAux_rebuild_generic_std_sf;
		*/
		InitMemory(&sd->currMem, 0, 0);
		InitMemory(&sd->funcMem, 0, 0);
		InitMemory(&sd->strMem, 0, 0);

/*#ifndef ITI_CE_ETAS_LABCAR*/
		g_currMem = &sd->currMem;
		g_sInfo = &sv->sInfo;
/*#endif*/
		/*States*/
		sv->x = (ITI_real*)calloc(sv->size.ix, sizeof(ITI_real));
		sv->xdot = (ITI_real*)calloc(sv->size.ix, sizeof(ITI_real));

		sd->strLengths = (ITI_uint*)calloc(sv->size.iStrs, sizeof(ITI_uint));

		/*Performanceanalyser*/
#ifdef _JOURNAL
		fsd->stat.dblInfluence = (ITI_real*)calloc(sv->size.ix, sizeof(ITI_real));
#endif

		/*Model data*/
		sv->y.realData = (ITI_real*)calloc(sv->size.iy_real, sizeof(ITI_real));
		sv->y.intData = (ITI_int*)calloc(sv->size.iy_int, sizeof(ITI_int));
		sv->y.strData = (ITI_char**)calloc(sv->size.iy_str, sizeof(ITI_char*));
		sv->u.realData = (ITI_real*)calloc(sv->size.iu_real, sizeof(ITI_real));
		sv->u.intData = (ITI_int*)calloc(sv->size.iu_int, sizeof(ITI_int));
		sv->u.strData = (ITI_char**)calloc(sv->size.iu_str, sizeof(ITI_char*));
		if (pValues)
		{
			AllocInitParameters(&sv->p, model->parameters, pValues, sv->size.ip_real, sv->size.ip_int, sv->size.ip_str);
		}
		else
		{
			sv->p.realData = (ITI_real*)calloc(sv->size.ip_real, sizeof(ITI_real));
			sv->p.intData = (ITI_int*)calloc(sv->size.ip_int, sizeof(ITI_int));
			sv->p.strData = (ITI_char**)calloc(sv->size.ip_str, sizeof(ITI_char*));
			sv->p.strSize = (size_t*)calloc(sv->size.ip_str, sizeof(size_t));
			sv->arr_p = (ITI_Array*)calloc(sv->size.ip_arr, sizeof(ITI_Array));
			InitParameter(sv, fsd->model.parameters, 0, 0, GetSize_p_allTypes(fsd));
		}

		sv->v.realData = (ITI_real*)calloc(sv->size.iv_real, sizeof(ITI_real));
		sv->v.intData = (ITI_int*)calloc(sv->size.iv_int, sizeof(ITI_int));
		sv->v.strData = (ITI_char**)calloc(sv->size.iv_str, sizeof(ITI_char*));
		sv->v.strSize = (size_t*)calloc(sv->size.iv_str, sizeof(size_t));

		sv->z.realData = (ITI_real*)calloc(sv->size.iz_real, sizeof(ITI_real));
		sv->z.intData = (ITI_int*)calloc(sv->size.iz_int, sizeof(ITI_int));
		sv->z.strData = (ITI_char**)calloc(sv->size.iz_str, sizeof(ITI_char*));
		sv->z.strSize = (size_t*)calloc(sv->size.iz_str, sizeof(size_t));

		sv->pre_z.realData = (ITI_real*)calloc(sv->size.iz_real, sizeof(ITI_real));
		sv->pre_z.intData = (ITI_int*)calloc(sv->size.iz_int, sizeof(ITI_int));
		sv->pre_z.strData = (ITI_char**)calloc(sv->size.iz_str, sizeof(ITI_char*));
		sv->pre_z.strSize = (size_t*)calloc(sv->size.iz_str, sizeof(size_t));

		sv->bx = (ITI_real*)calloc(sv->size.ibx, sizeof(ITI_real));

		sv->iReinit = (ITI_uint*)calloc(sv->size.ix, sizeof(ITI_uint));
		sv->xReinit = (ITI_real*)calloc(sv->size.ix, sizeof(ITI_real));

		AllocZFData(sv, model->fpartitions[0].dataZF, 1, 0);

		sv->sv = (ITI_int*)calloc(sv->size.isv, sizeof(ITI_int));
		sv->sampleTime = (ITI_SampleTime*)calloc(sv->size.isv, sizeof(ITI_SampleTime));

		sv->cNd = (ITI_CurveData_ND *)calloc(sv->size.icnd, sizeof(ITI_CurveData_ND));
		InitCurveDataND(sv->cNd, model->fpartitions[0].curveNDs, sv->size.icnd, NULL);

		sv->cSet = (ITI_CurveSetData *)calloc(sv->size.icset, sizeof(ITI_CurveSetData));
		InitCurveSetData(sv->cSet, model->fpartitions[0].curveSets, sv->size.icset, NULL);

		AllocateRecords_pneAux_rebuild_generic_std_sf(sv);

		sd->extObj = (ITI_void**)calloc(sv->size.iExtObj, sizeof(ITI_void*));
		InitDataArrays(sv, sv->size.iarr, model->fpartitions[0].arrayData, 0);

		sv->cs = (ITI_CurveCallState*)calloc(sv->size.ics, sizeof(ITI_CurveCallState));
		for (i = 0; i < sv->size.ics; i++){
			sv->cs[i].pSeqCs = (ITI_SeqCallState*)calloc(model->fpartitions[0].seqCsSizes[i], sizeof(ITI_SeqCallState));
			sv->cs[i].pSeqCs->iPos = -1;
		}

		sv->hcs = (ITI_HystCurveCallState*)calloc(sv->size.ihcs, sizeof(ITI_HystCurveCallState));
		for (i = 0; i < sv->size.ihcs; i++){
			/*TODO: Anzahl der sequCallstates stimmt hier nicht, muss wahrscheinlich 3 sein, insgesamt wird bei der Hysteres nur ein Callstate verwendet, was eher falsch ist!*/
			/*sv->hcs[i].pSeqCs = (ITI_SeqCallState*)calloc(sv->seqCsSizes[i], sizeof(ITI_SeqCallState));*/
			sv->hcs[i].pSeqCs = (ITI_SeqCallState*)calloc(3, sizeof(ITI_SeqCallState));
			sv->hcs[i].pSeqCs->iPos = -1;
		}
		sv->db = (ITI_DelayBuffer*)calloc(sv->size.idb, sizeof(ITI_DelayBuffer));
		InitDelayBuffers(sv->db, sv->size.idb, model->fpartitions[0].delayInfos, 0);

		sv->iDPbd = (ITI_DPBlockData*)calloc(sv->size.iDPB, sizeof(ITI_DPBlockData));
		InitDPBlockData(sv->iDPbd, &sv->stateIncidence, model->fpartitions[0].DPBlockSizes, sv->size.iDPB, 0);

		sv->ibd = (ITI_BlockData*)calloc(sv->size.numBlocks, sizeof(ITI_BlockData));
		InitBlockData(sv->ibd, sv->size.numBlocks, model->fpartitions[0].blockSizes, model->fpartitions[0].numJacColsData, model->fpartitions[0].DPBlockSizes, 0);

		fsd->model.fpartitions[0].InitBlockVars(sv->ibd);

#ifdef ITI_CE_EXEC_MODEL
		InitBlockStatistics(&fsd->stat, fsd->pData.size.numBlocks);
		InitPerformanceTiming(&fsd->data.performanceData, fsd->pData.size.numBlocks, 0);
#endif

		sv->smm = (ITI_StateMinMax*)calloc(1, sizeof(ITI_StateMinMax));
		InitStateMinMax(sv->smm, sv->size.numStateAttr);

		for (i = 0; i < fsd->pData.size.iv_str; i++)	{
			if (&fsd->pData.v.strData[i]) {
				if (fsd->pData.v.strSize[i] < 1)	{
					fsd->pData.v.strData[i] = GetStringMemory(&fsd->data.strMem, 1);
					fsd->pData.v.strSize[i] = 1;
				}
				strcpy(fsd->pData.v.strData[i], "");
			}
		}

		for(i = 0; i < fsd->pData.size.iz_str; i++)
		{
			if(&fsd->pData.z.strData[i])
			{
				if(fsd->pData.z.strSize[i] < 1)
				{
					fsd->pData.z.strData[i] = GetStringMemory(&fsd->data.strMem, 1);
					fsd->pData.z.strSize[i] = 1;
				}
				strcpy(fsd->pData.z.strData[i], "");
			}
			if(&fsd->pData.pre_z.strData[i])
			{
				if(fsd->pData.pre_z.strSize[i] < 1)
				{
					fsd->pData.pre_z.strData[i] = GetStringMemory(&fsd->data.strMem, 1);
					fsd->pData.pre_z.strSize[i] = 1;
				}
				strcpy(fsd->pData.pre_z.strData[i], "");
			}
		}

		return 1;
	}
}

static int InitSolverData(ITI_FixStepData* fsd)
{
	if (!fsd)
		return 0;
	else
	{
		ITI_int i;
		ITI_FixStepContext* fsc=&fsd->fsc;
		ITI_SimVar* sv=&fsd->pData;

		/*SolverSettings*/
		GetModelSolverSettings_pneAux_rebuild_generic_std_sf(&fsd->ss);

		/*TimeEvents*/
		fsc->isvMax = sv->size.isv;

		fsc->timeEventMax = (ITI_bui*)calloc(fsc->isvMax, sizeof(ITI_bui));
		fsc->timeEventCounter = (ITI_bui*)calloc(fsc->isvMax, sizeof(ITI_bui));

		for (i = 0; i < sv->size.isv; i++)
		{
			ITI_bui_reset(&fsc->timeEventMax[i]);
			ITI_bui_reset(&fsc->timeEventCounter[i]);
		}

		sv->sInfo.trace = 0;

		AllocAssertData(&sv->sInfo.assertData, sv->size.iass, 0);

		fsc->bReInit = 0;

		ITI_bui_reset(&(fsc->ui_Steps));
		ITI_bi_reset(&(fsc->i_t));
		ITI_bui_reset(&(fsc->ui_dt));

		fsc->bError = 0;

		fsc->xw = 0;
	}
	return 1;
}

void SetIntegrationMethod_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;

	if ((fsd->ss.mode > DOPRI5) || (fsd->ss.mode < EULER))
	{
		ITI_char charMsg[255];
		sprintf(charMsg, "\nWarning: Mode %d is not allowed! Using ITI_STANDARD.\n", fsd->ss.mode);
		traceError(charMsg, &sv->sInfo);
		fsd->ss.mode = ITI_STANDARD;
	}

	fsc->DoIntegration = 0;
	fsc->PostIntegration = 0;
	fsc->Reinit = 0;

	switch(fsd->ss.mode)
	{
		case EULER:
			if (fsd->ss.minmax == 0)
				fsc->DoIntegration = Euphor_DoIntegration;
			else
				fsc->DoIntegration = EuphorMin_DoIntegration;
			fsc->iw = 1;
			break;

		case ITI_STANDARD:
			if (fsd->ss.minmax == 0) {
				fsc->DoIntegration = ITI_FixStep_DoIntegration;
				fsc->Reinit = ITI_FixStep_Reinit;
			}
			else
				fsc->DoIntegration = ITI_FixStepMin_DoIntegration;
			fsc->PostIntegration = ITI_FixStep_PostIntegration;
			fsc->iw = 3;
			break;

		case HEUN:
			if (fsd->ss.minmax == 0) {
				fsc->DoIntegration = Rkfh_DoIntegration;
				fsc->iw = 1;
			}
			else {
				fsc->DoIntegration = RkfhMin_DoIntegration;
				fsc->iw = 2;
			}
			break;

		case RKF23:
			fsc->DoIntegration = Rkf23_DoIntegration;
			fsc->iw = 3;
			break;

		case DOPRI5:
			fsc->DoIntegration = Dopri5_DoIntegration;
			fsc->iw = 6;
			break;

		default:
			break;
	}

	InitWorkData(fsd);
}

static void InitWorkData(ITI_FixStepData* fsd)
{
	ITI_FixStepContext* fsc = &fsd->fsc;

	FreeWorkData(fsd);

	if (fsc->iw > 0)
	{
		ITI_uint i;
		fsc->xw = (ITI_real**)calloc(fsc->iw, sizeof(ITI_real*));
		for (i=0; i<fsc->iw; i++)
			fsc->xw[i] = (ITI_real*)calloc(fsd->pData.size.ix, sizeof(ITI_real));
	}
}

static void FreeWorkData(ITI_FixStepData* fsd)
{
	ITI_FixStepContext* fsc = &fsd->fsc;

	if (fsc->xw != 0)
	{
		ITI_uint i;
		for (i=0; i<fsc->iw; i++)
			free(fsc->xw[i]);
		free(fsc->xw);
		fsc->xw = 0;
	}
}

int SetSolverSettings_pneAux_rebuild_generic_std_sf(void* pData, ITI_SolverSettings* settings)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;

	fsd->ss.tStart = settings->tStart;
	fsd->ss.tStop = settings->tStop;
	fsd->ss.dtMin = settings->dtMin;
	fsd->ss.dtProtMin = settings->dtProtMin;
	fsd->ss.saveMode = settings->saveMode;
	fsd->ss.absTol = settings->absTol;
	fsd->ss.relTol = settings->relTol;
	fsd->ss.gltol = settings->gltol;
	fsd->ss.linSolv = settings->linSolv;
	fsd->ss.ignoreMinMax = settings->ignoreMinMax;
	fsd->ss.minmax = settings->minmax;
	if (fsd->ss.minmax == 1)
		fsd->ss.ignoreMinMax = 0;
	fsd->ss.bAssertOn = settings->bAssertOn;
	fsd->ss.bAssertTraceOn = settings->bAssertTraceOn;

	if(fsd->ss.mode != settings->mode){
		fsd->ss.mode = settings->mode;
		SetIntegrationMethod_pneAux_rebuild_generic_std_sf(pData);
	}
	return 1;
}

int SetTiming_pneAux_rebuild_generic_std_sf(void* pData, ITI_real tStart, ITI_real tStop, ITI_real dt, ITI_real dtProt)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;

	fsd->ss.tStart = tStart;
	fsd->ss.tStop = tStop;
	fsd->ss.dtMin = dt;
	fsd->ss.dtProtMin = dtProt;

	return 1;
}

int Set_dtProt_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtProt)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;

	fsd->ss.dtProtMin = dtProt;
	/*number of integration steps*/
	ITI_bui_reset(&(fsc->ui_IntSteps));
	ITI_bui_setreal(&(fsc->ui_IntSteps), fsd->ss.dtProtMin, fsd->ss.dtMin);

	return 1;
}

int Set_dtMin_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtMin)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;

	fsd->ss.dtMin = dtMin;
	/*number of integration steps*/
	ITI_bui_reset(&(fsc->ui_IntSteps));
	ITI_bui_setreal(&(fsc->ui_IntSteps), fsd->ss.dtProtMin, fsd->ss.dtMin);

	return 1;
}

int Set_dt_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtMin, ITI_real dtProt){
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;

	fsd->ss.dtMin = dtMin;
	fsd->ss.dtProtMin = dtProt;
	/*number of integration steps*/
	ITI_bui_reset(&(fsc->ui_IntSteps));
	ITI_bui_setreal(&(fsc->ui_IntSteps), fsd->ss.dtProtMin, fsd->ss.dtMin);

	return 1;
}

void FreeSolverInstance_pneAux_rebuild_generic_std_sf(void* pData)
{
	if (pData!=0)
	{
		ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
#ifdef _EVENTIT
		fclose(eventit);
#endif
#ifdef _SAVE_STATES
		fclose(states);
#endif
#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
		fclose(perfmea);
#endif
#ifdef _JOURNAL
		fclose(journal);
#endif
#ifdef _ROOT_MESSAGE_FILE
		fclose(roots);
#endif

		FreeModelData(fsd);
		FreeSolverData(fsd);

		free(pData);
	}
}

#if !defined ITI_DSPACE && !defined ITI_NI_RT && !defined ITI_SCALERT && !defined ITI_SFuncSolver && !defined ITI_CE_ETAS_LABCAR && !defined ITI_FMI_CS && !defined ITI_FMI_CS2
void PrintSolverStatistics_str(void* pData, char* strBuff){
	if(pData!=0)	{
		ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
		/*Print Statistics*/
		sprintf(strBuff, "  Steps:\t%u\n  RHS calls:\t%u\n  Events:\t%u\n    State:\t%u\n    Time:\t%u\n    State Sel.:\t%u\n    Other:\t%u\n  States:\t%u\n\n",
		fsd->stat.iValidSteps,
		fsd->stat.iRhsCalls,
		fsd->stat.iZeros + fsd->stat.iTimeEvents + fsd->stat.iStateSelections + fsd->stat.iOtherEvents,
		fsd->stat.iZeros,
		fsd->stat.iTimeEvents,
		fsd->stat.iStateSelections,
		fsd->stat.iOtherEvents,
		fsd->pData.size.ix
		);
	}
}
void PrintSolverStatistics(void* pData){
	if(pData!=0){
		char strBuff[1024];

		PrintSolverStatistics_str(pData, strBuff);
		printf("\n\nStatistics:\n");
		printf(strBuff);
	}
}
#endif

#ifndef ITI_QUOTE1
#define ITI_QUOTE1(arg) #arg
#endif

#ifndef ITI_QUOTE
#define ITI_QUOTE(arg) ITI_QUOTE1(arg)
#endif

void GetModelName_pneAux_rebuild_generic_std_sf(void* pData, char* strName)
{
	strcpy(strName, ITI_QUOTE(ITI_projectName));
}

void GetIntegratorName_pneAux_rebuild_generic_std_sf(void* pData, int iMode, char* strName)
{
	switch(iMode)
	{
		case 0:
			strcpy(strName, "Euler Forward");
			break;
		case 1:
			strcpy(strName, "ITI Standard");
			break;
		case 2:
			strcpy(strName, "Heun");
			break;
		case 3:
			strcpy(strName, "RKF23");
			break;
		case 4:
			strcpy(strName, "DOPRI5");
			break;
		default:
			strcpy(strName, "ITI Standard");
			break;
	}
}

static int FreeSolverData(ITI_FixStepData* fsd)
{
	if (!fsd)
		return 0;
	else
	{
		ITI_FixStepContext* fsc=&fsd->fsc;

		/*free(fsc->old_sign_zf);*/
		free(fsc->timeEventMax);
		free(fsc->timeEventCounter);

		FreeWorkData(fsd);

		return 1;
	}
}

static int FreeModelData(ITI_FixStepData* fsd)
{
	if (!fsd)
		return 0;
	else
	{
		ITI_int i = 0;

		ITI_SimVar* sv=&fsd->pData;
		ITI_SimData* sd=&fsd->data;
		ITI_Model* model = &fsd->model;
		/*
		TerminateModel(fsd);

		if (sv->sInfo.bInitializeFuncCalled)
		{
			sv->sInfo.isTerminal = 1;
			Terminate_pneAux_rebuild_generic_std_sf(&sd->currMem, &sv->sInfo, &fsd->data);
		}
		*/

		free(sv->x);
		free(sv->xdot);

		free(sv->bx);

		free(sd->strLengths);

		free(model->fpartitions);

#ifdef _JOURNAL
		free(fsd->stat.dblInfluence);
#endif

		FreeCompositeData(&sv->y, 0);
		FreeCompositeData(&sv->u, 0);
		for (i = 0; i < sv->size.ip_str; i++){
			if(sv->p.strData[i])
				free(sv->p.strData[i]);
		}
		FreeCompositeData(&sv->p, 0);

		for (i = 0; i < sv->size.ip_arr; i++) {
			free(sv->arr_p[i].dims);
			free(sv->arr_p[i].realValues);
			free(sv->arr_p[i].intValues);
			free(sv->arr_p[i].charValues);
		}
		free(sv->arr_p);

		FreeCompositeData(&sv->v, 0);
		FreeCompositeData(&sv->z, 0);
		FreeCompositeData(&sv->pre_z, 0);

		free(sv->iReinit);
		free(sv->xReinit);

		FreeZFData(sv, 1, 0);

		free(sv->sv);
		free(sv->sampleTime);

		FreeRecords_pneAux_rebuild_generic_std_sf(sv, sd);

		FreeCurveSetData(sv->cSet, sv->size.icset, NULL);
		free(sv->cSet);

		FreeCurveDataND(sv->cNd, sv->size.icnd, NULL);
		free(sv->cNd);

		for (i = 0; i < sv->size.ics; i++){
			free(sv->cs[i].pSeqCs);
		}
		free(sv->cs);

		for (i = 0; i < sv->size.ihcs; i++){
			free(sv->hcs[i].pSeqCs);
		}
		free(sv->hcs);

		FreeDelayBuffers(sv->db, sv->size.idb, 0);
		free(sv->db);

		FreeDPBlockData(sv->iDPbd, &sv->stateIncidence, sv->size.iDPB, 0);
		free(sv->iDPbd);

		FreeBlockData(sv->ibd, sv->size.numBlocks, 0);
		free(sv->ibd);

#ifdef ITI_CE_EXEC_MODEL
		FreeBlockStatistics(&fsd->stat);
		FreePerformanceTiming(fsd->data.performanceData);
#endif

		FreeStateMinMax(sv->smm);
		free(sv->smm);

		free(sd->extObj);
		FreeDataArrays(sv, sd, sv->size.iarr, 0);

		FreeAssertData(&sv->sInfo.assertData, 0);

		FreeAllMemory(&sd->currMem);
		FreeAllMemory(&sd->funcMem);
		FreeAllMemory(&sd->strMem);

		return 1;
	}

}

int SetRealParameters_pneAux_rebuild_generic_std_sf(void* pData, int nParam, double* param)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_SimVar* sv = &fsd->pData;

	InitParameter(sv, parameters_pneAux_rebuild_generic_std_sf, param, nParam, sv->size.ip_int+sv->size.ip_real+sv->size.ip_str);

	return 1;
}

int InitializeModel_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimData* sd = &fsd->data;
	ITI_SimVar* sv = &fsd->pData;

	int i = 0;

	#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
	__int64 temp_time= 0;
	double Add[size_Add];

	for (i=0; i<size_Add; i++)
		Add[i]=0;
	#endif

	fsc->bError = 0;
	fsc->state = _STATE_SUCCESS_CONTINUE;

	SetIntegrationMethod_pneAux_rebuild_generic_std_sf(pData);

	/*initialize Model data*/
	for(i = 0; i < sv->size.iv_real; i++)
		sv->v.realData[i] = 0.0;

	for(i = 0; i < sv->size.ibx; i++)
		sv->bx[i] = 0.0;

	for(i = 0; i < sv->size.iz_real; i++)
	{

		sv->pre_z.realData[i] = 0.0;
		sv->z.realData[i] = 0.0;
	}

	for(i = 0; i < sv->size.iz_int; i++)
	{
		sv->pre_z.intData[i] = 0;
		sv->z.intData[i] = 0;
	}

	for(i = 0; i < sv->size.icset; i++)
	{
		ITI_uint j;
		for (j = 0; j < sv->cSet[i].nYScale; j++)
			sv->cSet[i].pYScale[j].bScaleInitialized = 0;
	}

	for(i = 0; i < sv->size.icnd; i++)
	{
		ITI_uint j;
		for (j = 0; j < sv->cNd[i].nYScale; j++)
			sv->cNd[i].pYScale[j].bScaleInitialized = 0;
	}

	for(i = 0; i < sv->size.ihcs; i++)
		sv->hcs[i].bInitialized = 0;

	for(i = 0; i < sv->size.isv; i++){
		sv->sv[i] = 0;
	}

	/*Zero Functions*/
	InitZFData(sv);

	/*Reset delay Buffers*/
	SetDelayBufferData(sv->db, sv->size.idb);
	InitAssertData(&sv->sInfo.assertData);

	SetDPBlockData(sv->iDPbd, fsd->model.fpartitions[0].DPBlockSizes, sv->size.iDPB);

	sv->sInfo.allowJump = 0;
	sv->sInfo.allowBlockJump = 0;
	sv->sInfo.tracingAllowed = 1;
	sv->sInfo.isInitial = 1;
	sv->sInfo.isTerminal = 0;
	sv->sInfo.iTerminate = 0;
	sv->sInfo.strAnalysesType = "residuals";
	sv->sInfo.strAnalysisTypeDetail = "event";
	sv->sInfo.isEvent = 1;
	sv->sInfo.isFirstEventStep = 1;
	sv->sInfo.applyHysteresis = 0;
	sv->sInfo.bDPAllowed = 1;
	sv->sInfo.bDPRequired = 0;
	sv->sInfo.bSolverNeedsReset = 0;
	sv->sInfo.strTrace[0] = '\0';

	SetBlockSettings(sv->size.numBlocks, sv->ibd, fsd->ss.gltol, fsd->ss.linSolv, fsd->ss.ignoreMinMax);
	ResetBlockData(sv->size.numBlocks, sv->ibd, fsd->model.fpartitions[0].blockSizes);

	sv->sInfo.isEmbed = 0;
	sv->sInfo.bAssertOn = fsd->ss.bAssertOn;
	sv->sInfo.bAssertTraceOn = fsd->ss.bAssertTraceOn;
	sv->sInfo.bAssertActive = 0;
	sv->sInfo.bEventTriggered = 0;
	sv->sInfo.bUseSimpleHomotopy = 0;

	ResetWarningStack(&sv->sInfo);

	sv->sInfo.dt = 0.0;
	for (i = 0; i < sv->size.ix; i++)
	{
		sv->xdot[i] = 0.0;
		sv->x[i] = 0.0;

#ifdef _JOURNAL
		fsd->stat.dblInfluence[i] = 0.0;
#endif
	}

	/*Initialize Model*/
	/*zeroFunction work directly*/
	fsd->pData.szf = fsd->pData.cszf;

	/*start time*/
	sv->t = fsd->ss.tStart;

	fsc->bError = fsd->model.fpartitions[0].InitializeConstants(sv, sd);
	fsc->bError = fsd->model.fpartitions[0].InitializeParameterDependent(sv, sd);
	fsc->bError = fsd->model.fpartitions[0].InitializeTunableParameter(sv,sd);
	fsc->bError = fsd->model.fpartitions[0].Initialize(sv,sd);

	if (fsd->ss.minmax > 0)
		FillStateMinMax(sv, fsd->model.fpartitions[0].stateAttributes, fsd->pData.size.numStateAttr, ITI_absTol);

	sv->sInfo.bInitializeFuncCalled = 1;

	if (fsc->bError || sv->sInfo.iTerminate)
	{
		HandleWarnings(&sv->sInfo);
		if(fsc->bError)
			traceError("\nError: During Initialization!\n", &sv->sInfo);
		if(sv->sInfo.iTerminate)
			traceError("\nInfo: The simulation was stopped during Initialization!\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
		ReleaseAllMemory(&sd->currMem);
		ReleaseAllMemory(&sd->strMem);
		fsc->state = _STATE_ERROR_IN_INITIALIZATION;
		return fsc->state;
	}
	ReleaseAllMemory(&sd->currMem);

	fsd->stat.iValidSteps = 0;
	fsd->stat.iRhsCalls = 0;
	fsd->stat.iRoots = 0;
	fsd->stat.iTimeEvents = 0;

	return _STATE_SUCCESS_CONTINUE;
}

int InitializeConditionsModel_pneAux_rebuild_generic_std_sf(void* pData){
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;

	if(InitializeConditionsModelOnly_pneAux_rebuild_generic_std_sf(pData) == _STATE_SUCCESS_CONTINUE){
		InitializeConditionsModelFinish_pneAux_rebuild_generic_std_sf(pData);
	}
	return fsc->state;
}

int InitializeConditionsModelOnly_pneAux_rebuild_generic_std_sf(void* pData){
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;

	ITI_EmbeddingData hom;
	ITI_EmbeddingParams homp;

	if (sv->size.bxind_lambda > -1)
		InitHomotopy_pneAux_rebuild_generic_std_sf(sv, sd, &hom, &homp,(ITI_uint)sv->size.bxind_lambda, sv->size.bxind_homlast, sv->size.ihomres, fsd->ss.absTol, fsd->ss.relTol);

	/*zeroFunctions work directly*/
	fsd->pData.szf = fsd->pData.cszf;

	/*TODO: Check if necessary?
	Update_pre_zf(fsd->pData.zf, fsd->pData.pre_zf, fsd->pData.size.izf);
	*/
	Update_oszf(sv);

	if (sv->size.bxind_lambda > -1)
		CopyVars(sv->bx, hom.bx_tmp, 0, sv->size.bxind_homlast);

	/*TODO: Check with model from Alex: assert acts now in InitializeConditions too*/
	fsd->pData.sInfo.bAssertActive = fsd->pData.sInfo.bAssertOn;
	fsd->pData.sInfo.bInitializeConditions = 1;
	fsc->bError = fsd->model.fpartitions[0].InitializeConditions(sv, sd);
	fsd->pData.sInfo.bInitializeConditions = 0;
	ReleaseAllMemory(&sd->currMem);
	fsd->pData.szf = fsd->pData.oszf;

	if (sv->size.bxind_lambda > -1 && fsc->bError > 0){
		ResetWarningStack(&sv->sInfo);
		sv->sInfo.iTerminate = 0;
		Restore_z_data(sv, sd, &sv->pre_z);
		fsc->bError = CalcCurve_pneAux_rebuild_generic_std_sf(sv, sd, &hom, &homp, 0);
	}
	if (fsc->bError || sv->sInfo.iTerminate){
		HandleWarnings(&sv->sInfo);
		if(fsc->bError)
			traceError("\nError: During computation of initial conditions!\n", &sv->sInfo);
		if(sv->sInfo.iTerminate)
			traceError("\nInfo: The simulation was stopped during computation of initial conditions!\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
		ReleaseAllMemory(&sd->currMem);
		ReleaseAllMemory(&sd->strMem);
		if (sv->size.bxind_lambda > -1)
			FreeHomotopy_pneAux_rebuild_generic_std_sf(sv, &hom);

		fsc->state = _STATE_ERROR_IN_INITIALIZATION;
		return fsc->state;
	}

	if (sv->size.bxind_lambda > -1)
		FreeHomotopy_pneAux_rebuild_generic_std_sf(sv, &hom);

	if (fsd->ss.saveMode == SaveOutputsAtleastwithdtProtPrePostEvents)
		CalcModelOutputs_pneAux_rebuild_generic_std_sf(pData);

	return _STATE_SUCCESS_CONTINUE;
}

int InitializeConditionsModelFinish_pneAux_rebuild_generic_std_sf(void* pData){
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;

	ITI_int iFound = 0;
	ITI_real maxVal;
	ITI_char strMsg[1024];

	size_t i=0;
	ITI_int bDoEventiteration = 0;
	ITI_int iRet = 0;

	bDoEventiteration |= Check_z_data(sv, sv->sInfo.sSettings->absTol, sv->sInfo.sSettings->relTol);

	/*Handles if/when initial()... then terminate()*/
	if(sv->sInfo.iTerminate==1){
		fsc->bTerminateRequired = 1;
		fsc->state = _STATE_TERMINATED;
		bDoEventiteration = 1;
	}

	/*handle reinit(..)*/
	if(fsd->pData.sInfo.bSolverNeedsReset){
		fsd->pData.sInfo.bSolverNeedsReset = 0;
		bDoEventiteration |= 1;
	}

	/* dtMin must not be greater than tStop - tStart */
	if (fsd->ss.dtMin > fsd->ss.tStop - fsd->ss.tStart && fsd->ss.tStop > fsd->ss.tStart) {
		fsd->ss.dtMin = fsd->ss.tStop - fsd->ss.tStart;
		sprintf(strMsg, "Warning: dtMin must not be greater than tStop - tStart. It is reduced to tStop - tStart = %g.\n", fsd->ss.dtMin);
		traceWarning(strMsg, &sv->sInfo);
		HandleWarnings(&sv->sInfo);
		HandleTrace(&sv->sInfo);
	}

	/*GetSampleTimes*/
	fsd->model.fpartitions[0].SampleFunction(sv, sd);

	iFound = 0;
	for (i = 0; i < (size_t)sv->size.isv; i++){
		if(sv->sampleTime[i].ts <= 0.0){
			iFound = 1;
			break;
		}
		if(sv->sampleTime[i].ts < fsd->ss.dtMin){
			sprintf(strMsg, "\nWarning: The model contains a sample time of %g s which is smaller than the minimum step size dtMin (%g s). The minimum step size is reduced to this value in order to represent that sample time precisely.\n\n", sv->sampleTime[i].ts, fsd->ss.dtMin);
			traceWarning(strMsg, &sv->sInfo);
			HandleWarnings(&sv->sInfo);
			HandleTrace(&sv->sInfo);
			fsd->ss.dtMin = sv->sampleTime[i].ts;
		}
		if((sv->sampleTime[i].to > 0.0) && (sv->sampleTime[i].to < fsd->ss.dtMin)){
			sprintf(strMsg, "\nWarning: The model contains a sample offset time of %g s which is smaller than the minimum step size dtMin (%g s). The minimum step size is reduced to this value in order to represent that sample offset time precisely.\n\n", sv->sampleTime[i].to, fsd->ss.dtMin);
			traceWarning(strMsg, &sv->sInfo);
			HandleWarnings(&sv->sInfo);
			HandleTrace(&sv->sInfo);
			fsd->ss.dtMin = sv->sampleTime[i].to;
		}
	}
	if(iFound){
		HandleWarnings(&sv->sInfo);
		traceError("\nError: One of the sample times is zero or not constant. This is not allowed for this solver!\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
		return 0;
	}
	maxVal = ITI_bui_getrealMax(fsd->ss.dtMin);
	for (i = 0; i < (size_t)sv->size.isv; i++){
		if(sv->sampleTime[i].ts > maxVal)	{
			sprintf(strMsg, "\nWarning: The model contains a large sample time of %g s. This sample time cannot be expressed using the current setting for dtMin (%g s).\nThe biggest representable value is %g s. The sample time is reduced to that value.\nPlease consider an increasing of dtMin or a reduction of the sample time if this leads to wrong behaviour.\n\n", sv->sampleTime[i].ts, fsd->ss.dtMin, maxVal);
			traceWarning(strMsg, &sv->sInfo);
			HandleWarnings(&sv->sInfo);
			HandleTrace(&sv->sInfo);
			sv->sampleTime[i].ts = maxVal;
		}
		if(fabs(sv->sampleTime[i].to - fsd->ss.tStart) > maxVal){
			sprintf(strMsg, "\nWarning: The model contains a large sample offset time of %g s. This offset time value cannot be expressed using the current setting for dtMin (%g s).\nThe biggest representable value is %g s. The sample time is reduced to that value.\nPlease consider an increasing of dtMin or a reduction of the offset time if this leads to wrong behaviour.\n\n", sv->sampleTime[i].to, fsd->ss.dtMin, maxVal);
			traceWarning(strMsg, &sv->sInfo);
			HandleWarnings(&sv->sInfo);
			HandleTrace(&sv->sInfo);
			sv->sampleTime[i].to = maxVal + fsd->ss.tStart;
		}
	}
	/*tOffsets*/
	for (i = 0; i < (size_t)sv->size.isv; i++){
		ITI_real tOffset=sv->sampleTime[i].to - fsd->ss.tStart;
		if(tOffset<0.0){
			ITI_real tMod = fmod(fabs(tOffset) / sv->sampleTime[i].ts, 1.0);
			if(fabs(tMod)<1e-12)
				tMod = 0.0;
			if(fabs(tMod-1.0)<1e-12)
				tMod = 1.0;
			tOffset = (1.0 - tMod) * fsd->pData.sampleTime[i].ts;
		}
		ITI_bui_setreal(&fsc->timeEventMax[i], fabs(tOffset), fsd->ss.dtMin);
		fsc->timeEventCounter[i] = fsc->timeEventMax[i];
	}

	/*Check for time event at t=tStart*/
	for (i = 0; i < (size_t)sv->size.isv; i++){
		ITI_bui_setreal(&fsc->timeEventMax[i], sv->sampleTime[i].ts, fsd->ss.dtMin);
		if(ITI_bui_is_zero(&fsc->timeEventCounter[i])){
			fsc->bTimeEvent = 1;
		}
	}

	/*Initialize Timing*/
	if (fsd->ss.dtProtMin < fsd->ss.dtMin)
	{
		char charMsg[255];
		sprintf(charMsg, "\nWarning: dtProtMin < dtMin is not allowed!\nUsing dtProtMin = dtMin = %-.16g.\n", fsd->ss.dtMin);
		traceWarning(charMsg, &sv->sInfo);
		fsd->ss.dtProtMin = fsd->ss.dtMin;
	}

	/*Start time*/
	ITI_bi_setreal(&(fsc->i_t), fsd->ss.tStart, fsd->ss.dtMin);
	sv->t = ITI_bi_getreal(&(fsc->i_t), fsd->ss.dtMin);

	/*Stepsize*/
	ITI_bui_setreal(&(fsc->ui_dt), fsd->ss.dtMin, fsd->ss.dtMin);
	fsc->dt = ITI_bui_getreal(&(fsc->ui_dt), fsd->ss.dtMin);
	/*number of integration steps*/
	ITI_bui_reset(&(fsc->ui_IntSteps));
	ITI_bui_setreal(&(fsc->ui_IntSteps), fsd->ss.dtProtMin < fsd->ss.tStop ? fsd->ss.dtProtMin : fsd->ss.tStop, fsd->ss.dtMin);

	/*gltol*/
	if (fsd->ss.gltol >= fsd->ss.relTol || fsd->ss.gltol >= fsd->ss.absTol) {
		double tol = min(fsd->ss.relTol, fsd->ss.absTol) / 10.;
		sprintf(strMsg, "\nWarning: The tolerance for solving implicit blocks (%g) must be smaller than absolute and relative tolerance. It is reduced to %g.\n\n", fsd->ss.gltol, tol);
		traceWarning(strMsg, &sv->sInfo);
		HandleWarnings(&sv->sInfo);
		HandleTrace(&sv->sInfo);
		fsd->ss.gltol = tol;
	}

	Update_pre_zf(sv->zf, sv->pre_zf, sv->size.izf);
	Update_oszf(sv);
	/*pre Values get the current Values*/
	Update_pre_z_data(sv, sd);

	fsd->model.fpartitions[0].AssignLastVar(sv, sd);
	UpdateHystCurves(sv->hcs, sv->size.ihcs);
	/*
	UpdateDelayBuffers(fsd->pData.db, fsd->pData.size.idb);
	*/

	fsd->pData.sInfo.isInitial = 0;
	fsd->pData.sInfo.isTerminal = 0;
	fsd->pData.sInfo.strAnalysesType = "residuals";
	fsd->pData.sInfo.strAnalysisTypeDetail = "residuals";
	fsd->pData.sInfo.isEvent = 0;
	fsd->pData.sInfo.isFirstEventStep = 0;
	fsd->pData.sInfo.tracingAllowed = 1;
	fsd->pData.sInfo.bDPAllowed = 1;

	/*TODO: For FMI 2.0:
	- call fmiExitInitializationMode
	*/

	fsd->pData.sInfo.strAnalysisTypeDetail = "validInitialization";
	fsd->pData.sInfo.bEventTriggered = 0;
	/*TODOD: Check whether isFirstRhsCall = 1 fits with "validInitialization"*/
	fsd->pData.sInfo.isFirstRhsCall = 1;
	fsd->stat.iRhsCalls++;
	if (fsd->model.fpartitions[0].CalcDerivatives(sv, sd)){
		sv->sInfo.isFirstRhsCall = 0;
		HandleWarnings(&fsd->pData.sInfo);
		traceError("Error in first RHS call after initialization.", &fsd->pData.sInfo);
		fsc->state = _STATE_ERROR_IN_INITIALIZATION;
		return fsc->state;
	}
	ReleaseAllMemory(&sd->currMem);

	UpdateDelayBuffers(sv->db, sv->size.idb);

	Restore_z_data(sv, sd, &sv->pre_z);

	fsd->pData.sInfo.isFirstRhsCall = 0;

	fsd->pData.sInfo.strAnalysisTypeDetail = "residuals";

	/*First RHS call*/
	if(!(bDoEventiteration || sv->sInfo.bEventTriggered || fsd->fsc.bTimeEvent)){
		fsd->stat.iRhsCalls++;
		if (fsd->model.fpartitions[0].CalcDerivatives(sv, sd)){
			fsc->state = _STATE_ERROR_IN_INITIALIZATION;
			HandleWarnings(&sv->sInfo);
			traceError("Error in first RHS call after initialization.", &sv->sInfo);
			return fsc->state;
		}
		ReleaseAllMemory(&sd->currMem);

		bDoEventiteration |= Check_z_data(sv, sv->sInfo.sSettings->absTol, sv->sInfo.sSettings->relTol);
		/*Undo changes of discrete variables which are not allowed, but might have happened*/
		Restore_z_data(sv, sd, &sv->pre_z);
	}
	/*State event?*/
	fsc->bZeroFunc = Check_Update_oszf(sv);

	/*Eventiteration at start*/
	if(bDoEventiteration || sv->sInfo.bEventTriggered || fsd->fsc.bTimeEvent || fsc->bZeroFunc){
		if(fsc->bZeroFunc)
			fsd->stat.iZeros++;
		if(fsc->bTimeEvent)
			fsd->stat.iTimeEvents++;
		if(sv->sInfo.bEventTriggered)
			fsd->stat.iOtherEvents++;

		sv->sInfo.isInitial = 1;
		fsc->state = EventIteration_pneAux_rebuild_generic_std_sf(pData);
		fsc->bZeroFunc = 0;
		fsc->bTimeEvent = 0;
		sv->sInfo.bEventTriggered = 0;
	}

	if(fsc->state < 0){
		/*
		//TODO: necessary  in case of Eventiteration?
		HandleWarnings(&fsd->pData.sInfo);
		fsd->pData.sInfo.trace(0,4, " Error", "Error during initialization.", (void*)&fsd->pData.sInfo);
		*/
		fsc->state = _STATE_ERROR_IN_INITIALIZATION;
		return fsc->state;
	}

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	if (fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd) > 0) {
		ReleaseAllMemory(&sd->currMem);
		HandleWarnings(&sv->sInfo);
		fsc->state = _STATE_ERROR;
		return fsc->state;
	}

	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->model.fpartitions[0].AssignLastVar(sv, sd);
	UpdateDelayBuffers(sv->db, sv->size.idb);
	UpdateHystCurves(sv->hcs, sv->size.ihcs);
	HandleAssertWarnings(&sv->sInfo);

	if(sv->sInfo.iTerminate==1){
		fsc->state = _STATE_TERMINATED;
		return fsc->state;
	}

	sv->sInfo.tracingAllowed = 0;

	fsc->bAtStart = 1;

	return 1;
}

void CalcOneStep_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int i;

	#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
	__int64 temp_time = 0;
	double Add[size_Add];
	#endif

	if (fsc->bAtStart)
	{
		if (fsd->ss.ignoreMinMax == 0 && fsd->ss.minmax == 0) {
			fsc->bError = CheckMinMax(sv);
			if (fsc->bError) {
				HandleWarnings(&sv->sInfo);
				traceError("\nError: A state violates a limit.\n", &sv->sInfo);
				HandleTrace(&sv->sInfo);
				return;
			}
		}
		fsc->bAtStart = 0;
	}
	else
	{
		/*calculation over time*/
		sv->sInfo.isEvent = 0;
		sv->sInfo.strAnalysisTypeDetail = "residuals";
		sv->sInfo.isFirstEventStep = 0;
		sv->sInfo.bDPAllowed = 0;
		sv->sInfo.bSolverNeedsReset = 0;
		fsc->ui_IntStep_Counter = fsc->ui_IntSteps;

		/*do ui_IntSteps integration steps*/
		while(!ITI_bui_is_zero(&(fsc->ui_IntStep_Counter)))
		{
			#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
			temp_time = Measure_Cycl();
			Add[0] = (double)(temp_time-temp_time_start)/CYCLES_PER_MUESEC;
			#endif

			fsc->bZeroFunc = 0;
			sv->sInfo.bEventTriggered = 0;

			ITI_bui_inc(&(fsc->ui_Steps));

			/*decrement counter*/
			ITI_bui_dec(&(fsc->ui_IntStep_Counter));

			/*new time*/
			ITI_bi_plus(&(fsc->i_t), &(fsc->ui_dt));

			/*t=tNew;*/
			sv->t = ITI_bi_getreal(&(fsc->i_t), fsd->ss.dtMin);

			sv->sInfo.dt = fsd->ss.dtMin;

			/*Integration*/
			fsc->DoIntegration(pData);
			if (fsc->bError)
			{
				HandleWarnings(&sv->sInfo);
				traceError("\nError: During computation of the RHS-Function!\n", &sv->sInfo);
				HandleTrace(&sv->sInfo);
				return;
			}

			if (fsd->ss.ignoreMinMax == 0 && fsd->ss.minmax == 0) {
				fsc->bError = CheckMinMax(sv);
				if (fsc->bError) {
					HandleWarnings(&sv->sInfo);
					traceError("\nError: A state violates a limit.\n", &sv->sInfo);
					HandleTrace(&sv->sInfo);
					return;
				}
			}

			fsd->stat.iValidSteps++;

			if (fsc->Reinit)
			{
				if (fsc->bReInit)
				{
					sv->sInfo.iTerminate = 0;
					fsc->Reinit(pData);
					if (fsc->bError)
					{
						HandleWarnings(&sv->sInfo);
						traceError("\nError: During computation of the RHS-Function!\n", &sv->sInfo);
						HandleTrace(&sv->sInfo);
						return;
					}
					fsc->bReInit = 0;
				}
			}

			/*Check Zero Functions*/
			fsc->bZeroFunc = CheckForZeroCrossing(sv);

			/*Time Events*/
			/*Set SampleVars*/
			fsc->bTimeEvent = 0;
			for (i = 0; i < sv->size.isv; i++)
			{
				/*dec timers*/
				ITI_bui_minus(&(fsc->timeEventCounter[i]), &(fsc->ui_dt));
				if (ITI_bui_is_zero(&(fsc->timeEventCounter[i])))
				{
					/*set timer to new value*/
					fsc->timeEventCounter[i] = fsc->timeEventMax[i];
					sv->sv[i] = 1;
					fsc->bTimeEvent = 1;
				}
			}

			/*tStop*/
			/*
			if (sv->t>=fsd->ss.tStop)
				sv->sInfo.isTerminal=1;
			*/
			/*Last Values get the current values*/
			fsd->model.fpartitions[0].AssignLastVar(sv, sd);
			UpdateDelayBuffers(sv->db, sv->size.idb);
			UpdateHystCurves(sv->hcs, sv->size.ihcs);
			HandleAssertWarnings(&sv->sInfo);

			/*EventIteration if necessary*/
			if (fsc->bTimeEvent || fsc->bZeroFunc || sv->sInfo.bDPRequired || sv->sInfo.bEventTriggered){
				if(fsc->bZeroFunc)
					fsd->stat.iZeros++;
				if(fsc->bTimeEvent)
					fsd->stat.iTimeEvents++;
				if(fsd->pData.sInfo.bEventTriggered)
					fsd->stat.iOtherEvents++;
				if(sv->sInfo.bDPRequired)
					fsd->stat.iStateSelections++;

#ifdef _EVENTIT
				if (fsc->bZeroFunc)
					fprintf(eventit, "Root of Zerofunction at t=%.10f\n", sv->t);
				if (sv->sInfo.bDPRequired)
					fprintf(eventit, "New Dummy Derivative Pivoting at t=%.10f\n", sv->t);
				if (fsc->bTimeEvent)
					fprintf(eventit, "TimeEvent at t=%.10f\n", sv->t);
#endif
#if defined _ROOT_MESSAGE_SCREEN && defined _EVENT_STEP
				if (((sv->t >= _ROOT_PROT_BEGIN[0])&&(sv->t <= _ROOT_PROT_END[0])) || ((sv->t >= _ROOT_PROT_BEGIN[1])&&(sv->t <= _ROOT_PROT_END[1])) || ((sv->t >= _ROOT_PROT_BEGIN[2])&&(sv->t <= _ROOT_PROT_END[2])))
				{
					if (bZeroFunc)
						fprintf(stdout, "Root of Zerofunction at t=%.10f\n", sv->t);
					if (sv->sInfo.bDPRequired)
						fprintf(stdout, "New Dummy Derivative Pivoting at t=%.10f\n", sv->t);
					if (fsc->bTimeEvent)
						fprintf(stdout, "TimeEvent at t=%.10f\n", sv->t);
				}
#endif
#if defined _ROOT_MESSAGE_FILE && defined _EVENT_STEP
				if (((sv->t >= _ROOT_PROT_BEGIN[0])&&(sv->t <= _ROOT_PROT_END[0])) || ((sv->t >= _ROOT_PROT_BEGIN[1])&&(sv->t <= _ROOT_PROT_END[1])) || ((sv->t >= _ROOT_PROT_BEGIN[2])&&(sv->t <= _ROOT_PROT_END[2])))
				{
					if (fsc->bZeroFunc)
						fprintf(roots, "Root of Zerofunction at t=%.10f\n", sv->t);
					if (sv->sInfo.bDPRequired)
						fprintf(roots, "New Dummy Derivative Pivoting at t=%.10f\n", sv->t);
					if (fsc->bTimeEvent)
						fprintf(roots, "TimeEvent at t=%.10f\n", sv->t);
				}
#endif

				if (EventIteration_pneAux_rebuild_generic_std_sf(pData) < 0)
					return;
			}
			else
			{
				/*pre Values get the actual Values*/
				/*Update_pre_zf(sv->zf, sv->pre_zf, sv->size.izf);*/
			}

			if (sv->sInfo.iTerminate)
			{
				HandleWarnings(&sv->sInfo);
				traceError("\nInfo: The simulation was stopped during computation of the RHS-Function!\n", &sv->sInfo);
				HandleTrace(&sv->sInfo);
				return;
			}

			if (fsc->PostIntegration)
				fsc->PostIntegration(pData);

			sv->sInfo.bSolverNeedsReset = 0;

			#ifdef _SAVE_STATES
			Write2Stream(states, &sv->t, sv->x, sv->xdot, 1, sv->size.ix, sv->size.ix, 5, 15, 15);
			#endif

			#if defined(_PERFMEA) && defined(_MSC_VER) && !defined(_WIN64)
			temp_time = Measure_Cycl();
			Add[1] = (double)(temp_time-temp_time_start)/CYCLES_PER_MUESEC;
			Add[0] = (double)(Add[1]-Add[0]);
			Write2Stream(perfmea, &sv->t, Add, 0, 1, 1, 0, 5, 15, 15);
			#endif

			#ifdef _JOURNAL
			Write2Stream(journal, &sv->t, fsd->stat.dblInfluence, 0, 1, sv->size.ix, 0, 5, 15, 0);
			#endif
		}
	}

#if !defined ITI_SFuncSolver && !defined ITI_FMI_CS
	/*TODO: Optimize for FMI CS*/
	fsc->bError = fsd->model.fpartitions[0].CalcOutputs(sv, NULL, NULL, sd);
	fsc->bError += fsd->model.fpartitions[0].SynchOutputs(sv, NULL, NULL, sd);
	if (fsc->bError > 0)
	{
		HandleWarnings(&sv->sInfo);
		traceError("\nError: While computing outputs.\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
		ReleaseAllMemory(&sd->currMem);
		return;
	}
#endif
	ReleaseAllMemory(&sd->currMem);
}

void CalcModelOutputs_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_FixStepContext* fsc = &fsd->fsc;

	fsc->bError = fsd->model.fpartitions[0].CalcOutputs(sv, NULL, NULL, sd);
	fsc->bError += fsd->model.fpartitions[0].SynchOutputs(sv, NULL, NULL, sd);
	if (fsc->bError > 0) {
		HandleWarnings(&sv->sInfo);
		traceError("\nError: While computing outputs.\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
	}
	ReleaseAllMemory(&sd->currMem);
}

void CalcDerivativesAndModelOutputs_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_FixStepContext* fsc = &fsd->fsc;

	char* strAnalysisTypeDetail;
	int isEvent;
	int isFirstEventStep;
	int tracingAllowed;

	strAnalysisTypeDetail = fsd->pData.sInfo.strAnalysisTypeDetail;
	isEvent = fsd->pData.sInfo.isEvent;
	isFirstEventStep = fsd->pData.sInfo.isFirstEventStep;
	tracingAllowed = fsd->pData.sInfo.tracingAllowed;

	fsd->pData.sInfo.strAnalysisTypeDetail = "residuals";
	fsd->pData.sInfo.isEvent = 0;
	fsd->pData.sInfo.isFirstEventStep = 0;
	fsd->pData.sInfo.tracingAllowed = 0;

	fsd->model.fpartitions[0].CalcDerivatives(&fsd->pData, &fsd->data);
	ReleaseAllMemory(&sd->currMem);

	fsd->pData.sInfo.strAnalysisTypeDetail = strAnalysisTypeDetail;
	fsd->pData.sInfo.isEvent = isEvent;
	fsd->pData.sInfo.isFirstEventStep = isFirstEventStep;
	fsd->pData.sInfo.tracingAllowed = tracingAllowed;

	fsc->bError = fsd->model.fpartitions[0].CalcOutputs(sv, NULL, NULL, sd);
	fsc->bError += fsd->model.fpartitions[0].SynchOutputs(sv, NULL, NULL, sd);
	if (fsc->bError > 0) {
		HandleWarnings(&sv->sInfo);
		traceError("\nError: While computing outputs.\n", &sv->sInfo);
		HandleTrace(&sv->sInfo);
	}
	ReleaseAllMemory(&sd->currMem);
}

int TerminateModel_pneAux_rebuild_generic_std_sf(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	int bOK = 1;
	size_t i;

	if (sv->sInfo.MEcalled) /* do not call any model functions after ModelicaError */
		return 0;

	/*Solver Info*/
	sv->sInfo.isInitial = 0;
	sv->sInfo.isTerminal = 1;
	sv->sInfo.iTerminate = 0;
	sv->sInfo.strAnalysesType = "residuals";
	sv->sInfo.strAnalysisTypeDetail = "event";
	sv->sInfo.isEvent = 1;
	sv->sInfo.bDPAllowed = 1;
	sv->sInfo.bDPRequired = 0;
	sv->sInfo.bSolverNeedsReset = 0;

	/*call model with terminal() = true if not already done and no error occurred*/
	if(!fsd->fsc.bError && !sv->sInfo.isTerminal && sv->sInfo.bInitializeFuncCalled){
		if (fsd->model.fpartitions[0].CalcDerivatives(sv, sd) > 0){
			HandleWarnings(&sv->sInfo);
			traceError("\nError: While computing derivatives during termination.\n", &sv->sInfo);
			HandleTrace(&sv->sInfo);
			bOK = 0;
		}
		fsd->stat.iRhsCalls++;
		if (fsd->model.fpartitions[0].CalcOutputs(sv, NULL, NULL, sd) > 0){
			HandleWarnings(&sv->sInfo);
			traceError("\nError: While computing outputs during termination.\n", &sv->sInfo);
			HandleTrace(&sv->sInfo);
			bOK = 0;
		}
		fsd->model.fpartitions[0].SynchOutputs(sv, NULL, NULL, sd);
	}

	if(sv->sInfo.bInitializeFuncCalled){
		sv->sInfo.isTerminal = 1;
		if (fsd->model.fpartitions[0].Terminate(&fsd->pData, NULL, NULL, &fsd->data) > 0) {
			HandleWarnings(&sv->sInfo);
			traceError("\nError: While calling the Terminate() function of the model during termination.\n", &sv->sInfo);
			HandleTrace(&sv->sInfo);
			bOK = 0;
		}
	}

	ReleaseAllMemory(&sd->currMem);
	ReleaseAllMemory(&sd->strMem);

	for(i=0; i<(size_t)fsd->pData.size.iStrs; i++)
		fsd->data.strLengths[i] = 0;
	for (i = 0; i < (size_t)fsd->pData.size.iv_str; i++)
		fsd->pData.v.strSize[i] = 0;
	for (i = 0; i < (size_t)fsd->pData.size.iz_str; i++) {
		fsd->pData.z.strSize[i] = 0;
		fsd->pData.pre_z.strSize[i] = 0;
	}

	return bOK;
}

int EventIteration_pneAux_rebuild_generic_std_sf(void* pData){
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_FixStepContext* fsc = &fsd->fsc;

	size_t i;
	ITI_ushort bSolverNeedsReset = 0;

	fsc->iIter = 0;
	fsc->bRepeat = 0;

	fsd->pData.sInfo.bDPHappened = 0;
	fsc->bDPHappendInEventiteration = 0;
	fsd->pData.sInfo.bDPAllowed = 1;
	fsd->pData.sInfo.bDPRequired = 0;
	fsd->pData.sInfo.tracingAllowed = 1;
	fsd->pData.sInfo.isEvent = 1;
	fsd->pData.sInfo.isFirstEventStep = 1;
	fsd->pData.sInfo.strAnalysisTypeDetail = "event";

	if(!fsd->pData.sInfo.isInitial){
		/*Update Real discrete*/
		fsd->model.fpartitions[0].AssignDiscreteReal(&fsd->pData, &fsd->data);
		Update_real_pre_z_data(sv);
		fsd->pData.sInfo.applyHysteresis = 1;
	}
	else{
		fsd->pData.sInfo.applyHysteresis = 0;
	}

	/*TODO: Check if necessary*/
	Update_oszf(sv);
	/*zeroFunction work directly*/
	sv->szf = sv->cszf;
	Reset_ezf(sv);

	sv->sInfo.dt = 0.0;

	do{
		fsd->stat.iRhsCalls++;
		fsd->stat.iZero++;
		sv->sInfo.bSolverNeedsReset = 0;

		fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
		ReleaseAllMemory(&sd->currMem);

		sv->sInfo.isFirstEventStep = 0;

		if(sv->sInfo.isInitial){
			sv->sInfo.isInitial = 0;
			if(fsc->bTimeEvent){
				/*Set SampleVars for t=tStart*/
				for (i = 0; i < (size_t)sv->size.isv; i++){
					ITI_bui_setreal(&fsc->timeEventMax[i], sv->sampleTime[i].ts, fsd->ss.dtMin);
					if(ITI_bui_is_zero(&fsc->timeEventCounter[i])){
						fsc->timeEventCounter[i] = fsc->timeEventMax[i];
						sv->sv[i] = 1;
					}
				}
			}
		}
		else{
			if(fsc->bTimeEvent){
				fsc->bTimeEvent = 0;
				/*Reset SampleVars*/
				for (i = 0; i < (size_t)sv->size.isv; i++)
					sv->sv[i] = 0;
			}
		}

		if (fsc->bError){
			HandleWarnings(&sv->sInfo);
			traceError("\nError: During Reinitialization after an Event!\n", &sv->sInfo);
			fsc->state = _STATE_ERROR_IN_INITIALIZATION_AFTERDISCONTINUITY;
			return fsc->state;
		}

		/*handle reinit(..)*/
		if(sv->sInfo.bSolverNeedsReset){
			bSolverNeedsReset = 1;
			sv->sInfo.bSolverNeedsReset = 0;

			for (i = 0; i < (size_t)sv->size.ix; i++){
				if(sv->iReinit[i]){
					sv->x[i] = sv->xReinit[i];
					/*fsc->xChanged[i] = 1;*/
					sv->iReinit[i] = 0;
				}
			}
		}
		fsc->bRepeat = fsc->bTimeEvent;

		fsd->model.fpartitions[0].AssignDiscreteReal(sv, sd);

		/*Check for change of discrete variables*/
		fsc->bRepeat |= Check_z_data(sv, sv->sInfo.sSettings->absTol, sv->sInfo.sSettings->relTol);

		Update_czf(sv);
		fsc->bRepeat |= Check_Update_oszf(sv);

		if(fsc->bRepeat && fsc->iIter>10)
			sv->sInfo.applyHysteresis = 1;

		if(sv->sInfo.applyHysteresis){
			UpdateEpsilonZF(sv);
		}

		if(fsc->iIter>995)	{
			WarningChangedDiscreteVars(sv, fsc->iIter, 10.0*sv->sInfo.sSettings->gltol, 10.0*sv->sInfo.sSettings->gltol);
		}

		Update_pre_z_data(sv, sd);

		fsc->iIter++;

		/*event step at end, stop after next cycle in order to avoid addidional evaluations after when(terminal() was true*/
		/*TODO check with spec*/
		if(fsc->bTerminateRequired){
			sv->sInfo.isTerminal = 1;
			fsc->bTerminateRequired = 0;
		}
		else if(sv->sInfo.isTerminal == 1){
			fsc->bRepeat = 0;
		}
		else if(sv->sInfo.iTerminate == 1){ /*Handles if ... then terminate() und when .. then terminate() */
			sv->sInfo.isTerminal = 1;
			fsc->bRepeat = 1;
		}

		if (fsc->iIter > 999){
			HandleWarnings(&sv->sInfo);
			traceError("\nError: Cycle in Event Iteration!\n", &sv->sInfo);
			fsc->state = _STATE_CYCLE_IN_EVENT_ITERATION;
			return fsc->state;
		}

#if defined _ROOT_MESSAGE_SCREEN && defined _EVENT_STEP
		if (((sv->t >= _ROOT_PROT_BEGIN[0])&&(sv->t <= _ROOT_PROT_END[0])) || ((sv->t >= _ROOT_PROT_BEGIN[1])&&(sv->t <= _ROOT_PROT_END[1])) || ((sv->t >= _ROOT_PROT_BEGIN[2])&&(sv->t <= _ROOT_PROT_END[2])))
			fprintf(stdout, "Event Step:\t%d\n", fsc->iIter);
#endif
#if defined _ROOT_MESSAGE_FILE && defined _EVENT_STEP
		if (((sv->t >= _ROOT_PROT_BEGIN[0])&&(sv->t <= _ROOT_PROT_END[0])) || ((sv->t >= _ROOT_PROT_BEGIN[1])&&(sv->t <= _ROOT_PROT_END[1])) || ((sv->t >= _ROOT_PROT_BEGIN[2])&&(sv->t <= _ROOT_PROT_END[2])))
			fprintf(roots, "Event Step:\t%d\n", fsc->iIter);
#endif

	}while (fsc->iIter<1000 && fsc->bRepeat);

	sv->sInfo.tracingAllowed = 0;
	sv->szf = sv->oszf;
	Update_pre_zf(sv->zf, sv->pre_zf, sv->size.izf);
	ResetSCCounter(sv);

	/*Last Values get the current values*/
	fsd->model.fpartitions[0].AssignLastVar(sv, sd);
	UpdateDelayBuffers(sv->db, fsd->pData.size.idb);
	UpdateHystCurves(sv->hcs, fsd->pData.size.ihcs);
	HandleAssertWarnings(&sv->sInfo);

	if(!fsd->pData.sInfo.applyHysteresis){
		fsd->pData.sInfo.applyHysteresis = 1;
		UpdateEpsilonZF(&fsd->pData);
	}

	sv->sInfo.bDPAllowed = 0;
	sv->sInfo.isEvent = 0;
	fsc->bDPHappendInEventiteration = 0;

	fsd->pData.sInfo.bSolverNeedsReset = bSolverNeedsReset;

	if(fsd->pData.sInfo.iTerminate==1)
		return _STATE_TERMINATED;
	else
		return _STATE_SUCCESS_CONTINUE;
}

static void Euphor_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;
#ifdef _JOURNAL
	ITI_real der;
#endif

	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[0][k] = fsc->dt * sv->xdot[k];
			sv->x[k] += fsc->xw[0][k];
		}
#if defined(_JOURNAL) && defined(SLOW_DENORMAL)
		else
			fsc->xw[0][k] = 0.0;
#endif
	}

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}

	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls++;

#ifdef _JOURNAL
	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			der -= fsc->xw[0][k];
			fsd->stat.dblInfluence[k] += fabs(der)/2.0/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
		}
	}
#endif
}

static void EuphorMin_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;
#ifdef _JOURNAL
	ITI_real der;
#endif

	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[0][k] = fsc->dt * sv->xdot[k];
			sv->x[k] += fsc->xw[0][k];
		}
#if defined(_JOURNAL) && defined(SLOW_DENORMAL)
		else
			fsc->xw[0][k] = 0.0;
#endif
	}

	for (k = 0; k < sv->smm->nMin; k++) {
		if (sv->x[sv->smm->minInd[k]] <= sv->smm->minVal[k])
			sv->x[sv->smm->minInd[k]] = sv->smm->minVal[k];
	}
	for (k = 0; k < sv->smm->nMax; k++) {
		if (sv->x[sv->smm->maxInd[k]] >= sv->smm->maxVal[k])
			sv->x[sv->smm->maxInd[k]] = sv->smm->maxVal[k];
	}

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls++;

#ifdef _JOURNAL
	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			der -= fsc->xw[0][k];
			fsd->stat.dblInfluence[k] += fabs(der)/2.0/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
		}
	}
#endif
}

static void ITI_FixStep_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;

	for (k = 0; k < sv->size.ix; k++)
	{
		ITI_real der;
		fsc->xw[2][k] = sv->x[k];
		fsc->xw[0][k] = sv->xdot[k];

		der = fsc->dt * (fsc->xw[0][k] + fsc->xw[1][k] / 2.0);
#ifdef SLOW_DENORMAL
		if (fabs(der) > 1.E-300)
#endif
			sv->x[k] += der;
	}

#ifdef _JOURNAL
	if (fsc->bReInit == 0)
	{
		for (k = 0; k < sv->size.ix; k++)
		{
#ifdef SLOW_DENORMAL
			if (fabs(sv->xdot[k]) > 1.E-300)
#endif
			{
				ITI_real der = fsc->dt * sv->xdot[k];
				fsc->xw[2][k] += der;
			}

			fsc->xw[2][k] -= sv->x[k];
			fsc->xw[2][k] = fabs(fsc->xw[2][k]);
			fsd->stat.dblInfluence[k] += fsc->xw[2][k] / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
		}
	}
#endif
	if (fsc->bReInit == 0)
		sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	if (fsc->bReInit == 0 && fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls++;
}

static void ITI_FixStepMin_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;

	for (k = 0; k < sv->size.ix; k++)
	{
		ITI_real der;
		fsc->xw[2][k] = sv->x[k];
		fsc->xw[0][k] = sv->xdot[k];

		der = fsc->dt * (fsc->xw[0][k] + fsc->xw[1][k] / 2.0);
#ifdef SLOW_DENORMAL
		if (fabs(der) > 1.E-300)
#endif
			sv->x[k] += der;
	}

	for (k = 0; k < sv->smm->nMin; k++) {
		if (sv->x[sv->smm->minInd[k]] <= sv->smm->minVal[k])
			sv->x[sv->smm->minInd[k]] = sv->smm->minVal[k];
	}
	for (k = 0; k < sv->smm->nMax; k++) {
		if (sv->x[sv->smm->maxInd[k]] >= sv->smm->maxVal[k])
			sv->x[sv->smm->maxInd[k]] = sv->smm->maxVal[k];
	}

#ifdef _JOURNAL
	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			ITI_real der = fsc->dt * sv->xdot[k];
			fsc->xw[2][k] += der;
		}

		fsc->xw[2][k] -= sv->x[k];
		fsc->xw[2][k] = fabs(fsc->xw[2][k]);
		fsd->stat.dblInfluence[k] += fsc->xw[2][k] / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
	}
#endif

	if (fsc->bReInit == 0)
		sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);

	if (fsc->bReInit == 0 && fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}

	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls++;
	ReleaseAllMemory(&sd->currMem);
}

static void ITI_FixStep_PostIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_int k;

	if (sv->sInfo.bSolverNeedsReset == 0) {
		for (k = 0; k < sv->size.ix; k++)
			fsc->xw[1][k] = sv->xdot[k] - fsc->xw[0][k];
	}
	else
	{
		for (k = 0; k < sv->size.ix; k++)
			fsc->xw[1][k] = 0;
	}
}

static void ITI_FixStep_Reinit(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;

	for (k = 0; k < sv->size.ix; k++)
	{
		ITI_real der;
		sv->x[k] = fsc->xw[2][k];
		der = fsc->dt * (sv->xdot[k] + fsc->xw[0][k])/2.0;
#ifdef SLOW_DENORMAL
		if (fabs(der) > 1.E-300)
#endif
			sv->x[k] += der;
	}

#ifdef _JOURNAL
	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			ITI_real der = fsc->dt * sv->xdot[k];
			fsc->xw[2][k] += der;
		}

		fsc->xw[2][k] -= sv->x[k];
		fsc->xw[2][k] = fabs(fsc->xw[2][k]);
		fsd->stat.dblInfluence[k] += fsc->xw[2][k] / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
	}
#endif

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		fsd->model.ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls++;
	ReleaseAllMemory(&sd->currMem);
}

static void Rkfh_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;

	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[0][k] = sv->xdot[k];
			sv->x[k] += fsc->dt * fsc->xw[0][k];
		}
#ifdef SLOW_DENORMAL
		else
			fsc->xw[0][k] = 0.0;
#endif
	}

	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	for (k=0; k<sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			ITI_real der = fsc->dt * (sv->xdot[k] - fsc->xw[0][k]);
			sv->x[k] += der/2.0;

#ifdef _JOURNAL
			fsd->stat.dblInfluence[k] += fabs(der)/2.0/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#ifdef SLOW_DENORMAL
		else
		{
			ITI_real der = fsc->dt * fsc->xw[0][k]/2.0;
			sv->x[k] -= der;

#ifdef _JOURNAL
			fsd->stat.dblInfluence[k] += fabs(der)/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#endif
	}

	sv->sInfo.iTerminate = 0;

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}

	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls +=2;
	ReleaseAllMemory(&sd->currMem);
}

static void RkfhMin_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_int k;

	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[0][k] = sv->xdot[k];
			sv->x[k] += fsc->dt * fsc->xw[0][k];
		}
#ifdef SLOW_DENORMAL
		else
			fsc->xw[0][k] = 0.0;
#endif
	}

	for (k = 0; k < sv->smm->nMin; k++) {
		if (sv->x[sv->smm->minInd[k]] <= sv->smm->minVal[k])
			sv->x[sv->smm->minInd[k]] = sv->smm->minVal[k];
	}
	for (k = 0; k < sv->smm->nMax; k++) {
		if (sv->x[sv->smm->maxInd[k]] >= sv->smm->maxVal[k])
			sv->x[sv->smm->maxInd[k]] = sv->smm->maxVal[k];
	}

	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	for (k = 0; k < sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			ITI_real der = fsc->dt * (sv->xdot[k] - fsc->xw[0][k]);
			sv->x[k] += (der / 2.0) * fsc->xw[1][k];

#ifdef _JOURNAL
			fsd->stat.dblInfluence[k] += fabs(der)/2.0/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#ifdef SLOW_DENORMAL
		else
		{
			ITI_real der = fsc->dt * fsc->xw[0][k]/2.0;
			sv->x[k] -= der * fsc->xw[1][k];

#ifdef _JOURNAL
			fsd->stat.dblInfluence[k] += fabs(der)/(fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#endif
	}

	sv->sInfo.iTerminate = 0;

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls += 2;
	ReleaseAllMemory(&sd->currMem);
}

static void Rkf23_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_real der;
	ITI_int k;
	ITI_real tTmp = sv->t;

	for (k = 0; k < sv->size.ix; k++)
	{
		fsc->xw[0][k] = sv->x[k];
		fsc->xw[1][k] = sv->x[k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[2][k] = fsc->dt * sv->xdot[k];
			fsc->xw[0][k] += fsc->xw[2][k]/6.0;
			fsc->xw[1][k] += fsc->xw[2][k]/4.0;
			sv->x[k] += fsc->xw[2][k];
		}
	}

	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[1][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			fsc->xw[0][k] += der/6.0;
			sv->x[k] += der/4.0;

#ifdef _JOURNAL
			fsc->xw[2][k] += der;
#endif
		}
	}

	sv->t -= fsc->dt/2.0;
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);
	sv->t = tTmp;

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[0][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			fsc->xw[1][k] = fsc->dt * sv->xdot[k];
			sv->x[k] += 2.0*fsc->xw[1][k]/3.0;

#ifdef _JOURNAL
			fsc->xw[2][k] -= 2.0*fsc->xw[1][k];
			fsc->xw[2][k] = fabs(fsc->xw[2][k])/3.0;
			fsd->stat.dblInfluence[k] += fsc->xw[2][k] / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#ifdef SLOW_DENORMAL
		else
		{
#ifdef _JOURNAL
			fsc->xw[2][k] = fabs(fsc->xw[2][k])/3.0;
			fsd->stat.dblInfluence[k] += fsc->xw[2][k] / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
#endif
		}
#endif
	}

	sv->sInfo.iTerminate = 0;

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

	fsd->stat.iRhsCalls +=3;
	ReleaseAllMemory(&sd->currMem);
}

#define A21 (0.2)
#define A31 (3.0/40.0)
#define A32 (9.0/40.0)
#define A41 (44.0/45.0)
#define A42 (-56.0/15.0)
#define A43 (32.0/9.0)
#define A51 (19372.0/6561.0)
#define A52 (-25360.0/2187.0)
#define A53 (64448.0/6561.0)
#define A54 (-212.0/729.0)
#define A61 (9017.0/3168.0)
#define A62 (-355.0/33.0)
#define A63 (46732.0/5247.0)
#define A64 (49.0/176.0)
#define A65 (-5103.0/18656.0)
#define A71 (35.0/384.0)
#define A73 (500.0/1113.0)
#define A74 (125.0/192.0)
#define A75 (-2187.0/6784.0)
#define A76 (11.0/84.0)
#ifdef _JOURNAL
#define B1 (5179.0/57600.0)
#define B3 (7571.0/16695.0)
#define B4 (393.0/640.0)
#define B5 (-92097.0/339200.0)
#define B6 (187.0/2100.0)
#endif

static void Dopri5_DoIntegration(void* pData)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;
	ITI_SimVar* sv = &fsd->pData;
	ITI_SimData* sd = &fsd->data;
	ITI_real der;
	ITI_int k;
	ITI_real tTmp = sv->t;

	for (k = 0; k < sv->size.ix; k++)
	{
		fsc->xw[0][k] = sv->x[k];
		fsc->xw[1][k] = sv->x[k];
		fsc->xw[2][k] = sv->x[k];
		fsc->xw[3][k] = sv->x[k];
		fsc->xw[4][k] = sv->x[k];
#ifdef _JOURNAL
		fsc->xw[5][k] = sv->x[k];
#endif

#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A21;
			fsc->xw[0][k] += der*A31;
			fsc->xw[1][k] += der*A41;
			fsc->xw[2][k] += der*A51;
			fsc->xw[3][k] += der*A61;
			fsc->xw[4][k] += der*A71;
#ifdef _JOURNAL
			fsc->xw[5][k] += der*B1;
#endif
		}
	}

	sv->t -= fsc->dt*0.8;
	fsc->bError = fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);
	sv->t = tTmp;

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[0][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A32;
			fsc->xw[1][k] += der*A42;
			fsc->xw[2][k] += der*A52;
			fsc->xw[3][k] += der*A62;
		}
	}

	sv->t -= fsc->dt*0.7;
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);
	sv->t = tTmp;

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[1][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A43;
			fsc->xw[2][k] += der*A53;
			fsc->xw[3][k] += der*A63;
			fsc->xw[4][k] += der*A73;
#ifdef _JOURNAL
			fsc->xw[5][k] += der*B3;
#endif
		}
	}

	sv->t -= fsc->dt/5.0;
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);
	sv->t = tTmp;

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[2][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A54;
			fsc->xw[3][k] += der*A64;
			fsc->xw[4][k] += der*A74;
#ifdef _JOURNAL
			fsc->xw[5][k] += der*B4;
#endif
		}
	}

	sv->t -= fsc->dt/9.0;
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);
	sv->t = tTmp;

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[3][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A65;
			fsc->xw[4][k] += der*A75;
#ifdef _JOURNAL
			fsc->xw[5][k] += der*B5;
#endif
		}
	}

	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	ReleaseAllMemory(&sd->currMem);

	for (k = 0; k < sv->size.ix; k++)
	{
		sv->x[k] = fsc->xw[4][k];
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsc->dt * sv->xdot[k];
			sv->x[k] += der*A76;
#ifdef _JOURNAL
			fsc->xw[5][k] += der*B6;
#endif
		}
	}

	sv->sInfo.iTerminate = 0;

	sv->sInfo.strAnalysisTypeDetail = "validStep";
	fsc->bError += fsd->model.fpartitions[0].CalcDerivatives(sv, sd);
	fsd->stat.iRhsCalls +=6;
	ReleaseAllMemory(&sd->currMem);

	if (fsc->bError == 0) {
		sv->sInfo.strAnalysisTypeDetail = "validStep";
		fsc->bError = fsd->model.fpartitions[0].ValidStep(sv, NULL, NULL, sd);
		ReleaseAllMemory(&sd->currMem);
	}
	sv->sInfo.strAnalysisTypeDetail = "residuals";

#ifdef _JOURNAL
	for (k = 0; k <sv->size.ix; k++)
	{
#ifdef SLOW_DENORMAL
		if (fabs(sv->xdot[k]) > 1.E-300)
#endif
		{
			der = fsd->ss.dtMin * sv->xdot[k];
			fsc->xw[5][k] += der/40.0;
		}
		fsc->xw[5][k] -= sv->x[k];
		fsd->stat.dblInfluence[k] += fabs(fsc->xw[5][k]) / (fsd->ss.absTol + fabs(sv->x[k]) * fsd->ss.relTol);
	}
#endif
}

void Set_t_pneAux_rebuild_generic_std_sf(void* pData, ITI_real t)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	ITI_FixStepContext* fsc = &fsd->fsc;

	ITI_bi_setreal(&(fsc->i_t), t, fsd->ss.dtMin);
	fsd->pData.t = ITI_bi_getreal(&(fsc->i_t), fsd->ss.dtMin);
}

static ITI_uint CheckMinMax(ITI_SimVar *sv)
{
	ITI_int i;

	for (i = 0; i < sv->smm->nMin; i++) {
		if (sv->x[sv->smm->minInd[i]] < sv->smm->minVal[i]) {
			ITI_char msg[255];
			sprintf(msg, "t=%.16g: the value %-.17g is below the minimum (%-.17g) of the state(%d).\n", sv->t, sv->x[sv->smm->minInd[i]], sv->smm->minVal[i], sv->smm->minInd[i]);
			traceWarning(msg, &sv->sInfo);
			return 1;
		}
	}
	for (i = 0; i < sv->smm->nMax; i++) {
		if (sv->x[sv->smm->maxInd[i]] > sv->smm->maxVal[i]) {
			ITI_char msg[255];
			sprintf(msg, "t=%.16g: the value %-.17g exceeds the maximum (%-.17g) of the state(%d).\n", sv->t, sv->x[sv->smm->maxInd[i]], sv->smm->maxVal[i], sv->smm->maxInd[i]);
			traceWarning(msg, &sv->sInfo);
			return 1;
		}
	}

	return 0;
}

void SetContainerData_pneAux_rebuild_generic_std_sf(void* pData, void* pContainer)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;

	/*fsc->pContainer=pContainer;*/
	fsd->pData.sInfo.pContainer=pContainer;
}

void* GetContainerData_pneAux_rebuild_generic_std_sf(void* pData)
{
	return ((ITI_FixStepData*)pData)->pData.sInfo.pContainer;
}

void SetResourceFolder_FixStep_pneAux_rebuild_generic_std_sf(void* pData, ITI_char* strFolder)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;
	SetResourceFolder(&fsd->pData, strFolder);
}

void SetTraceCallback_pneAux_rebuild_generic_std_sf(void* pData, TRACE_FUNC* p)
{
	ITI_FixStepData* fsd = (ITI_FixStepData*)pData;

	fsd->pData.sInfo.trace = p;
}

#ifdef ITI_CE_ETAS_LABCAR

_ITI_INLINE double* Get_yReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.y.realData;
}

_ITI_INLINE int* Get_yInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.y.intData;
}

_ITI_INLINE double* Get_pReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.p.realData;
}

_ITI_INLINE int* Get_pInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.p.intData;
}

_ITI_INLINE double* Get_uReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.u.realData;
}

_ITI_INLINE int* Get_uInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData)
{
	return pData->pData.u.intData;
}

#endif
