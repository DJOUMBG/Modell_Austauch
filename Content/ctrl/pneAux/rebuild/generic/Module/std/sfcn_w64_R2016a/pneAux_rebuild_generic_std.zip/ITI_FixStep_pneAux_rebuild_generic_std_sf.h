#if !defined(_ITI_FixStep)
#define _ITI_FixStep

#include "ITI_Types.h"
#include "ITI_big_uint.h"

/* fixed step solvers */
#define EULER (0)
#define ITI_STANDARD (1)
#define HEUN (2)
#define RKF23 (3)
#define DOPRI5 (4)

typedef void (*DoIntegrationFunc)(void* pData);
typedef void (*PostIntegrationFunc)(void* pData);
typedef void (*ReinitFunc)(void* pData);

#define _STATE_TERMINATED 2
#define _STATE_SUCCESS_CONTINUE 1
#define _STATE_SUCCESS_END 0
#define _STATE_ERROR -1
#define _STATE_CYCLE_IN_EVENT_ITERATION -2
#define _STATE_ERROR_IN_INITIALIZATION -3
#define _STATE_ERROR_IN_INITIALIZATION_AFTERDISCONTINUITY -4
#define _STATE_CYCLE_IN_EVENT_ITERATION_AT_START -5
#define _STATE_ERROR_CREATE_INSTANCE -6
#define _STATE_ERROR_IN_ON_SET_INPUTS -7

/*
typedef struct ITI_ModelStatic {
	ITI_parameterData* parameters;
	ITI_outputData* outputData;
	ITI_inputData* inputData;
	ITI_CurveSetData* curveSets;
	ITI_CurveData_ND* curveNDs;
	ITI_VarAttributes* stateAttributes;
	ITI_BlockSizes *blockSizes;
	ITI_int *numJacColsData;
	ITI_uint* seqCsSizes;
	ITI_DelayInfo* delayInfos;
}ITI_ModelStatic;
*/
typedef struct ITI_FixStepContext {
	ITI_real** xw;
	ITI_uint iw;

	double dt;
	ITI_bi i_t;
	ITI_bui ui_dt;
	ITI_bui ui_Steps;
	ITI_bui ui_IntSteps;
	ITI_bui ui_IntStep_Counter;

	ITI_int isvMax;

	ITI_bui* timeEventMax;
	ITI_bui* timeEventCounter;

	ITI_real* prezf_tmp;

	ITI_uint bReInit;
	ITI_uint bAtStart;

	ITI_uint bError;

	ITI_int state;
	ITI_real* old_sign_zf;

	ITI_uint iIter;
	ITI_uint bRepeat;
	ITI_uint bTimeEvent;
	ITI_uint bZeroFunc;
	ITI_uint bTerminateRequired;

	ITI_int bDPHappendInEventiteration;

	DoIntegrationFunc DoIntegration;
	PostIntegrationFunc PostIntegration;
	ReinitFunc Reinit;
}ITI_FixStepContext;

typedef struct ITI_FixStepData {
	ITI_Model model;
	ITI_SimVar pData;
	ITI_SimData data;
	ITI_SolverSettings ss;
	ITI_SolverStatistic stat;
	ITI_FixStepContext fsc;
}ITI_FixStepData;

#define GetParameterData(pData) \
	(((ITI_FixStepData*)pData)->model.parameters)

#define GetInputData(pData) \
	(((ITI_FixStepData*)pData)->model.inputData)

#define GetOutputData(fsData) \
	(((ITI_FixStepData*)fsData)->model.outputData)

#define GetSizeY(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.iy_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_str))

#define GetSimVar(fsData) \
	(&((ITI_FixStepData*)fsData)->pData)

#define GetSimData(fsData) \
	(&((ITI_FixStepData*)fsData)->data)
#define Get_size_x(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ix)

#define GetSize_u_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.iu_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.iu_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.iu_str))
#define Get_size_u_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.iu_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.iu_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.iu_str))
#define Get_size_u(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_real)
#define Get_size_u_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_int)
#define Get_size_u_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_str)

#define Get_size_v_real(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iv_real)
#define Get_size_v_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iv_int)
#define Get_size_v_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iv_str)

#define Get_size_z_real(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iz_real)
#define Get_size_z_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iz_int)
#define Get_size_z_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iz_str)

#define Get_size_u_real(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_real)
#define Get_size_u_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_int)
#define Get_size_u_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iu_str)

#define GetSize_y_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.iy_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_str))

#define Get_size_y_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.iy_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.iy_str))

#define Get_size_y(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iy_real)

#define Get_size_y_real(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iy_real)
#define Get_size_y_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iy_int)
#define Get_size_y_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.iy_str)

#define Get_size_p(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ip_real)

#define Get_size_p_real(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ip_real)
#define Get_size_p_int(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ip_int)
#define Get_size_p_str(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ip_str)
#define GetSize_p_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.ip_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.ip_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.ip_str))
#define Get_size_p_allTypes(fsData) \
	((((ITI_FixStepData*)fsData)->pData.size.ip_real) + \
	(((ITI_FixStepData*)fsData)->pData.size.ip_int) + \
	(((ITI_FixStepData*)fsData)->pData.size.ip_str))
#define Get_size_p_arr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.size.ip_arr)

#define Get_dtProtMin(pData) \
	(((ITI_FixStepData*)pData)->ss.dtProtMin)
#define Get_dtMin(pData) \
	(((ITI_FixStepData*)pData)->ss.dtMin)

#define Get_u(fsData) \
	(((ITI_FixStepData*)fsData)->pData.u)
#define Get_y(fsData) \
	(((ITI_FixStepData*)fsData)->pData.y)
#define Get_p(fsData) \
	(((ITI_FixStepData*)fsData)->pData.p)

#ifdef ITI_CE_ETAS_LABCAR
_ITI_INLINE double* Get_uReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);
_ITI_INLINE int* Get_uInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);

_ITI_INLINE double* Get_yReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);
_ITI_INLINE int* Get_yInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);

_ITI_INLINE double* Get_pReal_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);
_ITI_INLINE int* Get_pInt_pneAux_rebuild_generic_std_sf(ITI_FixStepData* pData);
#else
#define Get_uReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.u.realData)
#define Get_uInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.u.intData)
#define Get_yReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.y.realData)
#define Get_yInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.y.intData)
#define Get_pReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.p.realData)
#define Get_pInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.p.intData)
#endif

#define Get_uStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.u.strData)
#define Get_yStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.y.strData)
#define Get_pStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.p.strData)

#define Get_vReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.v.realData)
#define Get_vInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.v.intData)
#define Get_vStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.v.strData)

#define Get_z(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z)
#define Get_zReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.realData)
#define Get_zInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.intData)
#define Get_zStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.strData)
#define Get_zStrsize(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.strSize)

#define Get_pre_z(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z)
#define Get_pre_zReal(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.realData)
#define Get_pre_zInt(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.intData)
#define Get_pre_zStr(fsData) \
	(((ITI_FixStepData*)fsData)->pData.z.strData)
#define Get_pre_zStrsize(fsData) \
	(((ITI_FixStepData*)fsData)->pData.pre_z.strSize)

#define Get_x(fsData) \
	(((ITI_FixStepData*)fsData)->pData.x)
#define Get_dx(fsData) \
	(((ITI_FixStepData*)fsData)->pData.xdot )
#define Get_t(fsData) \
	(((ITI_FixStepData*)fsData)->pData.t)

#define Get_Comp_u(fsData) \
	(&((ITI_FixStepData*)fsData)->pData.u)

#define Get_TerminateState(fsData) \
	((((ITI_FixStepData*)fsData)->pData.sInfo.iTerminate) || (((ITI_FixStepData*)fsData)->fsc.bError))

#define Get_TerminateStateOnly(fsData) \
	(((ITI_FixStepData*)fsData)->pData.sInfo.iTerminate)

#define Get_ErrorState(pData) \
	(((ITI_FixStepData*)pData)->fsc.bError)

#define Get_TraceString(fsData) \
	(((ITI_FixStepData*)fsData)->pData.sInfo.strTrace)

#define Is_TraceStringAvailable(pData) \
	(strlen(Get_TraceString(pData)) > 0)

#define Clear_TraceString(pData) \
	strcpy(Get_TraceString(pData), "")

int CreateSolverInstance_pneAux_rebuild_generic_std_sf(void** pData, int nParams, double* pValues);
int InitializeModel_pneAux_rebuild_generic_std_sf(void* pData);
int InitializeConditionsModel_pneAux_rebuild_generic_std_sf(void* pData);
int InitializeConditionsModelOnly_pneAux_rebuild_generic_std_sf(void* pData);
int InitializeConditionsModelFinish_pneAux_rebuild_generic_std_sf(void* pData);
int SetSolverSettings_pneAux_rebuild_generic_std_sf(void* pData, ITI_SolverSettings* settings);
int SetRealParameters_pneAux_rebuild_generic_std_sf(void* pData, int nParam, double* param);
int SetTiming_pneAux_rebuild_generic_std_sf(void* pData, ITI_real tStart, ITI_real tStop, ITI_real dt, ITI_real dtProt);
int Set_dtProt_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtProt);
int Set_dt_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtMin, ITI_real dtProt);
int Set_dtMin_pneAux_rebuild_generic_std_sf(void* pData, ITI_real dtMin);
void CalcOneStep_pneAux_rebuild_generic_std_sf(void* pData);
int EventIteration_pneAux_rebuild_generic_std_sf(void* pData);
void CalcModelOutputs_pneAux_rebuild_generic_std_sf(void* pData);
void CalcDerivativesAndModelOutputs_pneAux_rebuild_generic_std_sf(void* pData);
int TerminateModel_pneAux_rebuild_generic_std_sf(void* pData);
void PrintSolverStatistics_pneAux_rebuild_generic_std_sf(void* pData);
void PrintSolverStatistics_str_pneAux_rebuild_generic_std_sf(void* pData, char* strBuff);
void FreeSolverInstance_pneAux_rebuild_generic_std_sf(void* pData);
void Set_t_pneAux_rebuild_generic_std_sf(void* pData, ITI_real t);

void GetModelName_pneAux_rebuild_generic_std_sf(void* pData, char* strName);
void GetIntegratorName_pneAux_rebuild_generic_std_sf(void* pData, int iMode, char* strName);

void SetContainerData_pneAux_rebuild_generic_std_sf(void* pData, void* pContainer);
void* GetContainerData_pneAux_rebuild_generic_std_sf(void* pData);
void SetTraceCallback_pneAux_rebuild_generic_std_sf(void* pData, TRACE_FUNC* p);

void SetResourceFolder_FixStep_pneAux_rebuild_generic_std_sf(void* pData, ITI_char* strFolder);

#if !defined ITI_DSPACE && !defined ITI_NI_RT && !defined ITI_SCALERT && !defined ITI_SFuncSolver && !defined ITI_CE_ETAS_LABCAR
int ITI_FixStep(ITI_SolverSettings* settings, int nParams, double* pValues, int iVariation, SetInputsFunc SetInputs, char *outputFileName);
#endif

#endif
