Inputs: 
u[0]	... Signal Input (pneAux.env_Temperature)
u[1]	... Signal Input (pneAux.ActlEngPctTrq_Cval)
u[2]	... Signal Input (pneAux.aSatpAutoOpMd_Cmd_SDS)
u[3]	... Signal Input (pneAux.BS_PB_Fct_Rq)
u[4]	... Signal Input (pneAux.ch_Clutch_Stat_CPC)
u[5]	... Signal Input (pneAux.drv_PB_Sw_Stat_SATP)
u[6]	... Signal Input (pneAux.drv_Trlr_Air_Sup_Sw_Stat)
u[7]	... Signal Input (pneAux.EngRPM_Cval_CPC3)
u[8]	... Signal Input (pneAux.pne_MTBmodusSwAllowed)
u[9]	... Signal Input (pneAux.drv_DrS_Rq)
u[10]	... Signal Input (pneAux.drv_Knl_Rq)
u[11]	... Signal Input (pneAux.drv_PkBrk)
u[12]	... Signal Input (pneAux.drv_PkBrkLever_pos)
u[13]	... Signal Input (pneAux.hvs_AirCompressor_nEmot)
u[14]	... Signal Input (pneAux.hvs_InverterAirCompressor_hvCurrent)
u[15]	... Signal Input (pneAux.hvs_InverterAirCompressor_hvVoltage)
u[16]	... Signal Input (pneAux.mec_veh_AxleLoad1)
u[17]	... Signal Input (pneAux.mec_veh_AxleLoad2)
u[18]	... Signal Input (pneAux.mec_veh_AxleLoad3)
u[19]	... Signal Input (pneAux.mec_veh_AxleLoad4)
u[20]	... Signal Input (pneAux.mec_veh_TrailerAxleLoad1)
u[21]	... Signal Input (pneAux.mec_veh_TrailerAxleLoad2)
u[22]	... Signal Input (pneAux.mec_veh_TrailerAxleLoad3)
u[23]	... Signal Input (pneAux.mec_veh_transVel)
u[24]	... Signal Input (pneAux.pne_brk_Axle1_torque_sns)
u[25]	... Signal Input (pneAux.pne_brk_Axle2_torque_sns)
u[26]	... Signal Input (pneAux.pne_brk_Axle3_torque_sns)
u[27]	... Signal Input (pneAux.pne_brk_Axle4_torque_sns)
u[28]	... Signal Input (pneAux.pne_brk_BrkWearAALt)
u[29]	... Signal Input (pneAux.pne_brk_BrkWearAARt)
u[30]	... Signal Input (pneAux.pne_brk_BrkWearFA1Lt)
u[31]	... Signal Input (pneAux.pne_brk_BrkWearFA1Rt)
u[32]	... Signal Input (pneAux.pne_brk_BrkWearFA2Lt)
u[33]	... Signal Input (pneAux.pne_brk_BrkWearFA2Rt)
u[34]	... Signal Input (pneAux.pne_brk_BrkWearRA1Lt)
u[35]	... Signal Input (pneAux.pne_brk_BrkWearRA1Rt)
u[36]	... Signal Input (pneAux.pne_brk_BrkWearRA2Lt)
u[37]	... Signal Input (pneAux.pne_brk_BrkWearRA2Rt)
u[38]	... Signal Input (pneAux.pne_brk_CompON)
u[39]	... Signal Input (pneAux.pne_brk_pRelPkBrk)
u[40]	... Signal Input (pneAux.pne_brk_reg_active)
u[41]	... Signal Input (pneAux.pne_brk_rotVel_t1l)
u[42]	... Signal Input (pneAux.pne_brk_rotVel_t1r)
u[43]	... Signal Input (pneAux.pne_brk_rotVel_t2l)
u[44]	... Signal Input (pneAux.pne_brk_rotVel_t2r)
u[45]	... Signal Input (pneAux.pne_brk_rotVel_t3l)
u[46]	... Signal Input (pneAux.pne_brk_rotVel_t3r)
u[47]	... Signal Input (pneAux.pne_brk_Trailer_RV_Front_pAct)
u[48]	... Signal Input (pneAux.pne_brk_Trailer_RV_Rear_pAct)
u[49]	... Signal Input (pneAux.pne_brk_TrailerAxle1_BrakingForce_at8p5bar)
u[50]	... Signal Input (pneAux.pne_brk_TrailerAxle1_torque_sns)
u[51]	... Signal Input (pneAux.pne_brk_TrailerAxle2_BrakingForce_at8p5bar)
u[52]	... Signal Input (pneAux.pne_brk_TrailerAxle2_torque_sns)
u[53]	... Signal Input (pneAux.pne_brk_TrailerAxle3_BrakingForce_at8p5bar)
u[54]	... Signal Input (pneAux.pne_brk_TrailerAxle3_torque_sns)
u[55]	... Signal Input (pneAux.pne_brk_V1_pRel)
u[56]	... Signal Input (pneAux.pne_brk_V2_pRel)
u[57]	... Signal Input (pneAux.pne_brk_V4_pRel)
u[58]	... Signal Input (pneAux.pne_brk_V7_pRel)
u[59]	... Signal Input (pneAux.pne_brk_VTrailer_pRel)
u[60]	... Signal Input (pneAux.pne_brk_WetLvl_Cntr)
u[61]	... Signal Input (pneAux.pne_susp_A1_Le_Posn)
u[62]	... Signal Input (pneAux.pne_susp_A1_Ri_Posn)
u[63]	... Signal Input (pneAux.pne_susp_A2_Le_Posn)
u[64]	... Signal Input (pneAux.pne_susp_A2_Ri_Posn)
u[65]	... Signal Input (pneAux.pne_susp_A3_Le_Posn)
u[66]	... Signal Input (pneAux.pne_susp_A3_Ri_Posn)

Outputs: 
y[0]	... Signal Output (pneAux.pneAux_A1_Le_Rq)
y[1]	... Signal Output (pneAux.pneAux_A1_LoLi_Rq)
y[2]	... Signal Output (pneAux.pneAux_A1_Ri_Rq)
y[3]	... Signal Output (pneAux.pneAux_A2_Le_Rq)
y[4]	... Signal Output (pneAux.pneAux_A2_LoLi_Rq)
y[5]	... Signal Output (pneAux.pneAux_A2_Ri_Rq)
y[6]	... Signal Output (pneAux.pneAux_A3_Le_Rq)
y[7]	... Signal Output (pneAux.pneAux_A3_LoLi_Rq)
y[8]	... Signal Output (pneAux.pneAux_A3_Ri_Rq)
y[9]	... Signal Output (pneAux.pneAux_Axle1_load)
y[10]	... Signal Output (pneAux.pneAux_Axle2_load)
y[11]	... Signal Output (pneAux.pneAux_Axle3_load)
y[12]	... Signal Output (pneAux.pneAux_Axle4_load)
y[13]	... Signal Output (pneAux.pneAux_Drs_Rq)
y[14]	... Signal Output (pneAux.pneAux_EAPU_overrun)
y[15]	... Signal Output (pneAux.pneAux_pSoll_TCV_p43)
y[16]	... Signal Output (pneAux.pneAux_pSollPkBrk)
y[17]	... Signal Output (pneAux.pneAux_TCV_pDmd_Front_Left)
y[18]	... Signal Output (pneAux.pneAux_TCV_pDmd_Front_Right)
y[19]	... Signal Output (pneAux.pneAux_TCV_pDmd_Rear_Left)
y[20]	... Signal Output (pneAux.pneAux_TCV_pDmd_Rear_Right)
y[21]	... Signal Output (pneAux.pneAux_trailerAxle1_left_stABSInValve)
y[22]	... Signal Output (pneAux.pneAux_trailerAxle1_left_stABSOutValve)
y[23]	... Signal Output (pneAux.pneAux_trailerAxle1_load)
y[24]	... Signal Output (pneAux.pneAux_trailerAxle1_right_stABSInValve)
y[25]	... Signal Output (pneAux.pneAux_trailerAxle1_right_stABSOutValve)
y[26]	... Signal Output (pneAux.pneAux_trailerAxle2_left_stABSInValve)
y[27]	... Signal Output (pneAux.pneAux_trailerAxle2_left_stABSOutValve)
y[28]	... Signal Output (pneAux.pneAux_trailerAxle2_load)
y[29]	... Signal Output (pneAux.pneAux_trailerAxle2_right_stABSInValve)
y[30]	... Signal Output (pneAux.pneAux_trailerAxle2_right_stABSOutValve)
y[31]	... Signal Output (pneAux.pneAux_trailerAxle3_left_stABSInValve)
y[32]	... Signal Output (pneAux.pneAux_trailerAxle3_left_stABSOutValve)
y[33]	... Signal Output (pneAux.pneAux_trailerAxle3_load)
y[34]	... Signal Output (pneAux.pneAux_trailerAxle3_right_stABSInValve)
y[35]	... Signal Output (pneAux.pneAux_trailerAxle3_right_stABSOutValve)
y[36]	... Signal Output (pneAux.aAirComp_Stat_SATP)
y[37]	... Signal Output (pneAux.aAutoMd1To2Rdy_Stat_SATP)
y[38]	... Signal Output (pneAux.aAutoMd1To3Rdy_Stat_SATP)
y[39]	... Signal Output (pneAux.aAutoMd3To1Rdy_Stat_SATP)
y[40]	... Signal Output (pneAux.aAutoOpMd_Stat_SATP)
y[41]	... Signal Output (pneAux.aBrkAirPress1_Cval_SATP)
y[42]	... Signal Output (pneAux.aBrkAirPress1_Stat_SATP)
y[43]	... Signal Output (pneAux.aBrkAirPress2_Cval_SATP)
y[44]	... Signal Output (pneAux.aBrkAirPress2_Stat_SATP)
y[45]	... Signal Output (pneAux.aImplsblMdCmdErr_Stat_SATP)
y[46]	... Signal Output (pneAux.AirComp_Stat_SATP)
y[47]	... Signal Output (pneAux.AmbWarn_Rq_Trlr)
y[48]	... Signal Output (pneAux.AmbWarn_Rq_Trlr2)
y[49]	... Signal Output (pneAux.AmbWarn_Rq_Trlr3)
y[50]	... Signal Output (pneAux.AmbWarn_Rq_Trlr4)
y[51]	... Signal Output (pneAux.AmbWarn_Rq_Trlr5)
y[52]	... Signal Output (pneAux.aOverVoltPrim_Stat_SATP)
y[53]	... Signal Output (pneAux.API2_Inv2_RqSpd_Cval)
y[54]	... Signal Output (pneAux.aPrkBrk_ECUAir_SOH_SATP)
y[55]	... Signal Output (pneAux.aPrkBrk_ECUGen_SOH_SATP)
y[56]	... Signal Output (pneAux.aPrkBrk_SOH_SATP)
y[57]	... Signal Output (pneAux.aPrkBrkFltIntrlckMdChng_SATP)
y[58]	... Signal Output (pneAux.aPrkBrkIntrlckMdChng_SATP)
y[59]	... Signal Output (pneAux.aSdsIntfPrim_SOH_SATP)
y[60]	... Signal Output (pneAux.aTBL_LvrPosn_Cval)
y[61]	... Signal Output (pneAux.aTractorParkBrake_Status_SATP)
y[62]	... Signal Output (pneAux.aTrctrPrkBrk_AddInf_Cvl_SATP)
y[63]	... Signal Output (pneAux.aTrlr_Air_Supply_Press_Cval)
y[64]	... Signal Output (pneAux.aTrlr_Air_Supply_Stat)
y[65]	... Signal Output (pneAux.aTrlrSpplyLn_AddInf_Cvl_SATP)
y[66]	... Signal Output (pneAux.aUnderVoltPrim_Stat_SATP)
y[67]	... Signal Output (pneAux.AuxAirPress_Cval_SATP)
y[68]	... Signal Output (pneAux.AuxAirPress_Cval_Trlr)
y[69]	... Signal Output (pneAux.AuxAirPress_Stat_ICUC)
y[70]	... Signal Output (pneAux.AuxAirPress_Stat_SATP)
y[71]	... Signal Output (pneAux.aVehParkBrake_Status_SATP)
y[72]	... Signal Output (pneAux.aVehSpdIntrlckMdChng_SATP)
y[73]	... Signal Output (pneAux.BrkAirPress1_Cval_SATP)
y[74]	... Signal Output (pneAux.BrkAirPress1_Stat_ICUC)
y[75]	... Signal Output (pneAux.BrkAirPress1_Stat_SATP)
y[76]	... Signal Output (pneAux.BrkAirPress2_Cval_SATP)
y[77]	... Signal Output (pneAux.BrkAirPress2_Stat_ICUC)
y[78]	... Signal Output (pneAux.BrkAirPress2_Stat_SATP)
y[79]	... Signal Output (pneAux.BrkCylAirPres_FA_LW_Cval_Trlr)
y[80]	... Signal Output (pneAux.BrkCylAirPres_FA_RW_Cval_Trlr)
y[81]	... Signal Output (pneAux.BrkCylAirPres_SA_LW_Cval_Trlr)
y[82]	... Signal Output (pneAux.BrkCylAirPres_SA_RW_Cval_Trlr)
y[83]	... Signal Output (pneAux.BrkCylAirPres_TA_LW_Cval_Trlr)
y[84]	... Signal Output (pneAux.BrkCylAirPres_TA_RW_Cval_Trlr)
y[85]	... Signal Output (pneAux.BrkElCtrl_Stat_Trlr)
y[86]	... Signal Output (pneAux.BrkElCtrl_Stat_Trlr2)
y[87]	... Signal Output (pneAux.BrkElCtrl_Stat_Trlr3)
y[88]	... Signal Output (pneAux.BrkElCtrl_Stat_Trlr4)
y[89]	... Signal Output (pneAux.BrkElCtrl_Stat_Trlr5)
y[90]	... Signal Output (pneAux.BrkWearAALtWhl_Cval)
y[91]	... Signal Output (pneAux.BrkWearAARtWhl_Cval)
y[92]	... Signal Output (pneAux.BrkWearFA1LtWhl_Cval)
y[93]	... Signal Output (pneAux.BrkWearFA1RtWhl_Cval)
y[94]	... Signal Output (pneAux.BrkWearFA2LtWhl_Cval)
y[95]	... Signal Output (pneAux.BrkWearFA2RtWhl_Cval)
y[96]	... Signal Output (pneAux.BrkWearRA1LtWhl_Cval)
y[97]	... Signal Output (pneAux.BrkWearRA1RtWhl_Cval)
y[98]	... Signal Output (pneAux.BrkWearRA2LtWhl_Cval)
y[99]	... Signal Output (pneAux.BrkWearRA2RtWhl_Cval)
y[100]	... Signal Output (pneAux.DispPkBrkInd01_Rq_Stat)
y[101]	... Signal Output (pneAux.DispPkBrkInd02_Rq_Stat)
y[102]	... Signal Output (pneAux.DispPkBrkInd03_Rq_Stat)
y[103]	... Signal Output (pneAux.DispPkBrkInd04_Rq_Stat)
y[104]	... Signal Output (pneAux.DispPkBrkInd05_Rq_Stat)
y[105]	... Signal Output (pneAux.DispPkBrkInd06_Rq_Stat)
y[106]	... Signal Output (pneAux.DispPkBrkInd07_Rq_Stat)
y[107]	... Signal Output (pneAux.DispPkBrkInd08_Rq_Stat)
y[108]	... Signal Output (pneAux.DispPkBrkInd09_Rq_Stat)
y[109]	... Signal Output (pneAux.DispPkBrkInd10_Rq_Stat)
y[110]	... Signal Output (pneAux.DispPkBrkInd11_Rq_Stat)
y[111]	... Signal Output (pneAux.DispPkBrkInd12_Rq_Stat)
y[112]	... Signal Output (pneAux.DispPkBrkInd13_Rq_Stat)
y[113]	... Signal Output (pneAux.DispPkBrkInd14_Rq_Stat)
y[114]	... Signal Output (pneAux.DispPkBrkInd15_Rq_Stat)
y[115]	... Signal Output (pneAux.DispPkBrkInd16_Rq_Stat)
y[116]	... Signal Output (pneAux.DispPkBrkInd17_Rq_Stat)
y[117]	... Signal Output (pneAux.DispPkBrkInd18_Rq_Stat)
y[118]	... Signal Output (pneAux.ElComp_ActDischarge_Stat)
y[119]	... Signal Output (pneAux.ElComp_ActlSpd_Cval)
y[120]	... Signal Output (pneAux.ElComp_Backup_Rq)
y[121]	... Signal Output (pneAux.ElComp_CurrentCons_Cval)
y[122]	... Signal Output (pneAux.ElComp_PwrCons_Cval)
y[123]	... Signal Output (pneAux.ElComp_SpdMd_Stat)
y[124]	... Signal Output (pneAux.ElComp_Stat)
y[125]	... Signal Output (pneAux.ElComp_Volt_Cval)
y[126]	... Signal Output (pneAux.ElLoadProp_Stat_Trlr)
y[127]	... Signal Output (pneAux.ElLoadProp_Stat_Trlr2)
y[128]	... Signal Output (pneAux.ElLoadProp_Stat_Trlr3)
y[129]	... Signal Output (pneAux.ElLoadProp_Stat_Trlr4)
y[130]	... Signal Output (pneAux.ElLoadProp_Stat_Trlr5)
y[131]	... Signal Output (pneAux.PB_Sw_Stat_SATP)
y[132]	... Signal Output (pneAux.PB_Trlr_Ctrl_Stat)
y[133]	... Signal Output (pneAux.PBL_Fct_Stat)
y[134]	... Signal Output (pneAux.PBL_LvrPosn_Cval)
y[135]	... Signal Output (pneAux.PkB_TrlrAirPress_Stat_ICUC)
y[136]	... Signal Output (pneAux.PkBrk_Engg_Stat)
y[137]	... Signal Output (pneAux.PkBrk_Stat_EAPU)
y[138]	... Signal Output (pneAux.PkBrk_Stat_SCH)
y[139]	... Signal Output (pneAux.PkBrkPress_Cval)
y[140]	... Signal Output (pneAux.PressAir_Rq)
y[141]	... Signal Output (pneAux.PressAir_Rq_ICUC)
y[142]	... Signal Output (pneAux.PressAir_Rq_SATP)
y[143]	... Signal Output (pneAux.RedWarn_Rq_Trlr)
y[144]	... Signal Output (pneAux.RedWarn_Rq_Trlr2)
y[145]	... Signal Output (pneAux.RedWarn_Rq_Trlr3)
y[146]	... Signal Output (pneAux.RedWarn_Rq_Trlr4)
y[147]	... Signal Output (pneAux.RedWarn_Rq_Trlr5)
y[148]	... Signal Output (pneAux.SuspAirPress_Stat_SATP)
y[149]	... Signal Output (pneAux.TBL_LvrPosn_Cval)
y[150]	... Signal Output (pneAux.Trlr_Air_Sup_Sw_Stat)
y[151]	... Signal Output (pneAux.Trlr_Air_Supply_Press_Cval)
y[152]	... Signal Output (pneAux.VehABS_Stat_Trlr)
y[153]	... Signal Output (pneAux.VehSpd1_Cval_Trlr)
y[154]	... Signal Output (pneAux.WetLvlCntr_Cval_SATP)
y[155]	... Signal Output (pneAux.pneAux_mass_Tractor)
y[156]	... Signal Output (pneAux.pneAux_mass_Trailer)
y[157]	... Signal Output (pneAux.pneAux_SumBrakingForces_Tractor)
y[158]	... Signal Output (pneAux.pneAux_SumBrakingForces_Trailer)

Parameters: 
p[0]	... (pneAux.aAirComp_Stat_SATP_0)               0
p[1]	... (pneAux.aAutoMd1To2Rdy_Stat_SATP_0)               0
p[2]	... (pneAux.aAutoMd1To3Rdy_Stat_SATP_0)               0
p[3]	... (pneAux.aAutoMd3To1Rdy_Stat_SATP_0)               0
p[4]	... (pneAux.aAutoOpMd_Stat_SATP_0)               0
p[5]	... (pneAux.aBrkAirPress1_Cval_SATP_0)            2040
p[6]	... (pneAux.aBrkAirPress1_Stat_SATP_0)               3
p[7]	... (pneAux.aBrkAirPress2_Cval_SATP_0)            2040
p[8]	... (pneAux.aBrkAirPress2_Stat_SATP_0)               3
p[9]	... (pneAux.ActlEngPctTrq_Cval_0)               0
p[10]	... (pneAux.aImplsblMdCmdErr_Stat_SATP_0)               0
p[11]	... (pneAux.AirComp_Stat_SATP_0)               0
p[12]	... (pneAux.AmbWarn_Rq_Trlr2_0)               0
p[13]	... (pneAux.AmbWarn_Rq_Trlr3_0)               0
p[14]	... (pneAux.AmbWarn_Rq_Trlr4_0)               0
p[15]	... (pneAux.AmbWarn_Rq_Trlr5_0)               0
p[16]	... (pneAux.AmbWarn_Rq_Trlr_0)               0
p[17]	... (pneAux.aOverVoltPrim_Stat_SATP_0)               0
p[18]	... (pneAux.API2_Inv2_RqSpd_Cval_0)               0
p[19]	... (pneAux.aPrkBrk_ECUAir_SOH_SATP_0)               0
p[20]	... (pneAux.aPrkBrk_ECUGen_SOH_SATP_0)               0
p[21]	... (pneAux.aPrkBrk_SOH_SATP_0)               0
p[22]	... (pneAux.aPrkBrkFltIntrlckMdChng_SATP_0)               0
p[23]	... (pneAux.aPrkBrkIntrlckMdChng_SATP_0)               0
p[24]	... (pneAux.aSatpAutoOpMd_Cmd_SDS_0)               0
p[25]	... (pneAux.aSdsIntfPrim_SOH_SATP_0)               0
p[26]	... (pneAux.aTBL_LvrPosn_Cval_0)               0
p[27]	... (pneAux.ATBVehicleParameter)               0
p[28]	... (pneAux.aTractorParkBrake_Status_SATP_0)               0
p[29]	... (pneAux.aTrctrPrkBrk_AddInf_Cvl_SATP_0)               0
p[30]	... (pneAux.aTrlr_Air_Supply_Press_Cval_0)               0
p[31]	... (pneAux.aTrlr_Air_Supply_Stat_0)               0
p[32]	... (pneAux.aTrlrSpplyLn_AddInf_Cvl_SATP_0)               0
p[33]	... (pneAux.aUnderVoltPrim_Stat_SATP_0)               0
p[34]	... (pneAux.AuxAirPress_Cval_SATP_0)            2040
p[35]	... (pneAux.AuxAirPress_Cval_Trlr_0)            2040
p[36]	... (pneAux.AuxAirPress_Stat_ICUC_0)            2040
p[37]	... (pneAux.AuxAirPress_Stat_SATP_0)               3
p[38]	... (pneAux.aVehParkBrake_Status_SATP_0)               0
p[39]	... (pneAux.aVehSpdIntrlckMdChng_SATP_0)               0
p[40]	... (pneAux.BrkAirPress1_Cval_SATP_0)            2040
p[41]	... (pneAux.BrkAirPress1_Stat_ICUC_0)            2040
p[42]	... (pneAux.BrkAirPress1_Stat_SATP_0)               3
p[43]	... (pneAux.BrkAirPress2_Cval_SATP_0)            2040
p[44]	... (pneAux.BrkAirPress2_Stat_ICUC_0)            2040
p[45]	... (pneAux.BrkAirPress2_Stat_SATP_0)               3
p[46]	... (pneAux.BrkCylAirPres_FA_LW_Cval_Trlr_0)            1275
p[47]	... (pneAux.BrkCylAirPres_FA_RW_Cval_Trlr_0)            1275
p[48]	... (pneAux.BrkCylAirPres_SA_LW_Cval_Trlr_0)            1275
p[49]	... (pneAux.BrkCylAirPres_SA_RW_Cval_Trlr_0)            1275
p[50]	... (pneAux.BrkCylAirPres_TA_LW_Cval_Trlr_0)            1275
p[51]	... (pneAux.BrkCylAirPres_TA_RW_Cval_Trlr_0)            1275
p[52]	... (pneAux.BrkElCtrl_Stat_Trlr2_0)               0
p[53]	... (pneAux.BrkElCtrl_Stat_Trlr3_0)               0
p[54]	... (pneAux.BrkElCtrl_Stat_Trlr4_0)               0
p[55]	... (pneAux.BrkElCtrl_Stat_Trlr5_0)               0
p[56]	... (pneAux.BrkElCtrl_Stat_Trlr_0)               0
p[57]	... (pneAux.BrkWearAALtWhl_Cval_0)             102
p[58]	... (pneAux.BrkWearAARtWhl_Cval_0)             102
p[59]	... (pneAux.BrkWearFA1LtWhl_Cval_0)             102
p[60]	... (pneAux.BrkWearFA1RtWhl_Cval_0)             102
p[61]	... (pneAux.BrkWearFA2LtWhl_Cval_0)             102
p[62]	... (pneAux.BrkWearFA2RtWhl_Cval_0)             102
p[63]	... (pneAux.BrkWearRA1LtWhl_Cval_0)             102
p[64]	... (pneAux.BrkWearRA1RtWhl_Cval_0)             102
p[65]	... (pneAux.BrkWearRA2LtWhl_Cval_0)             102
p[66]	... (pneAux.BrkWearRA2RtWhl_Cval_0)             102
p[67]	... (pneAux.BS_PB_Fct_Rq_0)               0
p[68]	... (pneAux.ch_Clutch_Stat_CPC_0)               3
p[69]	... (pneAux.DispPkBrkInd01_Rq_Stat_0)               0
p[70]	... (pneAux.DispPkBrkInd02_Rq_Stat_0)               0
p[71]	... (pneAux.DispPkBrkInd03_Rq_Stat_0)               0
p[72]	... (pneAux.DispPkBrkInd04_Rq_Stat_0)               0
p[73]	... (pneAux.DispPkBrkInd05_Rq_Stat_0)               0
p[74]	... (pneAux.DispPkBrkInd06_Rq_Stat_0)               0
p[75]	... (pneAux.DispPkBrkInd07_Rq_Stat_0)               0
p[76]	... (pneAux.DispPkBrkInd08_Rq_Stat_0)               0
p[77]	... (pneAux.DispPkBrkInd09_Rq_Stat_0)               0
p[78]	... (pneAux.DispPkBrkInd10_Rq_Stat_0)               0
p[79]	... (pneAux.DispPkBrkInd11_Rq_Stat_0)               0
p[80]	... (pneAux.DispPkBrkInd12_Rq_Stat_0)               0
p[81]	... (pneAux.DispPkBrkInd13_Rq_Stat_0)               0
p[82]	... (pneAux.DispPkBrkInd14_Rq_Stat_0)               0
p[83]	... (pneAux.DispPkBrkInd15_Rq_Stat_0)               0
p[84]	... (pneAux.DispPkBrkInd16_Rq_Stat_0)               0
p[85]	... (pneAux.DispPkBrkInd17_Rq_Stat_0)               0
p[86]	... (pneAux.DispPkBrkInd18_Rq_Stat_0)               0
p[87]	... (pneAux.drv_DrS_Rq_0)               0
p[88]	... (pneAux.drv_Knl_Rq_0)               0
p[89]	... (pneAux.drv_PB_Sw_Stat_SATP_0)               0
p[90]	... (pneAux.drv_PkBrk_0)               0
p[91]	... (pneAux.drv_PkBrkLever_pos_0)               0
p[92]	... (pneAux.drv_Trlr_Air_Sup_Sw_Stat_0)               0
p[93]	... (pneAux.ElComp_ActDischarge_Stat_0)               0
p[94]	... (pneAux.ElComp_ActlSpd_Cval_0)               0
p[95]	... (pneAux.ElComp_Backup_Rq_0)               0
p[96]	... (pneAux.ElComp_CurrentCons_Cval_0)               0
p[97]	... (pneAux.ElComp_PwrCons_Cval_0)               0
p[98]	... (pneAux.ElComp_SpdMd_Stat_0)               2
p[99]	... (pneAux.ElComp_Stat_0)               0
p[100]	... (pneAux.ElComp_Volt_Cval_0)               0
p[101]	... (pneAux.ElLoadProp_Stat_Trlr2_0)               0
p[102]	... (pneAux.ElLoadProp_Stat_Trlr3_0)               0
p[103]	... (pneAux.ElLoadProp_Stat_Trlr4_0)               0
p[104]	... (pneAux.ElLoadProp_Stat_Trlr5_0)               0
p[105]	... (pneAux.ElLoadProp_Stat_Trlr_0)               0
p[106]	... (pneAux.EngRPM_Cval_CPC3_0)               0
p[107]	... (pneAux.env_Temperature_0)              20
p[108]	... (pneAux.epsLevel)               1
p[109]	... (pneAux.flagTrailerABS)               0
p[110]	... (pneAux.hvs_AirCompressor_nEmot_0)               0
p[111]	... (pneAux.hvs_InverterAirCompressor_hvCurrent_0)               0
p[112]	... (pneAux.hvs_InverterAirCompressor_hvVoltage_0)               0
p[113]	... (pneAux.kneelingLevel)               0
p[114]	... (pneAux.LP_rpmHigh)            4000
p[115]	... (pneAux.LP_rpmLow)            2000
p[116]	... (pneAux.mec_veh_AxleLoad1_0)               0
p[117]	... (pneAux.mec_veh_AxleLoad2_0)               0
p[118]	... (pneAux.mec_veh_AxleLoad3_0)               0
p[119]	... (pneAux.mec_veh_AxleLoad4_0)               0
p[120]	... (pneAux.mec_veh_TrailerAxleLoad1_0)               0
p[121]	... (pneAux.mec_veh_TrailerAxleLoad2_0)               0
p[122]	... (pneAux.mec_veh_TrailerAxleLoad3_0)               0
p[123]	... (pneAux.mec_veh_transVel_0)               0
p[124]	... (pneAux.MTBVehicleParameter)               0
p[125]	... (pneAux.PB_Sw_Stat_SATP_0)               0
p[126]	... (pneAux.PB_Trlr_Ctrl_Stat_0)               0
p[127]	... (pneAux.PBL_Fct_Stat_0)               0
p[128]	... (pneAux.PBL_LvrPosn_Cval_0)               0
p[129]	... (pneAux.PkB_TrlrAirPress_Stat_ICUC_0)            2040
p[130]	... (pneAux.PkBrk_Engg_Stat_0)               0
p[131]	... (pneAux.PkBrk_Stat_EAPU_0)               0
p[132]	... (pneAux.PkBrk_Stat_SCH_0)               0
p[133]	... (pneAux.PkBrkPress_Cval_0)               0
p[134]	... (pneAux.pne_brk_Axle1_torque_sns_0)           15000
p[135]	... (pneAux.pne_brk_Axle2_torque_sns_0)           15000
p[136]	... (pneAux.pne_brk_Axle3_torque_sns_0)           15000
p[137]	... (pneAux.pne_brk_Axle4_torque_sns_0)           15000
p[138]	... (pneAux.pne_brk_BrkWearAALt_0)             102
p[139]	... (pneAux.pne_brk_BrkWearAARt_0)             102
p[140]	... (pneAux.pne_brk_BrkWearFA1Lt_0)             102
p[141]	... (pneAux.pne_brk_BrkWearFA1Rt_0)             102
p[142]	... (pneAux.pne_brk_BrkWearFA2Lt_0)             102
p[143]	... (pneAux.pne_brk_BrkWearFA2Rt_0)             102
p[144]	... (pneAux.pne_brk_BrkWearRA1Lt_0)             102
p[145]	... (pneAux.pne_brk_BrkWearRA1Rt_0)             102
p[146]	... (pneAux.pne_brk_BrkWearRA2Lt_0)             102
p[147]	... (pneAux.pne_brk_BrkWearRA2Rt_0)             102
p[148]	... (pneAux.pne_brk_CompON_0)               0
p[149]	... (pneAux.pne_brk_pRelPkBrk_0)             8.5
p[150]	... (pneAux.pne_brk_reg_active_0)               0
p[151]	... (pneAux.pne_brk_rotVel_t1l_0)               0
p[152]	... (pneAux.pne_brk_rotVel_t1r_0)               0
p[153]	... (pneAux.pne_brk_rotVel_t2l_0)               0
p[154]	... (pneAux.pne_brk_rotVel_t2r_0)               0
p[155]	... (pneAux.pne_brk_rotVel_t3l_0)               0
p[156]	... (pneAux.pne_brk_rotVel_t3r_0)               0
p[157]	... (pneAux.pne_brk_Trailer_RV_Front_pAct_0)               0
p[158]	... (pneAux.pne_brk_Trailer_RV_Rear_pAct_0)               0
p[159]	... (pneAux.pne_brk_TrailerAxle1_BrakingForce_at8p5bar_0)               0
p[160]	... (pneAux.pne_brk_TrailerAxle1_torque_sns_0)           15000
p[161]	... (pneAux.pne_brk_TrailerAxle2_BrakingForce_at8p5bar_0)               0
p[162]	... (pneAux.pne_brk_TrailerAxle2_torque_sns_0)           15000
p[163]	... (pneAux.pne_brk_TrailerAxle3_BrakingForce_at8p5bar_0)               0
p[164]	... (pneAux.pne_brk_TrailerAxle3_torque_sns_0)           15000
p[165]	... (pneAux.pne_brk_V1_pRel_0)            12.5
p[166]	... (pneAux.pne_brk_V2_pRel_0)            12.5
p[167]	... (pneAux.pne_brk_V4_pRel_0)             8.5
p[168]	... (pneAux.pne_brk_V7_pRel_0)            12.5
p[169]	... (pneAux.pne_brk_VTrailer_pRel_0)             8.5
p[170]	... (pneAux.pne_brk_WetLvl_Cntr_0)               0
p[171]	... (pneAux.pne_MTBmodusSwAllowed_0)               1
p[172]	... (pneAux.pne_susp_A1_Le_Posn_0)               0
p[173]	... (pneAux.pne_susp_A1_Ri_Posn_0)               0
p[174]	... (pneAux.pne_susp_A2_Le_Posn_0)               0
p[175]	... (pneAux.pne_susp_A2_Ri_Posn_0)               0
p[176]	... (pneAux.pne_susp_A3_Le_Posn_0)               0
p[177]	... (pneAux.pne_susp_A3_Ri_Posn_0)               0
p[178]	... (pneAux.pneAux_A1_Le_Rq_0)               0
p[179]	... (pneAux.pneAux_A1_LoLi_Rq_0)               0
p[180]	... (pneAux.pneAux_A1_Ri_Rq_0)               0
p[181]	... (pneAux.pneAux_A2_Le_Rq_0)               0
p[182]	... (pneAux.pneAux_A2_LoLi_Rq_0)               0
p[183]	... (pneAux.pneAux_A2_Ri_Rq_0)               0
p[184]	... (pneAux.pneAux_A3_Le_Rq_0)               0
p[185]	... (pneAux.pneAux_A3_LoLi_Rq_0)               0
p[186]	... (pneAux.pneAux_A3_Ri_Rq_0)               0
p[187]	... (pneAux.pneAux_Axle1_load_0)               0
p[188]	... (pneAux.pneAux_Axle2_load_0)               0
p[189]	... (pneAux.pneAux_Axle3_load_0)               0
p[190]	... (pneAux.pneAux_Axle4_load_0)               0
p[191]	... (pneAux.pneAux_Drs_Rq_0)               0
p[192]	... (pneAux.pneAux_EAPU_overrun_0)               0
p[193]	... (pneAux.pneAux_mass_Tractor_0)               0
p[194]	... (pneAux.pneAux_mass_Trailer_0)               0
p[195]	... (pneAux.pneAux_pSoll_TCV_p43_0)               0
p[196]	... (pneAux.pneAux_pSollPkBrk_0)               0
p[197]	... (pneAux.pneAux_SumBrakingForces_Tractor_0)               0
p[198]	... (pneAux.pneAux_SumBrakingForces_Trailer_0)               0
p[199]	... (pneAux.pneAux_TCV_pDmd_Front_Left_0)               0
p[200]	... (pneAux.pneAux_TCV_pDmd_Front_Right_0)               0
p[201]	... (pneAux.pneAux_TCV_pDmd_Rear_Left_0)               0
p[202]	... (pneAux.pneAux_TCV_pDmd_Rear_Right_0)               0
p[203]	... (pneAux.pneAux_trailerAxle1_left_stABSInValve_0)               0
p[204]	... (pneAux.pneAux_trailerAxle1_left_stABSOutValve_0)               0
p[205]	... (pneAux.pneAux_trailerAxle1_load_0)               0
p[206]	... (pneAux.pneAux_trailerAxle1_right_stABSInValve_0)               0
p[207]	... (pneAux.pneAux_trailerAxle1_right_stABSOutValve_0)               0
p[208]	... (pneAux.pneAux_trailerAxle2_left_stABSInValve_0)               0
p[209]	... (pneAux.pneAux_trailerAxle2_left_stABSOutValve_0)               0
p[210]	... (pneAux.pneAux_trailerAxle2_load_0)               0
p[211]	... (pneAux.pneAux_trailerAxle2_right_stABSInValve_0)               0
p[212]	... (pneAux.pneAux_trailerAxle2_right_stABSOutValve_0)               0
p[213]	... (pneAux.pneAux_trailerAxle3_left_stABSInValve_0)               0
p[214]	... (pneAux.pneAux_trailerAxle3_left_stABSOutValve_0)               0
p[215]	... (pneAux.pneAux_trailerAxle3_load_0)               0
p[216]	... (pneAux.pneAux_trailerAxle3_right_stABSInValve_0)               0
p[217]	... (pneAux.pneAux_trailerAxle3_right_stABSOutValve_0)               0
p[218]	... (pneAux.PressAir_Rq_0)               0
p[219]	... (pneAux.PressAir_Rq_ICUC_0)               0
p[220]	... (pneAux.PressAir_Rq_SATP_0)               0
p[221]	... (pneAux.pSwitch_bar)             8.5
p[222]	... (pneAux.rdynFA)             492
p[223]	... (pneAux.rdynRA)             492
p[224]	... (pneAux.rdynTA)             492
p[225]	... (pneAux.RedWarn_Rq_Trlr2_0)               0
p[226]	... (pneAux.RedWarn_Rq_Trlr3_0)               0
p[227]	... (pneAux.RedWarn_Rq_Trlr4_0)               0
p[228]	... (pneAux.RedWarn_Rq_Trlr5_0)               0
p[229]	... (pneAux.RedWarn_Rq_Trlr_0)               0
p[230]	... (pneAux.stepSize)            0.01
p[231]	... (pneAux.SuspAirPress_Stat_SATP_0)               0
p[232]	... (pneAux.TBL_LvrPosn_Cval_0)               0
p[233]	... (pneAux.tDelay)              90
p[234]	... (pneAux.TrailerABS_L1o)             4.4
p[235]	... (pneAux.TrailerABS_L1v)             625
p[236]	... (pneAux.TrailerABS_L2o)            12.5
p[237]	... (pneAux.TrailerABS_L2v)            2500
p[238]	... (pneAux.TrailerABS_MinusB)            -1.5
p[239]	... (pneAux.TrailerABS_PlusB)             0.8
p[240]	... (pneAux.TrailerABS_PlusOB)              10
p[241]	... (pneAux.TrailerABS_THe)              50
p[242]	... (pneAux.TrailerABS_TPulHold)              20
p[243]	... (pneAux.TrailerABS_TPulOpen)              25
p[244]	... (pneAux.TrailerABS_vMin_kmh)               2
p[245]	... (pneAux.Trlr_Air_Sup_Sw_Stat_0)               0
p[246]	... (pneAux.Trlr_Air_Supply_Press_Cval_0)               0
p[247]	... (pneAux.VehABS_Stat_Trlr_0)               3
p[248]	... (pneAux.VehSpd1_Cval_Trlr_0)         255.996
p[249]	... (pneAux.WetLvlCntr_Cval_SATP_0)               0
p[250]	... (pneAux.axleLoadTrailer_kg) sMP.ctrl.pneAux.veh.axleLoadTrailer_kg
p[251]	... (pneAux.axleLoadVehicle_kg) sMP.ctrl.pneAux.veh.axleLoadVehicle_kg
p[252]	... (pneAux.brkCircuit) sMP.ctrl.pneAux.veh.brkCircuit
p[253]	... (pneAux.brkCircuitTrailer) sMP.ctrl.pneAux.veh.brkCircuitTrailer
p[254]	... (pneAux.flagTrailerControlActive) sMP.ctrl.pneAux.veh.flagTrailerControlActive
p[255]	... (pneAux.pAppCyl_Trailer) sMP.ctrl.pneAux.veh.pAppCyl_Trailer
p[256]	... (pneAux.speedSensorPosnTrailer) sMP.ctrl.pneAux.veh.speedSensorPosnTrailer

Curves: