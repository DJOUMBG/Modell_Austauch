Inputs: 
u[0]	... Signal Input (IO_EBS_InputSignals.env_curv_pm)
u[1]	... Signal Input (IO_EBS_InputSignals.env_road_slope_pct)
u[2]	... Signal Input (IO_EBS_InputSignals.ActlEmotTrq_Cval)
u[3]	... Signal Input (IO_EBS_InputSignals.ActlEngPctTrq_Cval)
u[4]	... Signal Input (IO_EBS_InputSignals.ActlMaxAvlRetPctTrq_Cval_CPC3)
u[5]	... Signal Input (IO_EBS_InputSignals.aSbspVehBrkForce_Cmd_SDS)
u[6]	... Signal Input (IO_EBS_InputSignals.BrkPress_Rq)
u[7]	... Signal Input (IO_EBS_InputSignals.Clutch_Stat_CPC)
u[8]	... Signal Input (IO_EBS_InputSignals.EdrvRefTrq_Cval)
u[9]	... Signal Input (IO_EBS_InputSignals.EngPctTrqActl_Cval)
u[10]	... Signal Input (IO_EBS_InputSignals.EngRefTrq_Cval)
u[11]	... Signal Input (IO_EBS_InputSignals.EngRPM_Cval_CPC3)
u[12]	... Signal Input (IO_EBS_InputSignals.ExtAccel_Rq_CPC)
u[13]	... Signal Input (IO_EBS_InputSignals.ExtAccel_Rq_CPC5ce)
u[14]	... Signal Input (IO_EBS_InputSignals.ExtAccel_Rq_VRDU)
u[15]	... Signal Input (IO_EBS_InputSignals.ExtAccel_Rq_VRDU3)
u[16]	... Signal Input (IO_EBS_InputSignals.ExtBrkStat_Rq_CPC)
u[17]	... Signal Input (IO_EBS_InputSignals.ExtBrkStat_Rq_VRDU)
u[18]	... Signal Input (IO_EBS_InputSignals.HB_Rq_Stat_CPC)
u[19]	... Signal Input (IO_EBS_InputSignals.HB_Rq_Stat_VRDU)
u[20]	... Signal Input (IO_EBS_InputSignals.MinAvlEmotTrq_Cval_CPC)
u[21]	... Signal Input (IO_EBS_InputSignals.NomFrictEngPctTrq_Cval)
u[22]	... Signal Input (IO_EBS_InputSignals.PkBrk_Rq_VRDU)
u[23]	... Signal Input (IO_EBS_InputSignals.RetPctTrqActl2_Cval_CPC3)
u[24]	... Signal Input (IO_EBS_InputSignals.RetRefTrq_Cval)
u[25]	... Signal Input (IO_EBS_InputSignals.TrqConv_Cval_PT)
u[26]	... Signal Input (IO_EBS_InputSignals.TxInShaftSpd_Cval_CPC)
u[27]	... Signal Input (IO_EBS_InputSignals.VehSpd1_Cval_Trlr)
u[28]	... Signal Input (IO_EBS_InputSignals.XBR_CtrlMode_Stat_CPC5ce)
u[29]	... Signal Input (IO_EBS_InputSignals.XBR_CtrlMode_Stat_VRDU)
u[30]	... Signal Input (IO_EBS_InputSignals.XBR_EBI_Stat_VRDU)
u[31]	... Signal Input (IO_EBS_InputSignals.XBR_Prio_Stat_CPC5ce)
u[32]	... Signal Input (IO_EBS_InputSignals.XBR_Prio_Stat_VRDU)
u[33]	... Signal Input (IO_EBS_InputSignals.drv_BrkPdl_pos)
u[34]	... Signal Input (IO_EBS_InputSignals.drv_PkBrk)
u[35]	... Signal Input (IO_EBS_InputSignals.mec3d_ESCsens_gamma_rate)
u[36]	... Signal Input (IO_EBS_InputSignals.mec3d_ESCsens_y_acceleration)
u[37]	... Signal Input (IO_EBS_InputSignals.mec_veh_AxleLoad1)
u[38]	... Signal Input (IO_EBS_InputSignals.mec_veh_AxleLoad2)
u[39]	... Signal Input (IO_EBS_InputSignals.mec_veh_AxleLoad3)
u[40]	... Signal Input (IO_EBS_InputSignals.mec_veh_AxleLoad4)
u[41]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad1)
u[42]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad2)
u[43]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad3)
u[44]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad4)
u[45]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad5)
u[46]	... Signal Input (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad6)
u[47]	... Signal Input (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad1)
u[48]	... Signal Input (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad2)
u[49]	... Signal Input (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad3)
u[50]	... Signal Input (IO_EBS_InputSignals.mec_veh_transVel)
u[51]	... Signal Input (IO_EBS_InputSignals.pne_brk_AdditionalAxle_left_pAct)
u[52]	... Signal Input (IO_EBS_InputSignals.pne_brk_AdditionalAxle_right_pAct)
u[53]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle1_BrakingForce_at8p5bar)
u[54]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle1_left_Tinterior)
u[55]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle1_right_Tinterior)
u[56]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle1_torque_sns)
u[57]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle2_BrakingForce_at8p5bar)
u[58]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle2_left_Tinterior)
u[59]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle2_right_Tinterior)
u[60]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle2_torque_sns)
u[61]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle3_BrakingForce_at8p5bar)
u[62]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle3_left_Tinterior)
u[63]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle3_right_Tinterior)
u[64]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle3_torque_sns)
u[65]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle4_BrakingForce_at8p5bar)
u[66]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle4_left_Tinterior)
u[67]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle4_right_Tinterior)
u[68]	... Signal Input (IO_EBS_InputSignals.pne_brk_Axle4_torque_sns)
u[69]	... Signal Input (IO_EBS_InputSignals.pne_brk_FrontAxle_pAct)
u[70]	... Signal Input (IO_EBS_InputSignals.pne_brk_RearAxle_left_pAct)
u[71]	... Signal Input (IO_EBS_InputSignals.pne_brk_RearAxle_right_pAct)
u[72]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_al)
u[73]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_ar)
u[74]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_fl)
u[75]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_fr)
u[76]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_rl)
u[77]	... Signal Input (IO_EBS_InputSignals.pne_brk_rotVel_rr)
u[78]	... Signal Input (IO_EBS_InputSignals.pne_brk_TCV_pAct)
u[79]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle1_BrakingForce_at8p5bar)
u[80]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle1_torque_sns)
u[81]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle2_BrakingForce_at8p5bar)
u[82]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle2_torque_sns)
u[83]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle3_BrakingForce_at8p5bar)
u[84]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle3_torque_sns)
u[85]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle4_BrakingForce_at8p5bar)
u[86]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle4_torque_sns)
u[87]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle5_BrakingForce_at8p5bar)
u[88]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle5_torque_sns)
u[89]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle6_BrakingForce_at8p5bar)
u[90]	... Signal Input (IO_EBS_InputSignals.pne_brk_Trailer02Axle6_torque_sns)
u[91]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle1_BrakingForce_at8p5bar)
u[92]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle1_torque_sns)
u[93]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle2_BrakingForce_at8p5bar)
u[94]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle2_torque_sns)
u[95]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle3_BrakingForce_at8p5bar)
u[96]	... Signal Input (IO_EBS_InputSignals.pne_brk_TrailerAxle3_torque_sns)

Outputs: 
y[0]	... Signal Output (IO_EBS_InputSignals.ebs_AdditionalAxle_left_pDmd)
y[1]	... Signal Output (IO_EBS_InputSignals.ebs_AdditionalAxle_right_pDmd)
y[2]	... Signal Output (IO_EBS_InputSignals.ebs_ESCsens_y_acceleration)
y[3]	... Signal Output (IO_EBS_InputSignals.ebs_FrontAxle_left_pDmd)
y[4]	... Signal Output (IO_EBS_InputSignals.ebs_FrontAxle_right_pDmd)
y[5]	... Signal Output (IO_EBS_InputSignals.ebs_RearAxle_left_pDmd)
y[6]	... Signal Output (IO_EBS_InputSignals.ebs_RearAxle_right_pDmd)
y[7]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Addl_Left)
y[8]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Addl_Right)
y[9]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Front_Left)
y[10]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Front_Right)
y[11]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_RCMax_Front)
y[12]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_RCMax_Rear)
y[13]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Rear_Left)
y[14]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Rear_Right)
y[15]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Addl_Left)
y[16]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Addl_Right)
y[17]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Front_Left)
y[18]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Front_Right)
y[19]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_RCMax_Front)
y[20]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_RCMax_Rear)
y[21]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Rear_Left)
y[22]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Rear_Right)
y[23]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stAPCVBuValve)
y[24]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stAxmoBuValve)
y[25]	... Signal Output (IO_EBS_InputSignals.ebs_sBSP_stCMaxBuValve)
y[26]	... Signal Output (IO_EBS_InputSignals.ebs_TCV_pDmd)
y[27]	... Signal Output (IO_EBS_InputSignals.aAutoOpMd_Stat_SBSP)
y[28]	... Signal Output (IO_EBS_InputSignals.aBrkAirPressAA_Cval_SBSP)
y[29]	... Signal Output (IO_EBS_InputSignals.aBrkAirPressFA_Cval_SBSP)
y[30]	... Signal Output (IO_EBS_InputSignals.aBrkAirPressRA_Cval_SBSP)
y[31]	... Signal Output (IO_EBS_InputSignals.aBrkPdlPosn3_Cval_SBSP)
y[32]	... Signal Output (IO_EBS_InputSignals.aBrkTempFA_Cval_SBSP)
y[33]	... Signal Output (IO_EBS_InputSignals.aBrkTempIA_Cval_SBSP)
y[34]	... Signal Output (IO_EBS_InputSignals.aBrkTempRA_Cval_SBSP)
y[35]	... Signal Output (IO_EBS_InputSignals.ABS_Actv2_Stat)
y[36]	... Signal Output (IO_EBS_InputSignals.ABS_Actv_Stat)
y[37]	... Signal Output (IO_EBS_InputSignals.ABS_FullyOp_Stat)
y[38]	... Signal Output (IO_EBS_InputSignals.ABS_Trlr_Stat)
y[39]	... Signal Output (IO_EBS_InputSignals.Accel_X_Cval)
y[40]	... Signal Output (IO_EBS_InputSignals.Accel_X_Cval_SBSP)
y[41]	... Signal Output (IO_EBS_InputSignals.Accel_Y_Cval)
y[42]	... Signal Output (IO_EBS_InputSignals.Accel_Y_Cval_SBSP)
y[43]	... Signal Output (IO_EBS_InputSignals.AddInfoVehSped_Cval_SBSP)
y[44]	... Signal Output (IO_EBS_InputSignals.aGroCmbVehWeight_Cval_SBSP)
y[45]	... Signal Output (IO_EBS_InputSignals.aGroCmbVehWeightConf_SBSP)
y[46]	... Signal Output (IO_EBS_InputSignals.aStandstill_Dtct_Stat_SBSP)
y[47]	... Signal Output (IO_EBS_InputSignals.ATC_BrkCtrl_Stat)
y[48]	... Signal Output (IO_EBS_InputSignals.ATC_EngCtrl_Stat)
y[49]	... Signal Output (IO_EBS_InputSignals.ATC_InfoSgl_Stat)
y[50]	... Signal Output (IO_EBS_InputSignals.aTCV_Press_Cval_SBSP)
y[51]	... Signal Output (IO_EBS_InputSignals.aVehSpd_Cval_E2E_SBSP)
y[52]	... Signal Output (IO_EBS_InputSignals.aVehSpd_Cval_SBSP)
y[53]	... Signal Output (IO_EBS_InputSignals.BlockTend_Stat)
y[54]	... Signal Output (IO_EBS_InputSignals.BrkPdlPosn3_Cval)
y[55]	... Signal Output (IO_EBS_InputSignals.BrkPdlPosn3_Cval_SBSP)
y[56]	... Signal Output (IO_EBS_InputSignals.BrkPdlPosn_Cval)
y[57]	... Signal Output (IO_EBS_InputSignals.BS_Brk_Cval)
y[58]	... Signal Output (IO_EBS_InputSignals.BS_Brk_Cval_SBSP)
y[59]	... Signal Output (IO_EBS_InputSignals.BS_CS_Acc_Stat)
y[60]	... Signal Output (IO_EBS_InputSignals.BS_CS_Acc_Stat_SBSP)
y[61]	... Signal Output (IO_EBS_InputSignals.BS_CS_RqPerf2_Stat)
y[62]	... Signal Output (IO_EBS_InputSignals.BS_CS_RqPerf2_Stat_SBSP)
y[63]	... Signal Output (IO_EBS_InputSignals.BS_CS_RqPerf_Stat_SBSP)
y[64]	... Signal Output (IO_EBS_InputSignals.BS_CSCPC_Acc_Stat)
y[65]	... Signal Output (IO_EBS_InputSignals.BS_CSCPC_Acc_Stat_SBSP)
y[66]	... Signal Output (IO_EBS_InputSignals.BS_CSCPC_Intf_Stat)
y[67]	... Signal Output (IO_EBS_InputSignals.BS_CSCPC_RqPerf_Stat)
y[68]	... Signal Output (IO_EBS_InputSignals.BS_HB_Acc_Stat_SBSP)
y[69]	... Signal Output (IO_EBS_InputSignals.BS_HB_RqPerf_Stat)
y[70]	... Signal Output (IO_EBS_InputSignals.BS_HB_RqPerf_Stat_SBSP)
y[71]	... Signal Output (IO_EBS_InputSignals.BS_HBCPC_Acc_Stat_SBSP)
y[72]	... Signal Output (IO_EBS_InputSignals.BS_HBCPC_RqPerf_Stat_SBSP)
y[73]	... Signal Output (IO_EBS_InputSignals.BS_RoadIncln_Cval)
y[74]	... Signal Output (IO_EBS_InputSignals.BS_SS_Acc_Stat)
y[75]	... Signal Output (IO_EBS_InputSignals.BS_SS_Acc_Stat_SBSP)
y[76]	... Signal Output (IO_EBS_InputSignals.BS_SS_RqPerf_Stat)
y[77]	... Signal Output (IO_EBS_InputSignals.BS_SS_RqPerf_Stat_SBSP)
y[78]	... Signal Output (IO_EBS_InputSignals.ConfLatAccel_SBSP)
y[79]	... Signal Output (IO_EBS_InputSignals.ConfLgtAccel_SBSP)
y[80]	... Signal Output (IO_EBS_InputSignals.ConfYawRate_SBSP)
y[81]	... Signal Output (IO_EBS_InputSignals.EBS_BrkSw2_Rq)
y[82]	... Signal Output (IO_EBS_InputSignals.EBS_BrkSw2_Rq_SBSP)
y[83]	... Signal Output (IO_EBS_InputSignals.EngRetTrqMax_Rq)
y[84]	... Signal Output (IO_EBS_InputSignals.EngRetTrqMin_Rq)
y[85]	... Signal Output (IO_EBS_InputSignals.FoundBrk_Stat)
y[86]	... Signal Output (IO_EBS_InputSignals.FullBrkAllow_Stat_SBSP)
y[87]	... Signal Output (IO_EBS_InputSignals.GroCmbVehWeight_Cval)
y[88]	... Signal Output (IO_EBS_InputSignals.HillHolderAvl_Stat)
y[89]	... Signal Output (IO_EBS_InputSignals.NrTrlr_Stat_SBSP)
y[90]	... Signal Output (IO_EBS_InputSignals.PwrVehWeight_Cval)
y[91]	... Signal Output (IO_EBS_InputSignals.RoadCurv_Cval)
y[92]	... Signal Output (IO_EBS_InputSignals.ROP_BrkCtrlActv2_Stat)
y[93]	... Signal Output (IO_EBS_InputSignals.ROP_EngCtrlActv2_Stat)
y[94]	... Signal Output (IO_EBS_InputSignals.sAccel_X_Cval_SBSP)
y[95]	... Signal Output (IO_EBS_InputSignals.sAccel_Y_Cval_SBSP)
y[96]	... Signal Output (IO_EBS_InputSignals.sAddInfoVehSped_Cval_SBSP)
y[97]	... Signal Output (IO_EBS_InputSignals.sBrkPdlPosn3_Cval_SBSP)
y[98]	... Signal Output (IO_EBS_InputSignals.sBS_Brk_Cval_SBSP)
y[99]	... Signal Output (IO_EBS_InputSignals.sBS_CS_Acc_Stat_SBSP)
y[100]	... Signal Output (IO_EBS_InputSignals.sBS_CS_RqPerf2_Stat_SBSP)
y[101]	... Signal Output (IO_EBS_InputSignals.sBS_CS_RqPerf_Stat_SBSP)
y[102]	... Signal Output (IO_EBS_InputSignals.sBS_CSCPC_Acc_Stat_SBSP)
y[103]	... Signal Output (IO_EBS_InputSignals.sBS_HB_Acc_Stat_SBSP)
y[104]	... Signal Output (IO_EBS_InputSignals.sBS_HB_RqPerf_Stat_SBSP)
y[105]	... Signal Output (IO_EBS_InputSignals.sBS_HBCPC_Acc_Stat_SBSP)
y[106]	... Signal Output (IO_EBS_InputSignals.sBS_HBCPC_RqPerf_Stat_SBSP)
y[107]	... Signal Output (IO_EBS_InputSignals.sBS_SS_Acc_Stat_SBSP)
y[108]	... Signal Output (IO_EBS_InputSignals.sBS_SS_RqPerf_Stat_SBSP)
y[109]	... Signal Output (IO_EBS_InputSignals.sConfLatAccel_SBSP)
y[110]	... Signal Output (IO_EBS_InputSignals.sConfLgtAccel_SBSP)
y[111]	... Signal Output (IO_EBS_InputSignals.sConfYawRate_SBSP)
y[112]	... Signal Output (IO_EBS_InputSignals.sEBS_BrkSw2_Rq_SBSP)
y[113]	... Signal Output (IO_EBS_InputSignals.sFullBrkAllow_Stat_SBSP)
y[114]	... Signal Output (IO_EBS_InputSignals.SpdFtAxleLtWhl_Cval)
y[115]	... Signal Output (IO_EBS_InputSignals.SpdFtAxleLtWhl_Cval_SBSP)
y[116]	... Signal Output (IO_EBS_InputSignals.SpdFtAxleRtWhl_Cval)
y[117]	... Signal Output (IO_EBS_InputSignals.SpdFtAxleRtWhl_Cval_SBSP)
y[118]	... Signal Output (IO_EBS_InputSignals.SpdR_AxleLtWhl_Cval)
y[119]	... Signal Output (IO_EBS_InputSignals.SpdR_AxleLtWhl_Cval_SBSP)
y[120]	... Signal Output (IO_EBS_InputSignals.SpdR_AxleRtWhl_Cval)
y[121]	... Signal Output (IO_EBS_InputSignals.SpdR_AxleRtWhl_Cval_SBSP)
y[122]	... Signal Output (IO_EBS_InputSignals.SrcAdrBrkCtrlDev_Cval)
y[123]	... Signal Output (IO_EBS_InputSignals.SrcAdrBrkCtrlDev_Cval_SBSP)
y[124]	... Signal Output (IO_EBS_InputSignals.sSpdFtAxleLtWhl_Cval_SBSP)
y[125]	... Signal Output (IO_EBS_InputSignals.sSpdFtAxleRtWhl_Cval_SBSP)
y[126]	... Signal Output (IO_EBS_InputSignals.sSpdR_AxleLtWhl_Cval_SBSP)
y[127]	... Signal Output (IO_EBS_InputSignals.sSpdR_AxleRtWhl_Cval_SBSP)
y[128]	... Signal Output (IO_EBS_InputSignals.sSrcAdrBrkCtrlDev_Cval_SBSP)
y[129]	... Signal Output (IO_EBS_InputSignals.sStandstill_Dtct_Stat_SBSP)
y[130]	... Signal Output (IO_EBS_InputSignals.Standstill_Dtct_Stat_SBSP)
y[131]	... Signal Output (IO_EBS_InputSignals.sTrlrAbsOper_Stat)
y[132]	... Signal Output (IO_EBS_InputSignals.sTrlrEstm_Stat_SBSP)
y[133]	... Signal Output (IO_EBS_InputSignals.sVehSpd_Cval_SBSP)
y[134]	... Signal Output (IO_EBS_InputSignals.sXBR_AccelLim_Stat_SBSP)
y[135]	... Signal Output (IO_EBS_InputSignals.sXBR_ActCtrl_Stat_SBSP)
y[136]	... Signal Output (IO_EBS_InputSignals.sXBR_Sys_Stat_SBSP)
y[137]	... Signal Output (IO_EBS_InputSignals.sYawRateCorr_Cval_SBSP)
y[138]	... Signal Output (IO_EBS_InputSignals.TrctrAbsOper_Stat)
y[139]	... Signal Output (IO_EBS_InputSignals.TrlrAbsOper_Stat)
y[140]	... Signal Output (IO_EBS_InputSignals.TrlrEstm_Stat_SBSP)
y[141]	... Signal Output (IO_EBS_InputSignals.TyreCorrLtFA_Cval)
y[142]	... Signal Output (IO_EBS_InputSignals.TyreCorrLtRA_Cval)
y[143]	... Signal Output (IO_EBS_InputSignals.TyreCorrRtFA_Cval)
y[144]	... Signal Output (IO_EBS_InputSignals.TyreCorrRtRA_Cval)
y[145]	... Signal Output (IO_EBS_InputSignals.TyreRollCircumFA_Cval)
y[146]	... Signal Output (IO_EBS_InputSignals.TyreRollCircumRA_Cval)
y[147]	... Signal Output (IO_EBS_InputSignals.VehSpd_Cval_BS)
y[148]	... Signal Output (IO_EBS_InputSignals.VehSpd_Cval_SBSP)
y[149]	... Signal Output (IO_EBS_InputSignals.XBR_AccelLim_Stat_BS)
y[150]	... Signal Output (IO_EBS_InputSignals.XBR_AccelLim_Stat_SBSP)
y[151]	... Signal Output (IO_EBS_InputSignals.XBR_ActCtrl_Stat_SBSP)
y[152]	... Signal Output (IO_EBS_InputSignals.XBR_Sys_Stat_SBSP)
y[153]	... Signal Output (IO_EBS_InputSignals.YawRateCorr_Cval_SBSP)
y[154]	... Signal Output (IO_EBS_InputSignals.YC_BrkCtrlActv2_Stat)
y[155]	... Signal Output (IO_EBS_InputSignals.YC_EngCtrlActv2_Stat)
y[156]	... Signal Output (IO_EBS_InputSignals.ebs_ActlEmotTrq_Nm)
y[157]	... Signal Output (IO_EBS_InputSignals.ebs_ActlEngTrq_Nm)
y[158]	... Signal Output (IO_EBS_InputSignals.ebs_ActlRetTrq_Nm)
y[159]	... Signal Output (IO_EBS_InputSignals.ebs_i_Emot)
y[160]	... Signal Output (IO_EBS_InputSignals.ebs_i_Ret)
y[161]	... Signal Output (IO_EBS_InputSignals.ebs_kappa)
y[162]	... Signal Output (IO_EBS_InputSignals.ebs_SumBrakingForces_Trailer)
y[163]	... Signal Output (IO_EBS_InputSignals.ebs_SumBrakingForces_Vehicle)
y[164]	... Signal Output (IO_EBS_InputSignals.ebs_zReqBrake)
y[165]	... Signal Output (IO_EBS_InputSignals.ebs_zReqEB)
y[166]	... Signal Output (IO_EBS_InputSignals.ebs_zRet)
y[167]	... Signal Output (IO_EBS_InputSignals.ebs_zSlopeComp)
y[168]	... Signal Output (IO_EBS_InputSignals.ebs_zSoll_BWG)

Parameters: 
p[0]	... (BWG.dim_xAxis_zSoll)              31
p[1]	... (eBS_veh_Param.ABS_L1o)             4.4
p[2]	... (eBS_veh_Param.ABS_L1v)             625
p[3]	... (eBS_veh_Param.ABS_L2o)            12.5
p[4]	... (eBS_veh_Param.ABS_L2v)            2500
p[5]	... (eBS_veh_Param.ABS_MinusB)            -1.5
p[6]	... (eBS_veh_Param.ABS_PlusB)             0.8
p[7]	... (eBS_veh_Param.ABS_PlusOB)              10
p[8]	... (eBS_veh_Param.ABS_THe)              50
p[9]	... (eBS_veh_Param.ABS_TPulHold)              20
p[10]	... (eBS_veh_Param.ABS_TPulOpen)              25
p[11]	... (eBS_veh_Param.ABS_vMin_kmh)               2
p[12]	... (eBS_veh_Param.flagTrailerABS)               0
p[13]	... (eBS_veh_Param.rdynFA)             492
p[14]	... (eBS_veh_Param.rdynRA)             492
p[15]	... (eBS_veh_Param.rdynTA)             492
p[16]	... (eBS_veh_Param.stepSize)            0.01
p[17]	... (eBSParam.ALB_dpMin_bar)             0.6
p[18]	... (eBSParam.ALB_mRA_Max_kg)            6350
p[19]	... (eBSParam.ALB_mRA_Min_kg)            3450
p[20]	... (eBSParam.ALB_p1Ref_bar)               8
p[21]	... (eBSParam.ALB_p2Max_bar)             8.2
p[22]	... (eBSParam.ALB_p2Min_bar)             2.9
p[23]	... (eBSParam.EBI_mueMax)             0.4
p[24]	... (eBSParam.EBI_vMin_kmh)              20
p[25]	... (eBSParam.flag_ABS)               0
p[26]	... (eBSParam.flag_DownhillDriveTest)               0
p[27]	... (eBSParam.flag_EBI)               2
p[28]	... (eBSParam.flag_SlopeCompActive)               1
p[29]	... (eBSParam.mec_iDiffAxle)               1
p[30]	... (eBSParam.Recuperation_end)               0
p[31]	... (eBSParam.Recuperation_initial)               0
p[32]	... (IO_EBS_InputSignals.aAutoOpMd_Stat_SBSP_0)               0
p[33]	... (IO_EBS_InputSignals.aBrkAirPressAA_Cval_SBSP_0)               0
p[34]	... (IO_EBS_InputSignals.aBrkAirPressFA_Cval_SBSP_0)               0
p[35]	... (IO_EBS_InputSignals.aBrkAirPressRA_Cval_SBSP_0)               0
p[36]	... (IO_EBS_InputSignals.aBrkPdlPosn3_Cval_SBSP_0)             102
p[37]	... (IO_EBS_InputSignals.aBrkTempFA_Cval_SBSP_0)               0
p[38]	... (IO_EBS_InputSignals.aBrkTempIA_Cval_SBSP_0)               0
p[39]	... (IO_EBS_InputSignals.aBrkTempRA_Cval_SBSP_0)               0
p[40]	... (IO_EBS_InputSignals.ABS_Actv2_Stat_0)               0
p[41]	... (IO_EBS_InputSignals.ABS_Actv_Stat_0)               2
p[42]	... (IO_EBS_InputSignals.ABS_FullyOp_Stat_0)               1
p[43]	... (IO_EBS_InputSignals.ABS_Trlr_Stat_0)               2
p[44]	... (IO_EBS_InputSignals.Accel_X_Cval_0)               0
p[45]	... (IO_EBS_InputSignals.Accel_X_Cval_SBSP_0)               0
p[46]	... (IO_EBS_InputSignals.Accel_Y_Cval_0)               0
p[47]	... (IO_EBS_InputSignals.Accel_Y_Cval_SBSP_0)               0
p[48]	... (IO_EBS_InputSignals.ActlEmotTrq_Cval_0)               0
p[49]	... (IO_EBS_InputSignals.ActlEngPctTrq_Cval_0)             130
p[50]	... (IO_EBS_InputSignals.ActlMaxAvlRetPctTrq_Cval_CPC3_0)             130
p[51]	... (IO_EBS_InputSignals.AddInfoVehSped_Cval_SBSP_0)              15
p[52]	... (IO_EBS_InputSignals.aGroCmbVehWeight_Cval_SBSP_0)           65535
p[53]	... (IO_EBS_InputSignals.aGroCmbVehWeightConf_SBSP_0)             100
p[54]	... (IO_EBS_InputSignals.aSbspVehBrkForce_Cmd_SDS_0)          655350
p[55]	... (IO_EBS_InputSignals.aStandstill_Dtct_Stat_SBSP_0)               3
p[56]	... (IO_EBS_InputSignals.ATC_BrkCtrl_Stat_0)               0
p[57]	... (IO_EBS_InputSignals.ATC_EngCtrl_Stat_0)               0
p[58]	... (IO_EBS_InputSignals.ATC_InfoSgl_Stat_0)               0
p[59]	... (IO_EBS_InputSignals.aTCV_Press_Cval_SBSP_0)               0
p[60]	... (IO_EBS_InputSignals.aVehSpd_Cval_E2E_SBSP_0)               0
p[61]	... (IO_EBS_InputSignals.aVehSpd_Cval_SBSP_0)               0
p[62]	... (IO_EBS_InputSignals.BlockTend_Stat_0)               0
p[63]	... (IO_EBS_InputSignals.BrkPdlPosn3_Cval_0)              60
p[64]	... (IO_EBS_InputSignals.BrkPdlPosn3_Cval_SBSP_0)              60
p[65]	... (IO_EBS_InputSignals.BrkPdlPosn_Cval_0)              60
p[66]	... (IO_EBS_InputSignals.BrkPress_Rq_0)               3
p[67]	... (IO_EBS_InputSignals.BS_Brk_Cval_0)          50.242
p[68]	... (IO_EBS_InputSignals.BS_Brk_Cval_SBSP_0)          50.242
p[69]	... (IO_EBS_InputSignals.BS_CS_Acc_Stat_0)               3
p[70]	... (IO_EBS_InputSignals.BS_CS_Acc_Stat_SBSP_0)               1
p[71]	... (IO_EBS_InputSignals.BS_CS_RqPerf2_Stat_0)               0
p[72]	... (IO_EBS_InputSignals.BS_CS_RqPerf2_Stat_SBSP_0)               0
p[73]	... (IO_EBS_InputSignals.BS_CS_RqPerf_Stat_SBSP_0)               3
p[74]	... (IO_EBS_InputSignals.BS_CSCPC_Acc_Stat_0)               1
p[75]	... (IO_EBS_InputSignals.BS_CSCPC_Acc_Stat_SBSP_0)               1
p[76]	... (IO_EBS_InputSignals.BS_CSCPC_Intf_Stat_0)               1
p[77]	... (IO_EBS_InputSignals.BS_CSCPC_RqPerf_Stat_0)               0
p[78]	... (IO_EBS_InputSignals.BS_HB_Acc_Stat_SBSP_0)               3
p[79]	... (IO_EBS_InputSignals.BS_HB_RqPerf_Stat_0)               0
p[80]	... (IO_EBS_InputSignals.BS_HB_RqPerf_Stat_SBSP_0)               0
p[81]	... (IO_EBS_InputSignals.BS_HBCPC_Acc_Stat_SBSP_0)               3
p[82]	... (IO_EBS_InputSignals.BS_HBCPC_RqPerf_Stat_SBSP_0)               3
p[83]	... (IO_EBS_InputSignals.BS_RoadIncln_Cval_0)               0
p[84]	... (IO_EBS_InputSignals.BS_SS_Acc_Stat_0)               1
p[85]	... (IO_EBS_InputSignals.BS_SS_Acc_Stat_SBSP_0)               3
p[86]	... (IO_EBS_InputSignals.BS_SS_RqPerf_Stat_0)               0
p[87]	... (IO_EBS_InputSignals.BS_SS_RqPerf_Stat_SBSP_0)               0
p[88]	... (IO_EBS_InputSignals.Clutch_Stat_CPC_0)               3
p[89]	... (IO_EBS_InputSignals.ConfLatAccel_SBSP_0)              10
p[90]	... (IO_EBS_InputSignals.ConfLgtAccel_SBSP_0)              10
p[91]	... (IO_EBS_InputSignals.ConfYawRate_SBSP_0)              10
p[92]	... (IO_EBS_InputSignals.drv_BrkPdl_pos_0)             0.6
p[93]	... (IO_EBS_InputSignals.drv_PkBrk_0)               0
p[94]	... (IO_EBS_InputSignals.ebs_ActlEmotTrq_Nm_0)               0
p[95]	... (IO_EBS_InputSignals.ebs_ActlEngTrq_Nm_0)               0
p[96]	... (IO_EBS_InputSignals.ebs_ActlRetTrq_Nm_0)               0
p[97]	... (IO_EBS_InputSignals.ebs_AdditionalAxle_left_pDmd_0)               0
p[98]	... (IO_EBS_InputSignals.ebs_AdditionalAxle_right_pDmd_0)               0
p[99]	... (IO_EBS_InputSignals.EBS_BrkSw2_Rq_0)               0
p[100]	... (IO_EBS_InputSignals.EBS_BrkSw2_Rq_SBSP_0)               0
p[101]	... (IO_EBS_InputSignals.ebs_ESCsens_y_acceleration_0)               0
p[102]	... (IO_EBS_InputSignals.ebs_FrontAxle_left_pDmd_0)               0
p[103]	... (IO_EBS_InputSignals.ebs_FrontAxle_right_pDmd_0)               0
p[104]	... (IO_EBS_InputSignals.ebs_i_Emot_0)               0
p[105]	... (IO_EBS_InputSignals.ebs_i_Ret_0)               0
p[106]	... (IO_EBS_InputSignals.ebs_kappa_0)               0
p[107]	... (IO_EBS_InputSignals.ebs_RearAxle_left_pDmd_0)               0
p[108]	... (IO_EBS_InputSignals.ebs_RearAxle_right_pDmd_0)               0
p[109]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Addl_Left_0)               0
p[110]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Addl_Right_0)               0
p[111]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Front_Left_0)               0
p[112]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Front_Right_0)               0
p[113]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_RCMax_Front_0)               0
p[114]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_RCMax_Rear_0)               0
p[115]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Rear_Left_0)               0
p[116]	... (IO_EBS_InputSignals.ebs_sBSP_stABSInValve_Rear_Right_0)               0
p[117]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Addl_Left_0)               0
p[118]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Addl_Right_0)               0
p[119]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Front_Left_0)               0
p[120]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Front_Right_0)               0
p[121]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_RCMax_Front_0)               0
p[122]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_RCMax_Rear_0)               0
p[123]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Rear_Left_0)               0
p[124]	... (IO_EBS_InputSignals.ebs_sBSP_stABSOutValve_Rear_Right_0)               0
p[125]	... (IO_EBS_InputSignals.ebs_sBSP_stAPCVBuValve_0)               0
p[126]	... (IO_EBS_InputSignals.ebs_sBSP_stAxmoBuValve_0)               0
p[127]	... (IO_EBS_InputSignals.ebs_sBSP_stCMaxBuValve_0)               0
p[128]	... (IO_EBS_InputSignals.ebs_SumBrakingForces_Trailer_0)               0
p[129]	... (IO_EBS_InputSignals.ebs_SumBrakingForces_Vehicle_0)               0
p[130]	... (IO_EBS_InputSignals.ebs_TCV_pDmd_0)               0
p[131]	... (IO_EBS_InputSignals.ebs_zReqBrake_0)               0
p[132]	... (IO_EBS_InputSignals.ebs_zReqEB_0)               0
p[133]	... (IO_EBS_InputSignals.ebs_zRet_0)               0
p[134]	... (IO_EBS_InputSignals.ebs_zSlopeComp_0)               0
p[135]	... (IO_EBS_InputSignals.ebs_zSoll_BWG_0)               0
p[136]	... (IO_EBS_InputSignals.EdrvRefTrq_Cval_0)           65535
p[137]	... (IO_EBS_InputSignals.EngPctTrqActl_Cval_0)             130
p[138]	... (IO_EBS_InputSignals.EngRefTrq_Cval_0)           65535
p[139]	... (IO_EBS_InputSignals.EngRetTrqMax_Rq_0)               0
p[140]	... (IO_EBS_InputSignals.EngRetTrqMin_Rq_0)               0
p[141]	... (IO_EBS_InputSignals.EngRPM_Cval_CPC3_0)         8191.88
p[142]	... (IO_EBS_InputSignals.env_curv_pm_0)               0
p[143]	... (IO_EBS_InputSignals.env_road_slope_pct_0)               0
p[144]	... (IO_EBS_InputSignals.ExtAccel_Rq_CPC5ce_0)               0
p[145]	... (IO_EBS_InputSignals.ExtAccel_Rq_CPC_0)         16.3125
p[146]	... (IO_EBS_InputSignals.ExtAccel_Rq_VRDU3_0)          16.312
p[147]	... (IO_EBS_InputSignals.ExtAccel_Rq_VRDU_0)               0
p[148]	... (IO_EBS_InputSignals.ExtBrkStat_Rq_CPC_0)               0
p[149]	... (IO_EBS_InputSignals.ExtBrkStat_Rq_VRDU_0)               0
p[150]	... (IO_EBS_InputSignals.FoundBrk_Stat_0)               4
p[151]	... (IO_EBS_InputSignals.FullBrkAllow_Stat_SBSP_0)               1
p[152]	... (IO_EBS_InputSignals.GroCmbVehWeight_Cval_0)          655350
p[153]	... (IO_EBS_InputSignals.HB_Rq_Stat_CPC_0)               3
p[154]	... (IO_EBS_InputSignals.HB_Rq_Stat_VRDU_0)               0
p[155]	... (IO_EBS_InputSignals.HillHolderAvl_Stat_0)               0
p[156]	... (IO_EBS_InputSignals.mec3d_ESCsens_gamma_rate_0)               0
p[157]	... (IO_EBS_InputSignals.mec3d_ESCsens_y_acceleration_0)               0
p[158]	... (IO_EBS_InputSignals.mec_veh_AxleLoad1_0)               0
p[159]	... (IO_EBS_InputSignals.mec_veh_AxleLoad2_0)               0
p[160]	... (IO_EBS_InputSignals.mec_veh_AxleLoad3_0)               0
p[161]	... (IO_EBS_InputSignals.mec_veh_AxleLoad4_0)               0
p[162]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad1_0)               0
p[163]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad2_0)               0
p[164]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad3_0)               0
p[165]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad4_0)               0
p[166]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad5_0)               0
p[167]	... (IO_EBS_InputSignals.mec_veh_Trailer02AxleLoad6_0)               0
p[168]	... (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad1_0)               0
p[169]	... (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad2_0)               0
p[170]	... (IO_EBS_InputSignals.mec_veh_TrailerAxleLoad3_0)               0
p[171]	... (IO_EBS_InputSignals.mec_veh_transVel_0)               0
p[172]	... (IO_EBS_InputSignals.MinAvlEmotTrq_Cval_CPC_0)               0
p[173]	... (IO_EBS_InputSignals.NomFrictEngPctTrq_Cval_0)             130
p[174]	... (IO_EBS_InputSignals.NrTrlr_Stat_SBSP_0)               0
p[175]	... (IO_EBS_InputSignals.PkBrk_Rq_VRDU_0)               0
p[176]	... (IO_EBS_InputSignals.pne_brk_AdditionalAxle_left_pAct_0)               0
p[177]	... (IO_EBS_InputSignals.pne_brk_AdditionalAxle_right_pAct_0)               0
p[178]	... (IO_EBS_InputSignals.pne_brk_Axle1_BrakingForce_at8p5bar_0)               0
p[179]	... (IO_EBS_InputSignals.pne_brk_Axle1_left_Tinterior_0)              25
p[180]	... (IO_EBS_InputSignals.pne_brk_Axle1_right_Tinterior_0)              25
p[181]	... (IO_EBS_InputSignals.pne_brk_Axle1_torque_sns_0)           15000
p[182]	... (IO_EBS_InputSignals.pne_brk_Axle2_BrakingForce_at8p5bar_0)               0
p[183]	... (IO_EBS_InputSignals.pne_brk_Axle2_left_Tinterior_0)              25
p[184]	... (IO_EBS_InputSignals.pne_brk_Axle2_right_Tinterior_0)              25
p[185]	... (IO_EBS_InputSignals.pne_brk_Axle2_torque_sns_0)           15000
p[186]	... (IO_EBS_InputSignals.pne_brk_Axle3_BrakingForce_at8p5bar_0)               0
p[187]	... (IO_EBS_InputSignals.pne_brk_Axle3_left_Tinterior_0)              25
p[188]	... (IO_EBS_InputSignals.pne_brk_Axle3_right_Tinterior_0)              25
p[189]	... (IO_EBS_InputSignals.pne_brk_Axle3_torque_sns_0)           15000
p[190]	... (IO_EBS_InputSignals.pne_brk_Axle4_BrakingForce_at8p5bar_0)               0
p[191]	... (IO_EBS_InputSignals.pne_brk_Axle4_left_Tinterior_0)              25
p[192]	... (IO_EBS_InputSignals.pne_brk_Axle4_right_Tinterior_0)              25
p[193]	... (IO_EBS_InputSignals.pne_brk_Axle4_torque_sns_0)           15000
p[194]	... (IO_EBS_InputSignals.pne_brk_FrontAxle_pAct_0)               0
p[195]	... (IO_EBS_InputSignals.pne_brk_RearAxle_left_pAct_0)               0
p[196]	... (IO_EBS_InputSignals.pne_brk_RearAxle_right_pAct_0)               0
p[197]	... (IO_EBS_InputSignals.pne_brk_rotVel_al_0)               0
p[198]	... (IO_EBS_InputSignals.pne_brk_rotVel_ar_0)               0
p[199]	... (IO_EBS_InputSignals.pne_brk_rotVel_fl_0)               0
p[200]	... (IO_EBS_InputSignals.pne_brk_rotVel_fr_0)               0
p[201]	... (IO_EBS_InputSignals.pne_brk_rotVel_rl_0)               0
p[202]	... (IO_EBS_InputSignals.pne_brk_rotVel_rr_0)               0
p[203]	... (IO_EBS_InputSignals.pne_brk_TCV_pAct_0)               0
p[204]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle1_BrakingForce_at8p5bar_0)               0
p[205]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle1_torque_sns_0)               0
p[206]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle2_BrakingForce_at8p5bar_0)               0
p[207]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle2_torque_sns_0)               0
p[208]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle3_BrakingForce_at8p5bar_0)               0
p[209]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle3_torque_sns_0)               0
p[210]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle4_BrakingForce_at8p5bar_0)               0
p[211]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle4_torque_sns_0)               0
p[212]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle5_BrakingForce_at8p5bar_0)               0
p[213]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle5_torque_sns_0)               0
p[214]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle6_BrakingForce_at8p5bar_0)               0
p[215]	... (IO_EBS_InputSignals.pne_brk_Trailer02Axle6_torque_sns_0)               0
p[216]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle1_BrakingForce_at8p5bar_0)               0
p[217]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle1_torque_sns_0)           15000
p[218]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle2_BrakingForce_at8p5bar_0)               0
p[219]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle2_torque_sns_0)           15000
p[220]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle3_BrakingForce_at8p5bar_0)               0
p[221]	... (IO_EBS_InputSignals.pne_brk_TrailerAxle3_torque_sns_0)           15000
p[222]	... (IO_EBS_InputSignals.PwrVehWeight_Cval_0)          655350
p[223]	... (IO_EBS_InputSignals.RetPctTrqActl2_Cval_CPC3_0)               0
p[224]	... (IO_EBS_InputSignals.RetRefTrq_Cval_0)           65535
p[225]	... (IO_EBS_InputSignals.RoadCurv_Cval_0)               0
p[226]	... (IO_EBS_InputSignals.ROP_BrkCtrlActv2_Stat_0)               2
p[227]	... (IO_EBS_InputSignals.ROP_EngCtrlActv2_Stat_0)               3
p[228]	... (IO_EBS_InputSignals.sAccel_X_Cval_SBSP_0)          16.312
p[229]	... (IO_EBS_InputSignals.sAccel_Y_Cval_SBSP_0)          16.312
p[230]	... (IO_EBS_InputSignals.sAddInfoVehSped_Cval_SBSP_0)               0
p[231]	... (IO_EBS_InputSignals.sBrkPdlPosn3_Cval_SBSP_0)             102
p[232]	... (IO_EBS_InputSignals.sBS_Brk_Cval_SBSP_0)             102
p[233]	... (IO_EBS_InputSignals.sBS_CS_Acc_Stat_SBSP_0)               1
p[234]	... (IO_EBS_InputSignals.sBS_CS_RqPerf2_Stat_SBSP_0)               3
p[235]	... (IO_EBS_InputSignals.sBS_CS_RqPerf_Stat_SBSP_0)               3
p[236]	... (IO_EBS_InputSignals.sBS_CSCPC_Acc_Stat_SBSP_0)               3
p[237]	... (IO_EBS_InputSignals.sBS_HB_Acc_Stat_SBSP_0)               0
p[238]	... (IO_EBS_InputSignals.sBS_HB_RqPerf_Stat_SBSP_0)               3
p[239]	... (IO_EBS_InputSignals.sBS_HBCPC_Acc_Stat_SBSP_0)               3
p[240]	... (IO_EBS_InputSignals.sBS_HBCPC_RqPerf_Stat_SBSP_0)               3
p[241]	... (IO_EBS_InputSignals.sBS_SS_Acc_Stat_SBSP_0)               1
p[242]	... (IO_EBS_InputSignals.sBS_SS_RqPerf_Stat_SBSP_0)               3
p[243]	... (IO_EBS_InputSignals.sConfLatAccel_SBSP_0)              10
p[244]	... (IO_EBS_InputSignals.sConfLgtAccel_SBSP_0)              10
p[245]	... (IO_EBS_InputSignals.sConfYawRate_SBSP_0)              10
p[246]	... (IO_EBS_InputSignals.sEBS_BrkSw2_Rq_SBSP_0)               3
p[247]	... (IO_EBS_InputSignals.sFullBrkAllow_Stat_SBSP_0)               1
p[248]	... (IO_EBS_InputSignals.SpdFtAxleLtWhl_Cval_0)               0
p[249]	... (IO_EBS_InputSignals.SpdFtAxleLtWhl_Cval_SBSP_0)         255.996
p[250]	... (IO_EBS_InputSignals.SpdFtAxleRtWhl_Cval_0)               0
p[251]	... (IO_EBS_InputSignals.SpdFtAxleRtWhl_Cval_SBSP_0)         255.996
p[252]	... (IO_EBS_InputSignals.SpdR_AxleLtWhl_Cval_0)               0
p[253]	... (IO_EBS_InputSignals.SpdR_AxleLtWhl_Cval_SBSP_0)         255.996
p[254]	... (IO_EBS_InputSignals.SpdR_AxleRtWhl_Cval_0)               0
p[255]	... (IO_EBS_InputSignals.SpdR_AxleRtWhl_Cval_SBSP_0)         255.996
p[256]	... (IO_EBS_InputSignals.SrcAdrBrkCtrlDev_Cval_0)               0
p[257]	... (IO_EBS_InputSignals.SrcAdrBrkCtrlDev_Cval_SBSP_0)               0
p[258]	... (IO_EBS_InputSignals.sSpdFtAxleLtWhl_Cval_SBSP_0)         255.996
p[259]	... (IO_EBS_InputSignals.sSpdFtAxleRtWhl_Cval_SBSP_0)         255.996
p[260]	... (IO_EBS_InputSignals.sSpdR_AxleLtWhl_Cval_SBSP_0)         255.996
p[261]	... (IO_EBS_InputSignals.sSpdR_AxleRtWhl_Cval_SBSP_0)         255.996
p[262]	... (IO_EBS_InputSignals.sSrcAdrBrkCtrlDev_Cval_SBSP_0)             255
p[263]	... (IO_EBS_InputSignals.sStandstill_Dtct_Stat_SBSP_0)               3
p[264]	... (IO_EBS_InputSignals.Standstill_Dtct_Stat_SBSP_0)               0
p[265]	... (IO_EBS_InputSignals.sTrlrAbsOper_Stat_0)               0
p[266]	... (IO_EBS_InputSignals.sTrlrEstm_Stat_SBSP_0)               0
p[267]	... (IO_EBS_InputSignals.sVehSpd_Cval_SBSP_0)         255.996
p[268]	... (IO_EBS_InputSignals.sXBR_AccelLim_Stat_SBSP_0)              13
p[269]	... (IO_EBS_InputSignals.sXBR_ActCtrl_Stat_SBSP_0)              15
p[270]	... (IO_EBS_InputSignals.sXBR_Sys_Stat_SBSP_0)               0
p[271]	... (IO_EBS_InputSignals.sYawRateCorr_Cval_SBSP_0)           4.078
p[272]	... (IO_EBS_InputSignals.TrctrAbsOper_Stat_0)               2
p[273]	... (IO_EBS_InputSignals.TrlrAbsOper_Stat_0)               0
p[274]	... (IO_EBS_InputSignals.TrlrEstm_Stat_SBSP_0)               0
p[275]	... (IO_EBS_InputSignals.TrqConv_Cval_PT_0)            8107
p[276]	... (IO_EBS_InputSignals.TxInShaftSpd_Cval_CPC_0)         8191.88
p[277]	... (IO_EBS_InputSignals.TyreCorrLtFA_Cval_0)          0.0041
p[278]	... (IO_EBS_InputSignals.TyreCorrLtRA_Cval_0)          0.0041
p[279]	... (IO_EBS_InputSignals.TyreCorrRtFA_Cval_0)          0.0041
p[280]	... (IO_EBS_InputSignals.TyreCorrRtRA_Cval_0)          0.0041
p[281]	... (IO_EBS_InputSignals.TyreRollCircumFA_Cval_0)            3100
p[282]	... (IO_EBS_InputSignals.TyreRollCircumRA_Cval_0)            3100
p[283]	... (IO_EBS_InputSignals.VehSpd1_Cval_Trlr_0)               0
p[284]	... (IO_EBS_InputSignals.VehSpd_Cval_BS_0)               0
p[285]	... (IO_EBS_InputSignals.VehSpd_Cval_SBSP_0)               0
p[286]	... (IO_EBS_InputSignals.XBR_AccelLim_Stat_BS_0)              -2
p[287]	... (IO_EBS_InputSignals.XBR_AccelLim_Stat_SBSP_0)             255
p[288]	... (IO_EBS_InputSignals.XBR_ActCtrl_Stat_SBSP_0)              15
p[289]	... (IO_EBS_InputSignals.XBR_CtrlMode_Stat_CPC5ce_0)               0
p[290]	... (IO_EBS_InputSignals.XBR_CtrlMode_Stat_VRDU_0)               0
p[291]	... (IO_EBS_InputSignals.XBR_EBI_Stat_VRDU_0)               3
p[292]	... (IO_EBS_InputSignals.XBR_Prio_Stat_CPC5ce_0)               3
p[293]	... (IO_EBS_InputSignals.XBR_Prio_Stat_VRDU_0)               3
p[294]	... (IO_EBS_InputSignals.XBR_Sys_Stat_SBSP_0)               3
p[295]	... (IO_EBS_InputSignals.YawRateCorr_Cval_SBSP_0)           4.078
p[296]	... (IO_EBS_InputSignals.YC_BrkCtrlActv2_Stat_0)               3
p[297]	... (IO_EBS_InputSignals.YC_EngCtrlActv2_Stat_0)               3
p[298]	... (BWG.zSoll_dx_xAxis_nom) sMP.ctrl.ebs.zSoll_dx_xAxis_nom
p[299]	... (BWG.zSoll_dx_yAxis_nom) sMP.ctrl.ebs.zSoll_dx_yAxis_nom
p[300]	... (eBS_veh_Param.axleLoadTrailer02_kg) sMP.ctrl.ebs.veh.axleLoadTrailer02_kg
p[301]	... (eBS_veh_Param.axleLoadTrailer_kg) sMP.ctrl.ebs.veh.axleLoadTrailer_kg
p[302]	... (eBS_veh_Param.axleLoadVehicle_kg) sMP.ctrl.ebs.veh.axleLoadVehicle_kg
p[303]	... (eBS_veh_Param.brkCircuit) sMP.ctrl.ebs.veh.brkCircuit
p[304]	... (eBS_veh_Param.flagTrailer02ControlActive) sMP.ctrl.ebs.veh.flagTrailer02ControlActive
p[305]	... (eBS_veh_Param.flagTrailerControlActive) sMP.ctrl.ebs.veh.flagTrailerControlActive
p[306]	... (eBS_veh_Param.pAppCyl_Tractor) sMP.ctrl.ebs.veh.pAppCyl_Tractor
p[307]	... (eBS_veh_Param.pAppCyl_Trailer) sMP.ctrl.ebs.veh.pAppCyl_Trailer
p[308]	... (eBS_veh_Param.pAppCyl_Trailer02) sMP.ctrl.ebs.veh.pAppCyl_Trailer02
p[309]	... (eBS_veh_Param.rdynTrailer02) sMP.ctrl.ebs.veh.rdynTrailer02
p[310]	... (eBS_veh_Param.speedSensorPosnVeh) sMP.ctrl.ebs.veh.speedSensorPosnVeh

Curves: