
#include "ITI_crt.h"
#include "ITI_LinSolver.h"
#if defined (ITI_SIMULINK_S_FUNC) || defined (ITI_SFuncSolver)
#include "simstruc.h"
#endif
#if defined (ITI_CE_ETAS_LABCAR) || defined (ITI_SIMULINK_S_FUNC) || defined (\
ITI_SFuncSolver) || defined (ITI_FMI_CS2)
#include "ITI_NonLinSolver_ebs_rebuild_generic_std_sf.h"
#else
#include "ITI_NonLinSolver.h"
#endif
#ifdef ITI_DSPACE
#undef _x
#undef _y
#endif
void __CAT(InitEmbeddingData,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,
ITI_EmbeddingData*zdcec0d15c5,ITI_uint za4489f0b51,ITI_uint bxind_homlast,
ITI_uint z77c4719614){zbd9e9bc5b8 ITI_uint zce99d8264d;ITI_uint z9e4f0600bc=
bxind_homlast-za4489f0b51;ITI_int zb9c72bfb92=max(z77c4719614,z9e4f0600bc);
zdcec0d15c5->z4eeebcd909=z9e4f0600bc;zdcec0d15c5->z90bbed6de0=za4489f0b51;
zdcec0d15c5->z25f5c17222=z77c4719614;zdcec0d15c5->ze8fdbc6343=(z77c4719614>=
z9e4f0600bc);zdcec0d15c5->z9e92215ca6=(ITI_real*)calloc(z77c4719614,sizeof(
ITI_real));zdcec0d15c5->z4bc2586276=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->bx_tmp=(ITI_real*)calloc(bxind_homlast,sizeof(ITI_real))
;zdcec0d15c5->z8a41d0006a=(ITI_real*)calloc(z9e4f0600bc,sizeof(ITI_real));
zdcec0d15c5->z44a72f7bfb=(ITI_real*)calloc(z9e4f0600bc,sizeof(ITI_real));
zdcec0d15c5->z434f62ee93=(ITI_real*)calloc(z9e4f0600bc,sizeof(ITI_real));
zdcec0d15c5->z411b5a9678=(ITI_real*)calloc(z9e4f0600bc,sizeof(ITI_real));
zdcec0d15c5->z3960d6c10a=(ITI_real*)calloc(z9e4f0600bc*z77c4719614,sizeof(
ITI_real));zdcec0d15c5->z8ccfbd4931=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->ze7514d6a7f=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->z8d4186ad41=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->z8a73e5ac9c=(ITI_real*)calloc(z77c4719614,sizeof(
ITI_real));zdcec0d15c5->z34b6b98586=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->zf7377f07fe=(ITI_uint*)calloc(z9e4f0600bc,sizeof(
ITI_uint));zdcec0d15c5->zf4ae93b057=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->ze94ec32586=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->z4c54a1eefd=(ITI_real*)calloc(z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->z51391e3ef1=(ITI_real*)calloc(zb9c72bfb92,sizeof(
ITI_real));zdcec0d15c5->zf667805127=(ITI_real*)calloc(zb9c72bfb92,sizeof(
ITI_real));for(zce99d8264d=(0xca8+1235-0x117b);zce99d8264d<z9e4f0600bc;
zce99d8264d++){zdcec0d15c5->z34b6b98586[zce99d8264d]=1.0;zdcec0d15c5->
zf4ae93b057[zce99d8264d]=DBL_EPSILON;zdcec0d15c5->z4c54a1eefd[zce99d8264d]=1.0;
zdcec0d15c5->ze94ec32586[zce99d8264d]=-1.0;}zdcec0d15c5->zc81779069f=(ITI_uint*)
calloc(z9e4f0600bc,sizeof(ITI_uint));zdcec0d15c5->z264c1cd328=(0x1+5511-0x1588);
zdcec0d15c5->z72506057c6=1.0;__CAT(z74e5623a8b,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,
z9e4f0600bc,z77c4719614);assert(sizeof(integer)==sizeof(ITI_int));assert(sizeof(
doublereal)==sizeof(ITI_real));zdcec0d15c5->z9e95b22d7f.a=zdcec0d15c5->
z3960d6c10a;zdcec0d15c5->z9e95b22d7f.m=z77c4719614;zdcec0d15c5->z9e95b22d7f.n=
z9e4f0600bc;zdcec0d15c5->z9e95b22d7f.ldb=z9e4f0600bc;lls_init(&zdcec0d15c5->
z9e95b22d7f);zdcec0d15c5->z9e95b22d7f.work=calloc(zdcec0d15c5->z9e95b22d7f.lwork
,sizeof(ITI_real));zdcec0d15c5->z9e95b22d7f.jpvt=calloc(z9e4f0600bc,sizeof(
ITI_int));zdcec0d15c5->ze957e2faee=(ITI_real*)calloc(_pData->size.izf,sizeof(
ITI_real));zdcec0d15c5->zed744e2941=(ITI_real*)calloc(_pData->size.izf,sizeof(
ITI_real));zdcec0d15c5->z09e05a7a6d=(ITI_real*)calloc(_pData->size.izf,sizeof(
ITI_real));zdcec0d15c5->z417a4f498b=(ITI_real*)calloc(zdcec0d15c5->z4eeebcd909,
sizeof(ITI_real));}void __CAT(zb3611fe3f7,_ebs_rebuild_generic_std_sf)(ITI_EmbeddingData*
zdcec0d15c5){free(zdcec0d15c5->z9e92215ca6);free(zdcec0d15c5->z4bc2586276);free(
zdcec0d15c5->bx_tmp);free(zdcec0d15c5->z8a41d0006a);free(zdcec0d15c5->
z44a72f7bfb);free(zdcec0d15c5->z434f62ee93);free(zdcec0d15c5->z411b5a9678);free(
zdcec0d15c5->z3960d6c10a);free(zdcec0d15c5->z03e5515547);free(zdcec0d15c5->
zf08be7baa7);free(zdcec0d15c5->z6473e0bce5);free(zdcec0d15c5->z8ba7bd6cb6);free(
zdcec0d15c5->work);free(zdcec0d15c5->z8ccfbd4931);free(zdcec0d15c5->ze7514d6a7f)
;free(zdcec0d15c5->z8d4186ad41);free(zdcec0d15c5->z8a73e5ac9c);free(zdcec0d15c5
->z34b6b98586);free(zdcec0d15c5->zf7377f07fe);free(zdcec0d15c5->zf4ae93b057);
free(zdcec0d15c5->ze94ec32586);free(zdcec0d15c5->z4c54a1eefd);free(zdcec0d15c5->
zc81779069f);free(zdcec0d15c5->z51391e3ef1);free(zdcec0d15c5->zf667805127);free(
zdcec0d15c5->z9e95b22d7f.work);free(zdcec0d15c5->z9e95b22d7f.jpvt);free(
zdcec0d15c5->ze957e2faee);free(zdcec0d15c5->zed744e2941);free(zdcec0d15c5->
z09e05a7a6d);free(zdcec0d15c5->z417a4f498b);}void __CAT(z39328dfd8f,_ebs_rebuild_generic_std_sf)
(ITI_EmbeddingParams*z6952f3187e,ITI_real za5d9603097,ITI_real z62eb1a3615){
z6952f3187e->z95f376aec4=1e-8;z6952f3187e->z26b200c34d=(0x19d5+3048-0x25b3);
z6952f3187e->z5c954d713f=0.2;z6952f3187e->z4bfea9a90b=0.5;z6952f3187e->
zfdee43babc=0.3;z6952f3187e->z432f21aa64=0.5*z6952f3187e->zfdee43babc;
z6952f3187e->z81339bb7b3=2.0;z6952f3187e->z717ffc7f4b=(0x2233+1502-0x2429);
z6952f3187e->z0920b53d5c=1.0e-8;z6952f3187e->zc9298ae764=0.1;z6952f3187e->
z8021017b9a=-0.5;z6952f3187e->z1e52fe5184=1.01;z6952f3187e->z8e8b5dbf80=
(0x705+7857-0x25ac);z6952f3187e->zc72a658dd9=(0x6ed+5730-0x1967);z6952f3187e->
z0466e2bdbb=0.0;z6952f3187e->zc55b8fab64=z6952f3187e->z95f376aec4;z6952f3187e->
zbe0284b765=z6952f3187e->z26b200c34d;z6952f3187e->z881e726654=0.1;z6952f3187e->
ze59e1c0f65=0.9;z6952f3187e->zb389952bf4=za5d9603097;z6952f3187e->z298a09d9bc=
z62eb1a3615;z6952f3187e->z1ae0008de8=(0x859+33-0x866);z6952f3187e->za49a3a96d0=
0.1;z6952f3187e->z6dbe734b84=0.5;z6952f3187e->z7930998139=1e-5;z6952f3187e->
z1903a1d1d0=(0x135b+3165-0x1fb8);}void __CAT(z74e5623a8b,_ebs_rebuild_generic_std_sf)(
ITI_EmbeddingData*zdcec0d15c5,ITI_uint z9e4f0600bc,ITI_uint z77c4719614){ITI_int
 zbcd06d4a67;ITI_real z2cead138df;ITI_int m=z77c4719614;ITI_int n=zdcec0d15c5->
z4eeebcd909;ITI_int zed7121633b=min(m,n);ITI_int z0544068583=max(
(0x1d3c+2461-0x26d8),m);ITI_char zf325a54eb5=((char)(0x3f5+5322-0x187e));
ITI_char z68981c957f=((char)(0xc2f+2509-0x15bb));zdcec0d15c5->z03e5515547=(
ITI_real*)calloc(z77c4719614*z77c4719614,sizeof(ITI_real));zdcec0d15c5->
zf08be7baa7=(ITI_real*)calloc(zed7121633b,sizeof(ITI_real));zdcec0d15c5->
z6473e0bce5=(ITI_real*)calloc(z9e4f0600bc*z9e4f0600bc,sizeof(ITI_real));
zdcec0d15c5->z8ba7bd6cb6=(ITI_real*)calloc(z9e4f0600bc*z9e4f0600bc,sizeof(
ITI_real));zdcec0d15c5->lwork=-(0x72f+2988-0x12da);dgesvd_(&zf325a54eb5,&
z68981c957f,&m,&n,NULL,&z0544068583,NULL,NULL,&z0544068583,NULL,&n,&z2cead138df,
&zdcec0d15c5->lwork,&zbcd06d4a67);zdcec0d15c5->lwork=(ITI_int)z2cead138df;
zdcec0d15c5->work=(ITI_real*)calloc(zdcec0d15c5->lwork,sizeof(ITI_real));}void
__CAT(InitHomotopy,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,
ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,ITI_uint
za4489f0b51,ITI_uint bxind_homlast,ITI_uint z77c4719614,ITI_real za5d9603097,
ITI_real z62eb1a3615){z15f3b3f7db zbd9e9bc5b8
#if defined _EMI_HOMOTOPY
ITI_HomMinMax*hmm;
#endif
__CAT(InitEmbeddingData,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,
za4489f0b51,bxind_homlast,z77c4719614);__CAT(z39328dfd8f,_ebs_rebuild_generic_std_sf)(
z6952f3187e,za5d9603097,z62eb1a3615);
#ifdef _FMIMODEL_HOMOTOPY
_data->hmm=(ITI_HomMinMax*)_data->functions.allocateMemory((0x138d+887-0x1703),
sizeof(ITI_HomMinMax));
#elif defined _EMI_HOMOTOPY
hmm=(ITI_HomMinMax*)calloc((0x2b9+8534-0x240e),sizeof(ITI_HomMinMax));
#else
_data->hmm=(ITI_HomMinMax*)calloc((0x91f+6566-0x22c4),sizeof(ITI_HomMinMax));
#endif
#ifdef _EMI_HOMOTOPY
InitHomMinMax(hmm,zdcec0d15c5->z4eeebcd909);emcGetPWork(__C)[(0x3ca+4613-0x15be)
]=hmm;
#else
InitHomMinMax(_data->hmm,zdcec0d15c5->z4eeebcd909);
#endif
_bstate(zdcec0d15c5->z90bbed6de0)=1.0;}void __CAT(FreeHomotopy,_ebs_rebuild_generic_std_sf)(void
*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5){z15f3b3f7db
#ifdef _EMI_HOMOTOPY
ITI_HomMinMax*hmm=(struct ITI_HomMinMax*)emcGetPWork(__C)[(0xc47+1184-0x10d6)];
#endif
#ifdef _EMI_HOMOTOPY
FreeHomMinMax(hmm,zdcec0d15c5->z4eeebcd909);
#else
FreeHomMinMax(_data->hmm,zdcec0d15c5->z4eeebcd909);
#endif
#ifdef _FMIMODEL_HOMOTOPY
_data->functions.freeMemory(_data->hmm);
#elif defined _EMI_HOMOTOPY
free(hmm);
#else
free(_data->hmm);
#endif
__CAT(zb3611fe3f7,_ebs_rebuild_generic_std_sf)(zdcec0d15c5);}ITI_uint __CAT(CalcCurve,
_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){z15f3b3f7db zbd9e9bc5b8
ITI_Model*model=(ITI_Model*)zf48d7e43ff;
#ifdef _EMI_HOMOTOPY
ITI_real z3f082f8bdc[_pData->size.z600a6fd606+(0xa92+117-0xb06)];ITI_real*zf=&(
emcGetRWork(__C)[_pData->size.zbf83df116e]);
#endif
ITI_int z01a44ab058=(0x7b+7499-0x1dc6);ITI_uint zce99d8264d,z09d05839f2=
(0x12e8+422-0x148e);ITI_uint zd74042d590=(0xd0b+5753-0x2384);ITI_real
zcfb665793f,zb87c4bff82,z5e3656c9b1;ITI_real*z8c8519dc9d=(ITI_real*)calloc(
zdcec0d15c5->z4eeebcd909,sizeof(ITI_real));ITI_real*z97eabe881c=(ITI_real*)
calloc(zdcec0d15c5->z4eeebcd909,sizeof(ITI_real));
#ifdef zf26266bf1d
z7006c31b6f*zf0f8ffbaae=z9c1d462f32("\x70\x61\x74\x68\x2e\x74\x78\x74",
"\x77\x2b");fprintf(zf0f8ffbaae,
"\x53\x74\x65\x70" "\t" "\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79" "\t" "\x53\x74\x65\x70\x20\x73\x69\x7a\x65" "\n"
);fprintf(zf0f8ffbaae,
"\x30" "\t" "\x20\x30" "\t" "\x25\x2d\x2e\x31\x37\x67" "\n",z6952f3187e->
z5c954d713f);
#endif
z5e407f1d0d z6952f3187e->ze954f3cce4=z6952f3187e->z5c954d713f;z6952f3187e->
zc55b8fab64=z6952f3187e->z95f376aec4;z6952f3187e->zbe0284b765=z6952f3187e->
z26b200c34d;_bstate(zdcec0d15c5->z90bbed6de0)=0.0;zdcec0d15c5->z8a41d0006a[
(0x11e8+716-0x14b4)]=1.0;_sInfo.isEmbed=(0x14df+3070-0x20dc);z6952f3187e->
z1a8d55b886=(0x3ec+2947-0xf6f);_sInfo.bUseSimpleHomotopy=(0xbbb+4161-0x1bfb);
z01a44ab058=zb1f36b2499 if(z01a44ab058>(0x150+125-0x1cd)){ITI_char zea4cd01646[
(0x19a8+3303-0x2590)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70\x75\x74\x65\x20\x63\x6f\x6e\x73\x69\x73\x74\x65\x6e\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x20\x76\x61\x6c\x75\x65\x73\x20\x6f\x66\x20\x74\x68\x65\x20\x73\x74\x61\x72\x74\x20\x70\x6f\x69\x6e\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x75\x72\x76\x65\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x30\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0xda0+2963-0x1932);}_sInfo.isEvent=(0x446+8689-0x2637);__CAT(z1fe51ea564,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5->zed744e2941);z01a44ab058=__CAT
(z6d34c7efdb,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);if(z01a44ab058<(0x4b4+2231-0xd6b)){ITI_char zea4cd01646[
(0x1196+1136-0x1507)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70\x75\x74\x65\x20\x63\x6f\x6e\x73\x69\x73\x74\x65\x6e\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x20\x76\x61\x6c\x75\x65\x73\x20\x6f\x66\x20\x74\x68\x65\x20\x73\x74\x61\x72\x74\x20\x70\x6f\x69\x6e\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x75\x72\x76\x65\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x30\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x19d4+1795-0x20d6);}_bstate(zdcec0d15c5->z90bbed6de0)=0.0;_sInfo.
bUseSimpleHomotopy=(0xfff+1526-0x15f5);_sInfo.isEmbed=(0x865+2682-0x12dd);__CAT(
z1faac1090f,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);if(
__CAT(z97f5bd8a23,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff)>(0x5b7+4975-0x1926)){ITI_char zea4cd01646[(0x1b70+767-0x1d70)];
sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x61\x6e\x67\x65\x6e\x74\x20\x63\x6f\x6d\x70\x75\x74\x61\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x30\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x1253+4783-0x2501);}for(zce99d8264d=(0x43c+7186-0x204e);zce99d8264d<
zdcec0d15c5->z4eeebcd909;zce99d8264d++){z8c8519dc9d[zce99d8264d]=_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0);z97eabe881c[zce99d8264d]=zdcec0d15c5->
z8a41d0006a[zce99d8264d];}zcfb665793f=_bstate(zdcec0d15c5->z90bbed6de0);
z6952f3187e->ze954f3cce4=min(z6952f3187e->ze954f3cce4,z6952f3187e->zbe0284b765);
while(zd74042d590<z6952f3187e->z717ffc7f4b){__CAT(z828752be51,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);zd74042d590++;z6952f3187e->
zbe0284b765=z6952f3187e->z26b200c34d;if(__CAT(zfcc32624f6,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff)>(0xffc+4456-0x2164)
){free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x166+5896-0x186d);}zb87c4bff82=zcfb665793f;zcfb665793f=_bstate(
zdcec0d15c5->z90bbed6de0);z5e3656c9b1=z6952f3187e->zc9298ae764*fabs(zcfb665793f-
zb87c4bff82)+z6952f3187e->z0920b53d5c;if(zcfb665793f>=1.0-z5e3656c9b1){if(
zdcec0d15c5->z44a72f7bfb[(0x40+8827-0x22bb)]!=0.0)__CAT(zfa5fa8855f,_ebs_rebuild_generic_std_sf)
(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,(0x623+463-0x7f2),(1.0-
zdcec0d15c5->z8ccfbd4931[(0x450+1066-0x87a)])/zdcec0d15c5->z44a72f7bfb[
(0xf85+5534-0x2523)]);else{ITI_char zea4cd01646[(0x3ac+7127-0x1e84)];sprintf(
zea4cd01646,
"\x54\x68\x65\x20\x63\x6f\x6d\x70\x75\x74\x65\x64\x20\x74\x61\x6e\x67\x65\x6e\x74\x20\x76\x65\x63\x74\x6f\x72\x20\x6f\x66\x20\x74\x68\x65\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x68\x61\x73\x20\x7a\x65\x72\x6f\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x76\x61\x6c\x75\x65\x20\x25\x65\x2e"
,zdcec0d15c5->z8ccfbd4931[(0x1a74+86-0x1aca)]);traceWarning(zea4cd01646,&_sInfo)
;}break;}if(zcfb665793f<z6952f3187e->z8021017b9a){if(z09d05839f2>
(0x16f2+1177-0x1b8b)){ITI_char zea4cd01646[(0x1b47+1295-0x1f57)];sprintf(
zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x68\x65\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x67\x6f\x65\x73\x20\x69\x6e\x20\x74\x68\x65\x20\x77\x72\x6f\x6e\x67\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x2e"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x5a9+3905-0x14e9);}++z09d05839f2;for(zce99d8264d=(0x3f6+2686-0xe74);
zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++){_bstate(zce99d8264d+
zdcec0d15c5->z90bbed6de0)=z8c8519dc9d[zce99d8264d];zdcec0d15c5->z8a41d0006a[
zce99d8264d]=-z97eabe881c[zce99d8264d];}zcfb665793f=_bstate(zdcec0d15c5->
z90bbed6de0);}
#ifdef zf26266bf1d
fprintf(zf0f8ffbaae,
"\x25\x75" "\t" "\x25\x2d\x2e\x31\x37\x67" "\t" "\x25\x2d\x2e\x31\x37\x67" "\n",
zd74042d590,_bstate(zdcec0d15c5->z90bbed6de0),z6952f3187e->ze954f3cce4);
#endif
if(z6952f3187e->ze954f3cce4<z6952f3187e->z95f376aec4){ITI_char zea4cd01646[
(0x13d3+2450-0x1c66)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x68\x65\x20\x73\x74\x65\x70\x20\x73\x69\x7a\x65\x20\x25\x67\x20\x69\x73\x20\x73\x6d\x61\x6c\x6c\x65\x72\x20\x74\x68\x61\x6e\x20\x74\x68\x65\x20\x6d\x69\x6e\x69\x6d\x61\x6c\x20\x73\x74\x65\x70\x20\x73\x69\x7a\x65\x20\x25\x67\x2e"
,z6952f3187e->ze954f3cce4,z6952f3187e->z95f376aec4);traceWarning(zea4cd01646,&
_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x64f+8371-0x2701);}__CAT(z1faac1090f,_ebs_rebuild_generic_std_sf)(zb425515a78,
zfb02fbb98b,zdcec0d15c5,z6952f3187e);}if(zd74042d590>=z6952f3187e->z717ffc7f4b){
ITI_char zea4cd01646[(0xa68+72-0x9b1)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x66\x61\x69\x6c\x73\x20\x61\x66\x74\x65\x72\x20\x25\x75\x20\x73\x74\x65\x70\x73\x20\x28\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x29\x2e" "\n"
,z6952f3187e->z717ffc7f4b,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(
zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x2c0+8902-0x2585);}
#ifdef zf26266bf1d
fprintf(zf0f8ffbaae,
"\x25\x75" "\t" "\x25\x2d\x2e\x31\x37\x67" "\t" "\x25\x2d\x2e\x31\x37\x67" "\n",
zd74042d590,_bstate(zdcec0d15c5->z90bbed6de0),z6952f3187e->ze954f3cce4);
#endif
__CAT(z828752be51,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);
zd74042d590++;zdcec0d15c5->z8a41d0006a[(0x9ad+4852-0x1ca1)]=(zdcec0d15c5->
z44a72f7bfb[(0x2f9+5557-0x18ae)]<0.0)?-1.0:1.0;_bstate(zdcec0d15c5->z90bbed6de0)
=1.0;zdcec0d15c5->ze8fdbc6343=(0x1dd1+463-0x1fa0);for(zce99d8264d=
(0xb9a+394-0xd23);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)zdcec0d15c5
->z8a41d0006a[zce99d8264d]=0.0;_sInfo.isEmbed=(0x1574+1340-0x1ab0);_sInfo.
isEvent=(0x14b3+3577-0x22ab);z01a44ab058=zb1f36b2499 if(z01a44ab058>
(0x1c9c+2003-0x246f)){ITI_char zea4cd01646[(0x13c1+3367-0x1fe9)];sprintf(
zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x66\x61\x69\x6c\x73\x20\x61\x74\x20\x74\x68\x65\x20\x73\x74\x6f\x70\x20\x70\x6f\x69\x6e\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x75\x72\x76\x65\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x31\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x7bb+5327-0x1c89);}z01a44ab058=__CAT(z6d34c7efdb,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);_sInfo.isEvent=
(0xc1d+5144-0x2034);if(z01a44ab058<(0xe2+8820-0x2356)){ITI_char zea4cd01646[
(0x4f9+1937-0xb8b)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x66\x61\x69\x6c\x73\x20\x61\x74\x20\x74\x68\x65\x20\x73\x74\x6f\x70\x20\x70\x6f\x69\x6e\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x75\x72\x76\x65\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x31\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);
#ifdef zf26266bf1d
zaef96f649a(zf0f8ffbaae);
#endif
return(0x1ee8+1555-0x24fa);}
#ifdef zf26266bf1d
fprintf(zf0f8ffbaae,
"\x25\x75" "\t" "\x25\x2d\x2e\x31\x37\x67" "\t" "\x25\x2d\x2e\x31\x37\x67" "\n",
zd74042d590,_bstate(zdcec0d15c5->z90bbed6de0),z6952f3187e->ze954f3cce4);
zaef96f649a(zf0f8ffbaae);
#endif
if(__CAT(z97f5bd8a23,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,
z6952f3187e,zf48d7e43ff)>(0x19f4+2286-0x22e2)){ITI_char zea4cd01646[
(0x1e8a+1780-0x247f)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x61\x6e\x67\x65\x6e\x74\x20\x63\x6f\x6d\x70\x75\x74\x61\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x31\x2e\x30\x2e" "\n"
);traceWarning(zea4cd01646,&_sInfo);free(z8c8519dc9d);free(z97eabe881c);return
(0xdad+6444-0x26d8);}_sInfo.isEmbed=(0x12fc+1815-0x1a13);free(z8c8519dc9d);free(
z97eabe881c);return(0x1bd+2029-0x9aa);}ITI_uint __CAT(z85035d0bf5,_ebs_rebuild_generic_std_sf)(
void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){z15f3b3f7db zbd9e9bc5b8
ITI_uint zce99d8264d;ITI_char zea4cd01646[(0x907+5398-0x1d1e)];ITI_uint
z7ec2813c96=(0xeb9+2611-0x18eb);ITI_real zf38d6c2ce4=0.0;ITI_real zf2146ea2b9=
0.0;ITI_real z812893a007=1.0;ITI_real zf14d711e90=0.0;ITI_real zcf8e59cd26=1.0;
ITI_uint z812c65ff2f=(0x512+988-0x8ee);__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);for(z812c65ff2f=
(0x3c7+4611-0x15ca);z812c65ff2f<z6952f3187e->z1ae0008de8;z812c65ff2f++){__CAT(
z4320d07649,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);if(__CAT(z6474127c41,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5)>(0x765+2292-0x1059))return(0x42a+6294-0x1cbf);__CAT(zf901b7d7e1,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zdcec0d15c5->z9e92215ca6,
zdcec0d15c5->z4bc2586276,z7ec2813c96);zf2146ea2b9=__CAT(z62f48093a2,_ebs_rebuild_generic_std_sf)
(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);zf14d711e90=
zf2146ea2b9/z812893a007;for(zce99d8264d=(0x12a6+2740-0x1d5a);zce99d8264d<
zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(zce99d8264d+zdcec0d15c5->
z90bbed6de0)+=zdcec0d15c5->z4bc2586276[zce99d8264d]*zdcec0d15c5->z3f01d343c0;if(
(zf2146ea2b9<=z6952f3187e->z7930998139)||((zdcec0d15c5->z3f01d343c0==1.0)&&(
zf38d6c2ce4==1.0)&&(zcf8e59cd26<1.0)&&(zf2146ea2b9<=1.0)&&((zcf8e59cd26<=
DBL_EPSILON)||(zf14d711e90<zcf8e59cd26))))return(0x1ae9+805-0x1e0e);zf38d6c2ce4=
zdcec0d15c5->z3f01d343c0;z812893a007=zf2146ea2b9;zcf8e59cd26=zf14d711e90;}
sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x4e\x6f\x20\x63\x6f\x6e\x76\x65\x72\x67\x65\x6e\x63\x65\x20\x61\x66\x74\x65\x72\x20\x25\x75\x20\x73\x74\x65\x70\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,z6952f3187e->z1ae0008de8,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(
zea4cd01646,&_sInfo);return(0x123+1276-0x61e);}ITI_uint __CAT(z8b17e620d6,
_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){ITI_uint z6fcd5db760=
(0xa81+2328-0x1398);__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5,z6952f3187e,zf48d7e43ff);return __CAT(z82aef60b72,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff,z6fcd5db760);}
ITI_uint __CAT(z82aef60b72,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,
ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff,
ITI_uint z6fcd5db760){zbd9e9bc5b8 ITI_char zea4cd01646[(0x397+366-0x406)];
ITI_uint zce99d8264d;ITI_real z720ca9f240,z8475703e80,za4112c943e;ITI_int m=
zdcec0d15c5->z25f5c17222;ITI_int n=zdcec0d15c5->z4eeebcd909;ITI_real z3f01d343c0
=0.1;ITI_uint z6fd7c833c1=(0xae6+3813-0x19cb);ITI_uint z3bbc4e81f2=
(0x658+8089-0x25f0);do{switch(z3bbc4e81f2){case(0x1216+1730-0x18d7):switch(
z6fcd5db760){case(0x1467+2116-0x1caa):__CAT(z4320d07649,_ebs_rebuild_generic_std_sf)(zb425515a78
,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);for(zce99d8264d=
(0xb0c+532-0xd20);zce99d8264d<zdcec0d15c5->z25f5c17222;zce99d8264d++){
zdcec0d15c5->z4bc2586276[zce99d8264d]=zdcec0d15c5->z9e92215ca6[zce99d8264d];
zdcec0d15c5->z9e95b22d7f.jpvt[zce99d8264d]=(0xab8+2603-0x14e3);}zdcec0d15c5->
z9e95b22d7f.m=m;zdcec0d15c5->z9e95b22d7f.n=n;zdcec0d15c5->z9e95b22d7f.ldb=n;
zdcec0d15c5->z9e95b22d7f.b=zdcec0d15c5->z4bc2586276;lls_fact(&zdcec0d15c5->
z9e95b22d7f);lls_solv(&zdcec0d15c5->z9e95b22d7f);break;case(0x518+1826-0xc38):
__CAT(z54d9b09da9,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,zdcec0d15c5->z9e92215ca6,zdcec0d15c5
->z4bc2586276);break;}zdcec0d15c5->z18c08b309a=EuklNorm(zdcec0d15c5->z4bc2586276
,zdcec0d15c5->z4eeebcd909);if(zdcec0d15c5->z18c08b309a<1e-007)return
(0xa6a+1664-0x10ea);if(z6fd7c833c1>(0x1ab2+718-0x1d80)){ITI_real z4bc2586276;for
(zce99d8264d=(0xddc+4020-0x1d90);zce99d8264d<zdcec0d15c5->z4eeebcd909;
zce99d8264d++)zdcec0d15c5->zf667805127[zce99d8264d]=zdcec0d15c5->z51391e3ef1[
zce99d8264d]-zdcec0d15c5->z4bc2586276[zce99d8264d];z4bc2586276=EuklNorm(
zdcec0d15c5->zf667805127,zdcec0d15c5->z4eeebcd909);if(z4bc2586276==0.0)
z3f01d343c0=1.0;else{za4112c943e=zdcec0d15c5->z22d4438c10*zdcec0d15c5->
zfaa7d86a2c*z3f01d343c0/(z4bc2586276*zdcec0d15c5->z18c08b309a);z3f01d343c0=max(
min(1.0,za4112c943e),1e-008);}}z6ccc5f5e83 case(0x736+3264-0x13f1):z6fd7c833c1++
;if(z3f01d343c0<1e-008){sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x4e\x6f\x20\x63\x6f\x6e\x76\x65\x72\x67\x65\x6e\x63\x65\x20\x28\x64\x61\x6d\x70\x69\x6e\x67\x29\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
z6fcd5db760;}for(zce99d8264d=(0xad7+1405-0x1054);zce99d8264d<zdcec0d15c5->
z4eeebcd909;zce99d8264d++)_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)-=
z3f01d343c0*zdcec0d15c5->z4bc2586276[zce99d8264d];__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)
(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);for(zce99d8264d=
(0x695+3699-0x1508);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)
zdcec0d15c5->z51391e3ef1[zce99d8264d]=0.0;switch(z6fcd5db760){case
(0x1d2a+2411-0x2694):for(zce99d8264d=(0x1afa+72-0x1b42);zce99d8264d<zdcec0d15c5
->z25f5c17222;zce99d8264d++)zdcec0d15c5->z51391e3ef1[zce99d8264d]=zdcec0d15c5->
z9e92215ca6[zce99d8264d];zdcec0d15c5->z9e95b22d7f.b=zdcec0d15c5->z51391e3ef1;
lls_solv(&zdcec0d15c5->z9e95b22d7f);break;case(0x627+4149-0x165a):__CAT(
z54d9b09da9,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,zdcec0d15c5->z9e92215ca6,zdcec0d15c5->
z51391e3ef1);break;}zdcec0d15c5->zfaa7d86a2c=EuklNorm(zdcec0d15c5->z51391e3ef1,
zdcec0d15c5->z4eeebcd909);for(zce99d8264d=(0x1004+232-0x10ec);zce99d8264d<
zdcec0d15c5->z4eeebcd909;zce99d8264d++)zdcec0d15c5->zf667805127[zce99d8264d]=
zdcec0d15c5->z51391e3ef1[zce99d8264d]+(z3f01d343c0-1.0)*zdcec0d15c5->z4bc2586276
[zce99d8264d];z8475703e80=EuklNorm(zdcec0d15c5->zf667805127,zdcec0d15c5->
z4eeebcd909);{ITI_real zc9ad6c3dc6=(0.5*zdcec0d15c5->z18c08b309a*z3f01d343c0*
z3f01d343c0);if(zc9ad6c3dc6<1e35*z8475703e80)za4112c943e=zc9ad6c3dc6/z8475703e80
;else za4112c943e=1e+35;}if(zdcec0d15c5->zfaa7d86a2c>=zdcec0d15c5->z18c08b309a){
z720ca9f240=min(za4112c943e,0.5*z3f01d343c0);if(z3f01d343c0<=1e-008)z3f01d343c0=
z720ca9f240;else z3f01d343c0=max(z720ca9f240,1e-008);zdcec0d15c5->ze4a8849194=
(0x1b7+7321-0x1e4f);z5e407f1d0d z3bbc4e81f2=(0x9ef+1237-0xebf);continue;}
z720ca9f240=min(1.0,za4112c943e);if(z3f01d343c0==1.0&&z720ca9f240==1.0){if(
zdcec0d15c5->zfaa7d86a2c<=1e-007)return(0x21ab+1293-0x26b8);}else{if(z720ca9f240
>=4.0*z3f01d343c0&&zdcec0d15c5->ze4a8849194==(0x1786+3038-0x2364)){z3f01d343c0=
z720ca9f240;zdcec0d15c5->ze4a8849194=(0xa6f+3776-0x192e);z5e407f1d0d z3bbc4e81f2
=(0x615+698-0x8ca);continue;}}zdcec0d15c5->ze4a8849194=(0x180a+3757-0x26b7);
zdcec0d15c5->z22d4438c10=zdcec0d15c5->z18c08b309a;z3bbc4e81f2=
(0xc4f+2518-0x1624);}}while(z6fd7c833c1<z6952f3187e->z1ae0008de8);sprintf(
zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x4e\x6f\x20\x63\x6f\x6e\x76\x65\x72\x67\x65\x6e\x63\x65\x20\x61\x66\x74\x65\x72\x20\x25\x75\x20\x73\x74\x65\x70\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,z6952f3187e->z1ae0008de8,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(
zea4cd01646,&_sInfo);return z6fcd5db760;}ITI_uint __CAT(z97f5bd8a23,_ebs_rebuild_generic_std_sf)
(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){z15f3b3f7db zbd9e9bc5b8
ITI_uint zce99d8264d,z26dbd73a5e;ITI_real zd8bb6b5553;ITI_real zf7f2900287;__CAT
(z4320d07649,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);if(__CAT(z6474127c41,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5)>(0xf63+442-0x111d))return(0x82a+2412-0x1195);zdcec0d15c5->
ze4482e84dd=zdcec0d15c5->z4eeebcd909-zdcec0d15c5->z7663004f47;for(zce99d8264d=
(0xad+7587-0x1e50);zce99d8264d<zdcec0d15c5->ze4482e84dd;zce99d8264d++)
zdcec0d15c5->z434f62ee93[zce99d8264d]=zdcec0d15c5->z6473e0bce5[zdcec0d15c5->
z7663004f47+zce99d8264d];zf7f2900287=EuklNorm(zdcec0d15c5->z434f62ee93,
zdcec0d15c5->ze4482e84dd);if(zf7f2900287==0.0){for(zce99d8264d=(0x131+676-0x3d5)
;zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++){zdcec0d15c5->z411b5a9678[
zce99d8264d]=zdcec0d15c5->z6473e0bce5[(int)floor(z6952f3187e->z1903a1d1d0/2.0)+
zdcec0d15c5->z7663004f47+zdcec0d15c5->z4eeebcd909*zce99d8264d];}z6952f3187e->
z1903a1d1d0++;if(floor(z6952f3187e->z1903a1d1d0/2.0)>=zdcec0d15c5->ze4482e84dd)
z6952f3187e->z1903a1d1d0=(0x4b1+1207-0x968);}else{for(zce99d8264d=
(0x3f3+4820-0x16c7);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++){
zdcec0d15c5->z411b5a9678[zce99d8264d]=0.0;for(z26dbd73a5e=(0xfb3+3017-0x1b7c);
z26dbd73a5e<zdcec0d15c5->ze4482e84dd;z26dbd73a5e++)zdcec0d15c5->z411b5a9678[
zce99d8264d]+=zdcec0d15c5->z6473e0bce5[zdcec0d15c5->z7663004f47+z26dbd73a5e+
zdcec0d15c5->z4eeebcd909*zce99d8264d]*zdcec0d15c5->z434f62ee93[z26dbd73a5e];
zdcec0d15c5->z411b5a9678[zce99d8264d]/=zf7f2900287;}}__CAT(z11cd768e30,
_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z411b5a9678,z6952f3187e->z26b200c34d,zdcec0d15c5->
z4eeebcd909);if(SProd(zdcec0d15c5->z8a41d0006a,zdcec0d15c5->z411b5a9678,
zdcec0d15c5->z4eeebcd909)<(0xe58+2729-0x1901))__CAT(z11cd768e30,_ebs_rebuild_generic_std_sf)(
zdcec0d15c5->z411b5a9678,-1.0,zdcec0d15c5->z4eeebcd909);if(__hmm->considerLimit)
__CAT(zb3da54817e,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zdcec0d15c5->
z411b5a9678);zd8bb6b5553=__CAT(zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z411b5a9678
,zdcec0d15c5->z34b6b98586,zdcec0d15c5->z4eeebcd909);for(zce99d8264d=
(0x9d+6045-0x183a);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)
zdcec0d15c5->z8a41d0006a[zce99d8264d]=zdcec0d15c5->z411b5a9678[zce99d8264d]/
zd8bb6b5553;z6952f3187e->zbe0284b765=max(z6952f3187e->z95f376aec4,min(
z6952f3187e->z26b200c34d*zdcec0d15c5->z72506057c6,z6952f3187e->zbe0284b765));if(
z6952f3187e->z26b200c34d*zdcec0d15c5->z72506057c6<z6952f3187e->z95f376aec4){
ITI_char zea4cd01646[(0x5e9+3671-0x1341)];sprintf(zea4cd01646,
"\x54\x68\x65\x20\x69\x6e\x20\x6f\x72\x64\x65\x72\x20\x74\x6f\x20\x61\x76\x6f\x69\x64\x20\x65\x78\x63\x65\x65\x64\x69\x6e\x67\x20\x74\x68\x65\x20\x6c\x69\x6d\x69\x74\x73\x20\x73\x75\x67\x67\x65\x73\x74\x65\x64\x20\x73\x74\x65\x70\x20\x73\x69\x7a\x65\x20\x25\x67\x20\x69\x73\x20\x73\x6d\x61\x6c\x6c\x65\x72\x20\x74\x68\x61\x6e\x20\x74\x68\x65\x20\x6d\x69\x6e\x69\x6d\x61\x6c\x20\x73\x74\x65\x70\x20\x73\x69\x7a\x65\x20\x25\x67\x2e\x20" "\n"
,z6952f3187e->z26b200c34d*zdcec0d15c5->z72506057c6,z6952f3187e->z95f376aec4);
traceWarning(zea4cd01646,&_sInfo);return(0x176+7167-0x1d74);}return
(0x794+4890-0x1aae);}ITI_uint __CAT(zfcc32624f6,_ebs_rebuild_generic_std_sf)(void*zb425515a78,
void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,
void*zf48d7e43ff){z15f3b3f7db zbd9e9bc5b8 ITI_uint z01a44ab058;ITI_uint
z0d48c638e3=(0x64b+3892-0x157f);ITI_int zbc03e9b268=-(0x1530+1631-0x1b8e);
z6952f3187e->za494561071=z6952f3187e->z4bfea9a90b;do{for(z6952f3187e->
zcb80911ce0=(0x13fb+4432-0x254b);z6952f3187e->ze954f3cce4>=z6952f3187e->
zc55b8fab64;z6952f3187e->ze954f3cce4*=z6952f3187e->z4bfea9a90b,z6952f3187e->
zcb80911ce0=(0x1098+4397-0x21c5)){__CAT(zfa5fa8855f,_ebs_rebuild_generic_std_sf)(zb425515a78,
zfb02fbb98b,zdcec0d15c5,z6952f3187e,-(0x463+2067-0xc75),z6952f3187e->ze954f3cce4
);z01a44ab058=__CAT(z6e964533e7,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5
,z6952f3187e,zf48d7e43ff);if(z01a44ab058==(0x7f4+1189-0xc98))return
(0x674+8140-0x263f);else if(z01a44ab058==(0x683+2347-0xfac))continue;else
z6952f3187e->z1a8d55b886=(0x1b64+506-0x1d5d);__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);if(__CAT(
z97f5bd8a23,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff)>(0x2151+344-0x22a9)){ITI_char zea4cd01646[(0xe7f+3487-0x1b1f)];
sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x61\x6e\x67\x65\x6e\x74\x20\x63\x6f\x6d\x70\x75\x74\x61\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
(0x1d81+1651-0x23f3);}__CAT(z097b6f9bf5,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,z6952f3187e);if
(z6952f3187e->z0466e2bdbb<=z6952f3187e->zfdee43babc)break;}if(z6952f3187e->
ze954f3cce4<z6952f3187e->zc55b8fab64){if(__CAT(z85035d0bf5,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff)>
(0x1b17+1799-0x221e))return(0x1838+2849-0x2358);z6952f3187e->z1a8d55b886=
(0x11bc+2316-0x1ac7);}z6952f3187e->zcb80911ce0=(0xa69+3629-0x1896);zbc03e9b268=
__CAT(z6d34c7efdb,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);if(zbc03e9b268<(0x59+1682-0x6eb)){z6952f3187e->zcb80911ce0=
(0x1111+4047-0x20df);z6952f3187e->ze954f3cce4=max(z6952f3187e->z95f376aec4,0.99*
z6952f3187e->ze954f3cce4);}if(z6952f3187e->zcb80911ce0){if(++z0d48c638e3>
z6952f3187e->z8e8b5dbf80){ITI_char zea4cd01646[(0x501+5835-0x1acd)];sprintf(
zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x68\x65\x20\x6d\x61\x78\x69\x6d\x61\x6c\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x25\x75\x20\x72\x65\x74\x72\x69\x65\x73\x20\x28\x77\x69\x74\x68\x20\x72\x65\x64\x75\x63\x65\x64\x20\x73\x74\x65\x70\x20\x73\x69\x7a\x65\x29\x20\x61\x66\x74\x65\x72\x20\x61\x20\x72\x65\x70\x65\x61\x74\x65\x64\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x70\x6f\x69\x6e\x74\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x65\x78\x63\x65\x65\x64\x65\x64\x20\x69\x6e\x20\x61\x20\x68\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x73\x74\x65\x70\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,z6952f3187e->z8e8b5dbf80,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(
zea4cd01646,&_sInfo);return(0x4d4+2646-0xf29);}}else break;}while(
(0x1b41+46-0x1b6e));if(zbc03e9b268>(0x2fc+5814-0x19b2))z6952f3187e->ze954f3cce4=
z6952f3187e->z5c954d713f;else if(z6952f3187e->ze954f3cce4<z6952f3187e->
zc55b8fab64)z6952f3187e->ze954f3cce4=z6952f3187e->z95f376aec4;else{__CAT(
zbb1a877b64,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);}
return(0x229b+1107-0x26ee);}void __CAT(zbb1a877b64,_ebs_rebuild_generic_std_sf)(void*zb425515a78
,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e)
{zbd9e9bc5b8 ITI_real z26505f5082=__CAT(zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(zdcec0d15c5->
z8a41d0006a,zdcec0d15c5->z34b6b98586,zdcec0d15c5->z4eeebcd909);ITI_real
z31b80bfa3d=zdcec0d15c5->z8a41d0006a[(0xd3c+5733-0x23a1)]/z26505f5082;ITI_real
z4675d8a028;z6952f3187e->za494561071=max(z6952f3187e->za494561071,z6952f3187e->
z0466e2bdbb/z6952f3187e->z432f21aa64);if(z6952f3187e->za494561071*z6952f3187e->
zbe0284b765>z6952f3187e->ze954f3cce4)z6952f3187e->ze954f3cce4=max(z6952f3187e->
z95f376aec4,z6952f3187e->ze954f3cce4/z6952f3187e->za494561071);else z6952f3187e
->ze954f3cce4=min(z6952f3187e->zbe0284b765,z6952f3187e->ze954f3cce4/z6952f3187e
->z4bfea9a90b);z4675d8a028=_bstate(zdcec0d15c5->z90bbed6de0)+z31b80bfa3d*
z6952f3187e->ze954f3cce4;if(z4675d8a028>1.0)z6952f3187e->ze954f3cce4=max(
z6952f3187e->z95f376aec4,z6952f3187e->z1e52fe5184*(1.0-_bstate(zdcec0d15c5->
z90bbed6de0))/z31b80bfa3d);}ITI_uint __CAT(z6e964533e7,_ebs_rebuild_generic_std_sf)(void*
zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*
z6952f3187e,void*zf48d7e43ff){zbd9e9bc5b8 ITI_uint zce99d8264d;ITI_real
z9439e49293,zdc8d9bb183;ITI_uint z7ec2813c96=(0x101+7622-0x1ec6);ITI_uint
z6fd7c833c1=(0x2200+142-0x228e);__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,
zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);if(__CAT(z97f5bd8a23,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff)>
(0xbd6+3774-0x1a94)){ITI_char zea4cd01646[(0x1407+3690-0x2172)];sprintf(
zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x61\x6e\x67\x65\x6e\x74\x20\x63\x6f\x6d\x70\x75\x74\x61\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
(0x25b+9172-0x262e);}__CAT(z097b6f9bf5,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,z6952f3187e);if(
z6952f3187e->z0466e2bdbb>z6952f3187e->zfdee43babc)return(0x71+7408-0x1d5f);__CAT
(zf901b7d7e1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zdcec0d15c5->
z9e92215ca6,zdcec0d15c5->z4bc2586276,z7ec2813c96);for(zce99d8264d=
(0x138d+1858-0x1acf);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)+=zdcec0d15c5->z4bc2586276[zce99d8264d];
z6fd7c833c1++;if(__CAT(z5d747ed95f,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
z6952f3187e,zdcec0d15c5->z4bc2586276,zdcec0d15c5->z34b6b98586,zdcec0d15c5->
z4eeebcd909,zdcec0d15c5->z90bbed6de0,&z9439e49293))return(0xcf+2826-0xbd9);if(
z9439e49293>z6952f3187e->z881e726654)return(0xf36+1540-0x1538);__CAT(zf29e330b26
,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);__CAT
(zf901b7d7e1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zdcec0d15c5->
z9e92215ca6,zdcec0d15c5->z4bc2586276,z7ec2813c96);for(zce99d8264d=
(0xd2f+2444-0x16bb);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)+=zdcec0d15c5->z4bc2586276[zce99d8264d];
z6fd7c833c1++;if(__CAT(z5d747ed95f,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
z6952f3187e,zdcec0d15c5->z4bc2586276,zdcec0d15c5->z34b6b98586,zdcec0d15c5->
z4eeebcd909,zdcec0d15c5->z90bbed6de0,&zdc8d9bb183))return(0xae5+1819-0x1200);if(
z9439e49293*z6952f3187e->ze59e1c0f65<zdc8d9bb183)return(0x1ab2+2208-0x2350);if(
__CAT(z8b17e620d6,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff)>(0xb6b+141-0xbf8))return(0x7b4+6598-0x2178);return
(0x236+5799-0x18dd);}ITI_uint __CAT(z8401db3b7b,_ebs_rebuild_generic_std_sf)(void*zb425515a78,
void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,
void*zf48d7e43ff){zbd9e9bc5b8 ITI_uint z6fcd5db760=(0xe75+3807-0x1d52);__CAT(
zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);if(__CAT(z97f5bd8a23,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5,z6952f3187e,zf48d7e43ff)>(0xf5+2955-0xc80)){ITI_char zea4cd01646[
(0x50b+3842-0x130e)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x54\x61\x6e\x67\x65\x6e\x74\x20\x63\x6f\x6d\x70\x75\x74\x61\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x3d\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
(0x1585+3190-0x21fa);}__CAT(z097b6f9bf5,_ebs_rebuild_generic_std_sf)(zdcec0d15c5,z6952f3187e);if
(z6952f3187e->z0466e2bdbb>z6952f3187e->zfdee43babc)return(0xa27+5378-0x1f27);
return __CAT(z82aef60b72,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,
z6952f3187e,zf48d7e43ff,z6fcd5db760);}ITI_real __CAT(z62f48093a2,_ebs_rebuild_generic_std_sf)(
void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){zbd9e9bc5b8 ITI_real
z988292fecc;ITI_real zd3919aa600,z73789d311b;ITI_real z52754d10b7,z84df455267;
ITI_uint zce99d8264d;zdcec0d15c5->z3f01d343c0=1.0;z6ccc5f5e83 for(zce99d8264d=
(0x1fa6+1273-0x249f);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)+=zdcec0d15c5->z4bc2586276[zce99d8264d];
__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);z5e407f1d0d zd3919aa600=__CAT(z8315707fda,_ebs_rebuild_generic_std_sf)(zb425515a78,
zfb02fbb98b,zdcec0d15c5,z6952f3187e);
#ifdef ITI_COMP_SIM
z988292fecc=__CAT(ze7161a9726,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->z4bc2586276,
_pData->bx,zdcec0d15c5->z4eeebcd909,zdcec0d15c5->z90bbed6de0);
#elif defined _EMI_HOMOTOPY
z988292fecc=__CAT(z66842ef5f7,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->z4bc2586276,
((ITI_real*)emcGetPWork(__C)[(0x144a+1582-0x1a6a)]),zdcec0d15c5->z4eeebcd909,
zdcec0d15c5->z90bbed6de0);
#else
z988292fecc=__CAT(z66842ef5f7,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->z4bc2586276,
_pData->bx,zdcec0d15c5->z4eeebcd909,zdcec0d15c5->z90bbed6de0);
#endif
if(zd3919aa600<=z6952f3187e->ze59e1c0f65*z988292fecc)return zd3919aa600;
zdcec0d15c5->z3f01d343c0=min(max(z6952f3187e->za49a3a96d0,0.5*z988292fecc/
zd3919aa600),0.7*zdcec0d15c5->z3f01d343c0);z6ccc5f5e83 for(zce99d8264d=
(0x2fa+4207-0x1369);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)+=zdcec0d15c5->z3f01d343c0*zdcec0d15c5->
z4bc2586276[zce99d8264d];__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5,z6952f3187e,zf48d7e43ff);z5e407f1d0d z73789d311b=__CAT(z8315707fda,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);if(z73789d311b<=
z6952f3187e->ze59e1c0f65*z988292fecc)return z73789d311b;z52754d10b7=(z73789d311b
-z988292fecc*(1.0-zdcec0d15c5->z3f01d343c0)-zd3919aa600*int_pow(zdcec0d15c5->
z3f01d343c0,(0xf25+4029-0x1edf)))/(int_pow(zdcec0d15c5->z3f01d343c0,
(0x1456+1989-0x1c19))*(1.0-zdcec0d15c5->z3f01d343c0));z84df455267=-z52754d10b7/(
3.0*(zd3919aa600-z52754d10b7));zdcec0d15c5->z3f01d343c0=min(max(min(z84df455267+
sqrt(int_pow(z84df455267,(0x1abf+1638-0x2123))+z988292fecc),z6952f3187e->
z6dbe734b84*zdcec0d15c5->z3f01d343c0),z6952f3187e->za49a3a96d0*zdcec0d15c5->
z3f01d343c0),0.7*zdcec0d15c5->z3f01d343c0);z6ccc5f5e83 for(zce99d8264d=
(0x6e9+6390-0x1fdf);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)+=zdcec0d15c5->z3f01d343c0*zdcec0d15c5->
z4bc2586276[zce99d8264d];__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5,z6952f3187e,zf48d7e43ff);z5e407f1d0d return __CAT(z8315707fda,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e);}void __CAT(
z4320d07649,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*
zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff){zbd9e9bc5b8
ITI_uint zce99d8264d,z26dbd73a5e,z812c65ff2f;ITI_real z7493f886db;z6ccc5f5e83
CopyVars(zdcec0d15c5->z9e92215ca6,zdcec0d15c5->z8a73e5ac9c,(0x1b1c+478-0x1cfa),
zdcec0d15c5->z25f5c17222);for(zce99d8264d=(0xf3c+4583-0x2123);zce99d8264d<
zdcec0d15c5->z4eeebcd909;zce99d8264d++){z812c65ff2f=zce99d8264d+zdcec0d15c5->
z90bbed6de0;z7493f886db=min(max(fabs(_bstate(z812c65ff2f))*sqrt(DBL_EPSILON),
z6952f3187e->zb389952bf4),__MAX_PERT);_bstate(z812c65ff2f)+=z7493f886db;__CAT(
zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);for(z26dbd73a5e=(0x1bfb+1328-0x212b);z26dbd73a5e<zdcec0d15c5->
z25f5c17222;z26dbd73a5e++)zdcec0d15c5->z3960d6c10a[zce99d8264d*zdcec0d15c5->
z25f5c17222+z26dbd73a5e]=(zdcec0d15c5->z9e92215ca6[z26dbd73a5e]-zdcec0d15c5->
z8a73e5ac9c[z26dbd73a5e])/z7493f886db;_bstate(z812c65ff2f)=zdcec0d15c5->bx_tmp[
z812c65ff2f];}z5e407f1d0d _sInfo.isEmbed=(0x11c+3605-0xf2e);__CAT(zf29e330b26,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff);_sInfo
.isEmbed=(0x811+4783-0x1abe);}void __CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(void*
zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*
z6952f3187e,void*zf48d7e43ff){z15f3b3f7db zbd9e9bc5b8 ITI_Model*model=(ITI_Model
*)zf48d7e43ff;
#ifdef _EMI_HOMOTOPY
ITI_real z3f082f8bdc[_pData->size.z600a6fd606+(0x138a+3044-0x1f6d)];ITI_real*zf=
&(emcGetRWork(__C)[_pData->size.zbf83df116e]);emcGetPWork(__C)[
(0xb55+2985-0x16ec)]=(ITI_void*)zdcec0d15c5->z9e92215ca6;emcGetPWork(__C)[
(0xde1+6335-0x268d)]=(ITI_void*)zdcec0d15c5->z3960d6c10a;
#else
_data->hom_res=zdcec0d15c5->z9e92215ca6;_data->hom_jac=zdcec0d15c5->z3960d6c10a;
#endif
zb1f36b2499}ITI_int __CAT(z6d34c7efdb,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*
zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e,void*
zf48d7e43ff){zbd9e9bc5b8 ITI_uint z43bff7bac5=(0x367+7339-0x2012);if(!__CAT(
z5669ea4bf3,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff,(0x4a0+7878-0x2366))){ITI_uint zce99d8264d;for(zce99d8264d=
(0x170a+2288-0x1ffa);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)
zdcec0d15c5->z417a4f498b[zce99d8264d]=_bstate(zce99d8264d+zdcec0d15c5->
z90bbed6de0);for(z43bff7bac5++;z43bff7bac5!=z6952f3187e->zc72a658dd9;z43bff7bac5
++){z6952f3187e->zcb80911ce0=(0x14a2+2760-0x1f6a);if(__CAT(z85035d0bf5,
_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,zf48d7e43ff)>
(0xbf4+4176-0x1c44)){z6952f3187e->zcb80911ce0=(0xd06+4067-0x1ce8);break;}else if
(__CAT(z5669ea4bf3,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff,(0x1f9+3093-0xe0d))){z6952f3187e->zcb80911ce0=(0x114d+2546-0x1b3f);
z6952f3187e->ze954f3cce4=z6952f3187e->z5c954d713f;break;}}if(z43bff7bac5==
z6952f3187e->zc72a658dd9){--z43bff7bac5;z6952f3187e->zcb80911ce0=
(0x583+6216-0x1dca);}if(z6952f3187e->zcb80911ce0){for(zce99d8264d=
(0x412+3728-0x12a2);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(
zce99d8264d+zdcec0d15c5->z90bbed6de0)=zdcec0d15c5->z8ccfbd4931[zce99d8264d];
__CAT(z5669ea4bf3,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff,(0x227+6171-0x1a40));for(zce99d8264d=(0x170f+2515-0x20e2);
zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)_bstate(zce99d8264d+
zdcec0d15c5->z90bbed6de0)=zdcec0d15c5->z417a4f498b[zce99d8264d];return-
(0x795+5761-0x1e15);}}return z43bff7bac5;}ITI_uint __CAT(z5669ea4bf3,_ebs_rebuild_generic_std_sf
)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,void*zf48d7e43ff,ITI_uint z00f6ed1d9c){
zbd9e9bc5b8 ITI_uint zb12cd23f9f=(0x1118+3763-0x1fcb);switch(z00f6ed1d9c){case
(0x590+5778-0x1c22):zb12cd23f9f=__CAT(z5650878f4b,_ebs_rebuild_generic_std_sf)(zb425515a78,
zfb02fbb98b,zdcec0d15c5);if(zb12cd23f9f){ITI_real z1e07cd0a35=1.0;ITI_real
zb2913d8fa6=0.99;ITI_int z4c0d9ada56;for(z4c0d9ada56=(0x55a+148-0x5ee);
z4c0d9ada56<_pData->size.izf;++z4c0d9ada56){if((zdcec0d15c5->z09e05a7a6d[
z4c0d9ada56]<0.0&&zdcec0d15c5->ze957e2faee[z4c0d9ada56]>0.0)||(zdcec0d15c5->
z09e05a7a6d[z4c0d9ada56]>0.0&&zdcec0d15c5->ze957e2faee[z4c0d9ada56]<0.0)){
ITI_real z7ada113a3a=zdcec0d15c5->ze957e2faee[z4c0d9ada56]/(zdcec0d15c5->
ze957e2faee[z4c0d9ada56]-zdcec0d15c5->z09e05a7a6d[z4c0d9ada56]);if(fabs(
z7ada113a3a)<z1e07cd0a35)z1e07cd0a35=fabs(z7ada113a3a);}}if(z1e07cd0a35<1.0)
zb2913d8fa6=0.9*z1e07cd0a35;if(zb2913d8fa6>0.0){z6952f3187e->zcb80911ce0=
(0xd6d+1735-0x1433);z6952f3187e->ze954f3cce4=max(z6952f3187e->z95f376aec4,min(
0.99*z6952f3187e->ze954f3cce4,zb2913d8fa6*__CAT(z224a93e97c,_ebs_rebuild_generic_std_sf)(
zb425515a78,zfb02fbb98b,zdcec0d15c5)));}}break;case(0x904+3213-0x1590):
zb12cd23f9f=__CAT(z5650878f4b,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5);
break;case(0x1499+3917-0x23e4):{ITI_int z4c0d9ada56;for(z4c0d9ada56=
(0x1d44+1401-0x22bd);z4c0d9ada56<_pData->size.izf;++z4c0d9ada56)zdcec0d15c5->
zed744e2941[z4c0d9ada56]=zdcec0d15c5->ze957e2faee[z4c0d9ada56];zb12cd23f9f=
(0x1c85+2526-0x2662);break;}}if(zb12cd23f9f){_sInfo.isEvent=(0x13f1+4479-0x256f)
;__CAT(zf29e330b26,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,z6952f3187e,
zf48d7e43ff);Update_pre_z_data(zb425515a78,zfb02fbb98b);_sInfo.isEvent=
(0xdea+5744-0x245a);}else __CAT(z1fe51ea564,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b
,zdcec0d15c5->ze957e2faee);return zb12cd23f9f==(0x991+1776-0x1081)?
(0x15b7+2184-0x1e3e):(0x1430+1903-0x1b9f);}ITI_uint __CAT(z5650878f4b,
_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5){
zbd9e9bc5b8 ITI_int z4c0d9ada56;ITI_uint zb12cd23f9f=(0x1937+2930-0x24a9);__CAT(
z1fe51ea564,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5->z09e05a7a6d);for(
z4c0d9ada56=(0x1211+3964-0x218d);z4c0d9ada56<_pData->size.izf;++z4c0d9ada56){if(
(zdcec0d15c5->z09e05a7a6d[z4c0d9ada56]<0.0&&zdcec0d15c5->zed744e2941[z4c0d9ada56
]>=0.0)||(zdcec0d15c5->z09e05a7a6d[z4c0d9ada56]>0.0&&zdcec0d15c5->zed744e2941[
z4c0d9ada56]<=0.0))zb12cd23f9f=(0x141f+2181-0x1ca3);zdcec0d15c5->zed744e2941[
z4c0d9ada56]=zdcec0d15c5->z09e05a7a6d[z4c0d9ada56];}return zb12cd23f9f;}void
__CAT(z1fe51ea564,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,ITI_real*
z09e05a7a6d){zbd9e9bc5b8 ITI_int z4c0d9ada56;for(z4c0d9ada56=(0x22d+6152-0x1a35)
;z4c0d9ada56<_pData->size.izf;++z4c0d9ada56){
#ifdef _EMI_HOMOTOPY
#else
z09e05a7a6d[z4c0d9ada56]=_pData->zf[z4c0d9ada56];
#endif
}}void __CAT(z1faac1090f,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,
ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*z6952f3187e){zbd9e9bc5b8
ITI_uint zce99d8264d,ze8cf17c11e,z760cb77366=(0x88b+5543-0x1e32);ITI_real*
zbd05723d83=(ITI_real*)calloc(zdcec0d15c5->z4eeebcd909,sizeof(ITI_real));for(
zce99d8264d=(0x11f2+4914-0x2523);zce99d8264d<zdcec0d15c5->z4eeebcd909;
zce99d8264d++){if(_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)>zdcec0d15c5->
z4c54a1eefd[zce99d8264d])zdcec0d15c5->z4c54a1eefd[zce99d8264d]=zdcec0d15c5->
ze94ec32586[zce99d8264d]+z6952f3187e->z81339bb7b3*(_bstate(zce99d8264d+
zdcec0d15c5->z90bbed6de0)-zdcec0d15c5->ze94ec32586[zce99d8264d]);else if(_bstate
(zce99d8264d+zdcec0d15c5->z90bbed6de0)<zdcec0d15c5->ze94ec32586[zce99d8264d])
zdcec0d15c5->ze94ec32586[zce99d8264d]=zdcec0d15c5->z4c54a1eefd[zce99d8264d]+
z6952f3187e->z81339bb7b3*(_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)-
zdcec0d15c5->z4c54a1eefd[zce99d8264d]);else continue;if(zdcec0d15c5->z34b6b98586
[zce99d8264d]*(zdcec0d15c5->z4c54a1eefd[zce99d8264d]-zdcec0d15c5->ze94ec32586[
zce99d8264d])>1.0){if(!z760cb77366){ITI_real z26505f5082=__CAT(zab7ffcf1ba,
_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z8a41d0006a,zdcec0d15c5->z34b6b98586,zdcec0d15c5->
z4eeebcd909);if(z26505f5082<DBL_EPSILON){ITI_char zea4cd01646[
(0x12e2+1272-0x16db)];sprintf(zea4cd01646,
"\x54\x68\x65\x20\x63\x6f\x6d\x70\x75\x74\x65\x64\x20\x74\x61\x6e\x67\x65\x6e\x74\x20\x76\x65\x63\x74\x6f\x72\x20\x6f\x66\x20\x74\x68\x65\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x68\x61\x73\x20\x7a\x65\x72\x6f\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x76\x61\x6c\x75\x65\x20\x25\x65\x2e"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);for(
ze8cf17c11e=(0x21a6+1129-0x260f);ze8cf17c11e<zdcec0d15c5->z4eeebcd909;
ze8cf17c11e++)zbd05723d83[ze8cf17c11e]=z6952f3187e->ze954f3cce4*zdcec0d15c5->
z8a41d0006a[ze8cf17c11e]/DBL_EPSILON;}else{for(ze8cf17c11e=(0x106b+4470-0x21e1);
ze8cf17c11e<zdcec0d15c5->z4eeebcd909;ze8cf17c11e++)zbd05723d83[ze8cf17c11e]=
z6952f3187e->ze954f3cce4*zdcec0d15c5->z8a41d0006a[ze8cf17c11e]/z26505f5082;}}
zdcec0d15c5->z34b6b98586[zce99d8264d]=max((0x1462+3122-0x2093)/(zdcec0d15c5->
z4c54a1eefd[zce99d8264d]-zdcec0d15c5->ze94ec32586[zce99d8264d]),zdcec0d15c5->
zf4ae93b057[zce99d8264d]);z760cb77366=(0x16c8+1512-0x1caf);}}if(z760cb77366){
z6952f3187e->ze954f3cce4=__CAT(zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(zbd05723d83,zdcec0d15c5
->z34b6b98586,zdcec0d15c5->z4eeebcd909);z6952f3187e->zc55b8fab64=min(z6952f3187e
->z95f376aec4,z6952f3187e->ze954f3cce4);}free(zbd05723d83);}void __CAT(
z4bc25bef61,_ebs_rebuild_generic_std_sf)(ITI_real*a,ITI_real*b,ITI_uint z1581844784){ITI_uint
zce99d8264d;for(zce99d8264d=(0x6d+1240-0x545);zce99d8264d<z1581844784;
zce99d8264d++)a[zce99d8264d]/=b[zce99d8264d];}void __CAT(z11cd768e30,_ebs_rebuild_generic_std_sf
)(ITI_real*a,ITI_real z1437e7d647,ITI_uint z1581844784){ITI_uint zce99d8264d;for
(zce99d8264d=(0x15a4+2576-0x1fb4);zce99d8264d<z1581844784;zce99d8264d++)a[
zce99d8264d]*=z1437e7d647;}ITI_uint __CAT(z6474127c41,_ebs_rebuild_generic_std_sf)(void*
zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5){zbd9e9bc5b8 if(__CAT
(z5551e92655,_ebs_rebuild_generic_std_sf)(zdcec0d15c5)>(0x1060+2285-0x194d)){ITI_char
zea4cd01646[(0x51c+7671-0x2214)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x53\x56\x44\x20\x64\x65\x63\x6f\x6d\x70\x6f\x73\x69\x74\x69\x6f\x6e\x20\x66\x61\x69\x6c\x73\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x3d\x20\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
(0x1108+361-0x1270);}if(zdcec0d15c5->zf08be7baa7[(0xe28+730-0x1102)]==0.0)
zdcec0d15c5->z7663004f47=(0x1230+664-0x14c8);else{ITI_uint zce99d8264d=min(
zdcec0d15c5->z25f5c17222,zdcec0d15c5->z4eeebcd909);while((zce99d8264d>
(0xaa6+6811-0x2541))&&(zdcec0d15c5->zf08be7baa7[zce99d8264d-(0x132+4865-0x1432)]
<10.0*DBL_EPSILON*zdcec0d15c5->zf08be7baa7[(0x1b05+106-0x1b6f)]))zce99d8264d--;
zdcec0d15c5->z7663004f47=zce99d8264d;}if(zdcec0d15c5->z7663004f47>=zdcec0d15c5->
z4eeebcd909){ITI_char zea4cd01646[(0xc05+3312-0x17f6)];sprintf(zea4cd01646,
"\x45\x72\x72\x6f\x72\x3a\x20\x4b\x65\x72\x6e\x65\x6c\x20\x6f\x66\x20\x74\x68\x65\x20\x4a\x61\x63\x6f\x62\x69\x61\x6e\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x20\x66\x6f\x72\x20\x6c\x61\x6d\x62\x64\x61\x48\x6f\x6d\x6f\x74\x6f\x70\x79\x20\x3d\x20\x25\x2d\x2e\x31\x37\x67\x2e" "\n"
,_bstate(zdcec0d15c5->z90bbed6de0));traceWarning(zea4cd01646,&_sInfo);return
(0xceb+1450-0x1294);}return(0x1f7d+1071-0x23ac);}void __CAT(z54d9b09da9,
_ebs_rebuild_generic_std_sf)(ITI_EmbeddingData*zdcec0d15c5,ITI_real*z9e92215ca6,ITI_real*
zbd05723d83){ITI_uint zce99d8264d,z26dbd73a5e;ITI_uint z1581844784=zdcec0d15c5->
z4eeebcd909;ITI_uint z77c4719614=zdcec0d15c5->z25f5c17222;memset((void*)
zdcec0d15c5->z8d4186ad41,(0xaf3+1741-0x11c0),zdcec0d15c5->z7663004f47*sizeof(
ITI_real));memset((void*)zbd05723d83,(0xcda+4075-0x1cc5),z1581844784*sizeof(
ITI_real));for(zce99d8264d=(0x4a3+7596-0x224f);zce99d8264d<z77c4719614;
zce99d8264d++)for(z26dbd73a5e=(0x935+3905-0x1876);z26dbd73a5e<z77c4719614;
z26dbd73a5e++)zdcec0d15c5->z8d4186ad41[zce99d8264d]+=zdcec0d15c5->z03e5515547[
zce99d8264d*z77c4719614+z26dbd73a5e]*z9e92215ca6[z26dbd73a5e];for(zce99d8264d=
(0xdc1+6431-0x26e0);zce99d8264d<zdcec0d15c5->z7663004f47;zce99d8264d++)
zdcec0d15c5->z8d4186ad41[zce99d8264d]/=zdcec0d15c5->zf08be7baa7[zce99d8264d];for
(zce99d8264d=zdcec0d15c5->z7663004f47;zce99d8264d<z1581844784;zce99d8264d++)
zdcec0d15c5->z8d4186ad41[zce99d8264d]=0.0;for(zce99d8264d=(0x198d+972-0x1d59);
zce99d8264d<z1581844784;zce99d8264d++)for(z26dbd73a5e=(0x9bb+3574-0x17b1);
z26dbd73a5e<z1581844784;z26dbd73a5e++)zbd05723d83[zce99d8264d]+=zdcec0d15c5->
z6473e0bce5[zce99d8264d*z1581844784+z26dbd73a5e]*zdcec0d15c5->z8d4186ad41[
z26dbd73a5e];}ITI_uint __CAT(z5551e92655,_ebs_rebuild_generic_std_sf)(ITI_EmbeddingData*
zdcec0d15c5){ITI_int zbcd06d4a67;ITI_int m=zdcec0d15c5->z25f5c17222;ITI_int n=
zdcec0d15c5->z4eeebcd909;ITI_char zf325a54eb5=((char)(0x11d7+1909-0x190b));
ITI_char z68981c957f=((char)(0xffb+5889-0x26bb));memset((void*)zdcec0d15c5->work
,(0x16eb+2832-0x21fb),zdcec0d15c5->lwork*sizeof(ITI_real));dgesvd_(&zf325a54eb5,
&z68981c957f,&m,&n,zdcec0d15c5->z3960d6c10a,&m,zdcec0d15c5->zf08be7baa7,
zdcec0d15c5->z03e5515547,&m,zdcec0d15c5->z6473e0bce5,&n,zdcec0d15c5->work,&
zdcec0d15c5->lwork,&zbcd06d4a67);return zbcd06d4a67;}ITI_real __CAT(zb82f30584a,
_ebs_rebuild_generic_std_sf)(ITI_real*z7b058c25be,ITI_real*z6e0310fb34,ITI_real*zf667805127,
ITI_uint z1581844784){ITI_real z3c32d4e665=__CAT(z9383ee8374,_ebs_rebuild_generic_std_sf)(
z7b058c25be,z6e0310fb34,zf667805127,z1581844784);ITI_real zb0d9bb9d1a=__CAT(
zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(z7b058c25be,zf667805127,z1581844784)*__CAT(zab7ffcf1ba,
_ebs_rebuild_generic_std_sf)(z6e0310fb34,zf667805127,z1581844784);if((zb0d9bb9d1a>=DBL_MIN)&&(
fabs(z3c32d4e665)<zb0d9bb9d1a))return acos(z3c32d4e665/zb0d9bb9d1a);else if(
z3c32d4e665<=-zb0d9bb9d1a)return 2.0*acos(0.);else return 0.0;}ITI_real __CAT(
z9383ee8374,_ebs_rebuild_generic_std_sf)(ITI_real*z7b058c25be,ITI_real*z6e0310fb34,ITI_real*
zf667805127,ITI_uint z1581844784){ITI_uint zce99d8264d;ITI_real z7be9105675;
ITI_real zdb5468ea8f=0.0;for(zce99d8264d=(0x1b63+501-0x1d58);zce99d8264d<
z1581844784;zce99d8264d++){z7be9105675=zf667805127[zce99d8264d]*zf667805127[
zce99d8264d];zdb5468ea8f+=z7b058c25be[zce99d8264d]*z6e0310fb34[zce99d8264d]*
z7be9105675;}return zdb5468ea8f;}ITI_real __CAT(z224a93e97c,_ebs_rebuild_generic_std_sf)(void*
zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5){zbd9e9bc5b8 ITI_uint
 zce99d8264d;ITI_real z5e26adef18=0.;for(zce99d8264d=(0x83c+4726-0x1ab2);
zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)z5e26adef18=max(z5e26adef18,
fabs(zdcec0d15c5->z34b6b98586[zce99d8264d]*(_bstate(zdcec0d15c5->z90bbed6de0+
zce99d8264d)-zdcec0d15c5->z8ccfbd4931[zce99d8264d])));if(z5e26adef18!=0.){
ITI_real z6fcd2c121f=0.;for(zce99d8264d=(0x145f+4342-0x2555);zce99d8264d<
zdcec0d15c5->z4eeebcd909;zce99d8264d++){ITI_real z7be9105675=((zdcec0d15c5->
z34b6b98586[zce99d8264d]*(_bstate(zdcec0d15c5->z90bbed6de0+zce99d8264d)-
zdcec0d15c5->z8ccfbd4931[zce99d8264d]))/z5e26adef18);z6fcd2c121f+=z7be9105675*
z7be9105675;}z5e26adef18*=sqrt(z6fcd2c121f);}return z5e26adef18;}ITI_real __CAT(
zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(ITI_real*za04057655a,ITI_real*z82425fa37c,ITI_uint
z1581844784){ITI_uint zce99d8264d;ITI_real z5e26adef18=0.;for(zce99d8264d=
(0x634+3204-0x12b8);zce99d8264d<z1581844784;zce99d8264d++)z5e26adef18=max(
z5e26adef18,fabs(za04057655a[zce99d8264d]*z82425fa37c[zce99d8264d]));if(
z5e26adef18!=0.){ITI_real z6fcd2c121f=0.;for(zce99d8264d=(0x1624+3223-0x22bb);
zce99d8264d<z1581844784;zce99d8264d++){ITI_real z7be9105675=((za04057655a[
zce99d8264d]*z82425fa37c[zce99d8264d])/z5e26adef18);z6fcd2c121f+=z7be9105675*
z7be9105675;}z5e26adef18*=sqrt(z6fcd2c121f);}return z5e26adef18;}ITI_real __CAT(
z48766ede72,_ebs_rebuild_generic_std_sf)(ITI_real*za04057655a,ITI_real*z82425fa37c,ITI_uint
z1581844784,ITI_uint zf1cdc30602){ITI_uint zce99d8264d;ITI_real z5e26adef18=0.0;
for(zce99d8264d=(0x9af+34-0x9d1);zce99d8264d<z1581844784;zce99d8264d++)
z5e26adef18=max(z5e26adef18,fabs(za04057655a[zce99d8264d+zf1cdc30602]*
z82425fa37c[zce99d8264d]));if(z5e26adef18!=0.){ITI_real z6fcd2c121f=0.;for(
zce99d8264d=(0x3a+287-0x159);zce99d8264d<z1581844784;zce99d8264d++){ITI_real
z7be9105675=((za04057655a[zce99d8264d+zf1cdc30602]*z82425fa37c[zce99d8264d])/
z5e26adef18);z6fcd2c121f+=z7be9105675*z7be9105675;}z5e26adef18*=sqrt(z6fcd2c121f
);}return z5e26adef18;}ITI_real __CAT(zc1c3f4c2b5,_ebs_rebuild_generic_std_sf)(ITI_real**
za04057655a,ITI_real*z82425fa37c,ITI_uint z1581844784,ITI_uint zf1cdc30602){
ITI_uint zce99d8264d;ITI_real z5e26adef18=0.0;for(zce99d8264d=
(0x149a+4346-0x2594);zce99d8264d<z1581844784;zce99d8264d++)z5e26adef18=max(
z5e26adef18,fabs(*za04057655a[zce99d8264d+zf1cdc30602]*z82425fa37c[zce99d8264d])
);if(z5e26adef18!=0.){ITI_real z6fcd2c121f=0.;for(zce99d8264d=
(0x96a+1694-0x1008);zce99d8264d<z1581844784;zce99d8264d++){ITI_real z7be9105675=
((*za04057655a[zce99d8264d+zf1cdc30602]*z82425fa37c[zce99d8264d])/z5e26adef18);
z6fcd2c121f+=z7be9105675*z7be9105675;}z5e26adef18*=sqrt(z6fcd2c121f);}return
z5e26adef18;}ITI_real __CAT(z66842ef5f7,_ebs_rebuild_generic_std_sf)(ITI_EmbeddingParams*
z6952f3187e,ITI_real*z3f082f8bdc,ITI_real*za04057655a,ITI_uint z1581844784,
ITI_uint zf1cdc30602){ITI_uint zce99d8264d;ITI_real z5e26adef18=0.0;for(
zce99d8264d=(0x496+325-0x5db);zce99d8264d<z1581844784;zce99d8264d++)z5e26adef18=
max(z5e26adef18,fabs(z3f082f8bdc[zce99d8264d]/(z6952f3187e->zb389952bf4+
z6952f3187e->z298a09d9bc*fabs(za04057655a[zce99d8264d+zf1cdc30602]))));if(
z5e26adef18!=0.){ITI_real z6fcd2c121f=0.;for(zce99d8264d=(0xc00+3896-0x1b38);
zce99d8264d<z1581844784;zce99d8264d++){ITI_real z7be9105675=(z3f082f8bdc[
zce99d8264d]/(z6952f3187e->zb389952bf4+z6952f3187e->z298a09d9bc*fabs(za04057655a
[zce99d8264d+zf1cdc30602])))/z5e26adef18;z6fcd2c121f+=z7be9105675*z7be9105675;}
z5e26adef18*=sqrt(z6fcd2c121f);}return z5e26adef18;}ITI_real __CAT(ze7161a9726,
_ebs_rebuild_generic_std_sf)(ITI_EmbeddingParams*z6952f3187e,ITI_real*z3f082f8bdc,ITI_real**
za04057655a,ITI_uint z1581844784,ITI_uint zf1cdc30602){ITI_uint zce99d8264d;
ITI_real z5e26adef18=0.;for(zce99d8264d=(0x181c+2500-0x21e0);zce99d8264d<
z1581844784;zce99d8264d++)z5e26adef18=max(z5e26adef18,fabs(z3f082f8bdc[
zce99d8264d]/(z6952f3187e->zb389952bf4+z6952f3187e->z298a09d9bc*fabs(*
za04057655a[zce99d8264d+zf1cdc30602]))));if(z5e26adef18!=0.){ITI_real
z6fcd2c121f=0.;for(zce99d8264d=(0x1b8+9194-0x25a2);zce99d8264d<z1581844784;
zce99d8264d++){ITI_real z7be9105675=(z3f082f8bdc[zce99d8264d]/(z6952f3187e->
zb389952bf4+z6952f3187e->z298a09d9bc*fabs(*za04057655a[zce99d8264d+zf1cdc30602])
))/z5e26adef18;z6fcd2c121f+=z7be9105675*z7be9105675;}z5e26adef18*=sqrt(
z6fcd2c121f);}return z5e26adef18;}ITI_real __CAT(z8315707fda,_ebs_rebuild_generic_std_sf)(void*
zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*
z6952f3187e){zbd9e9bc5b8 ITI_uint zce99d8264d;ITI_uint z7ec2813c96=
(0x8a9+3785-0x1772);for(zce99d8264d=(0x472+6072-0x1c2a);zce99d8264d<zdcec0d15c5
->z4eeebcd909;zce99d8264d++)zdcec0d15c5->ze7514d6a7f[zce99d8264d]=0.0;__CAT(
zf901b7d7e1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zdcec0d15c5->
z9e92215ca6,zdcec0d15c5->ze7514d6a7f,z7ec2813c96);
#ifdef ITI_COMP_SIM
return __CAT(ze7161a9726,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->ze7514d6a7f,
_pData->bx,zdcec0d15c5->z4eeebcd909,zdcec0d15c5->z90bbed6de0);
#elif defined _EMI_HOMOTOPY
return __CAT(z66842ef5f7,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->ze7514d6a7f,((
ITI_real*)emcGetPWork(__C)[(0x364+6730-0x1da0)]),zdcec0d15c5->z4eeebcd909,
zdcec0d15c5->z90bbed6de0);
#else
return __CAT(z66842ef5f7,_ebs_rebuild_generic_std_sf)(z6952f3187e,zdcec0d15c5->ze7514d6a7f,
_pData->bx,zdcec0d15c5->z4eeebcd909,zdcec0d15c5->z90bbed6de0);
#endif
}ITI_uint __CAT(z5d747ed95f,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*zfb02fbb98b,
ITI_EmbeddingParams*z6952f3187e,ITI_real*zbd05723d83,ITI_real*z82425fa37c,
ITI_uint z1581844784,ITI_uint zf1cdc30602,ITI_real*z9439e49293){zbd9e9bc5b8
ITI_real za26b66afdf;
#ifdef ITI_COMP_SIM
za26b66afdf=__CAT(zc1c3f4c2b5,_ebs_rebuild_generic_std_sf)(_pData->bx,z82425fa37c,z1581844784,
zf1cdc30602);
#elif defined _EMI_HOMOTOPY
za26b66afdf=__CAT(z48766ede72,_ebs_rebuild_generic_std_sf)(((ITI_real*)emcGetPWork(__C)[
(0xc73+6486-0x25bb)]),z82425fa37c,z1581844784,zf1cdc30602);
#else
za26b66afdf=__CAT(z48766ede72,_ebs_rebuild_generic_std_sf)(_pData->bx,z82425fa37c,z1581844784,
zf1cdc30602);
#endif
*z9439e49293=__CAT(zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(zbd05723d83,z82425fa37c,z1581844784)
;return(*z9439e49293<z6952f3187e->z298a09d9bc*za26b66afdf+z6952f3187e->
zb389952bf4);}void __CAT(zf901b7d7e1,_ebs_rebuild_generic_std_sf)(void*zb425515a78,void*
zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_real*z9e92215ca6,ITI_real*
zbd05723d83,ITI_uint z7ec2813c96){z15f3b3f7db zbd9e9bc5b8 __CAT(z54d9b09da9,
_ebs_rebuild_generic_std_sf)(zdcec0d15c5,z9e92215ca6,zbd05723d83);__CAT(z11cd768e30,_ebs_rebuild_generic_std_sf)
(zbd05723d83,-1.0,zdcec0d15c5->z4eeebcd909);if(z7ec2813c96){if(__hmm->
considerLimit){__CAT(zb3da54817e,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,
zdcec0d15c5,zbd05723d83);__CAT(z11cd768e30,_ebs_rebuild_generic_std_sf)(zbd05723d83,zdcec0d15c5
->z72506057c6,zdcec0d15c5->z4eeebcd909);}}}void __CAT(zfa5fa8855f,_ebs_rebuild_generic_std_sf)(
void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e,ITI_int zaa5147cc6a,ITI_real zbd762e14d2){
zbd9e9bc5b8 ITI_uint zce99d8264d;if(z6952f3187e->z1a8d55b886){if(zaa5147cc6a>=
(0x8da+6533-0x225f)){ITI_real z00a6472bbe=_bstate(zaa5147cc6a+zdcec0d15c5->
z90bbed6de0)-zdcec0d15c5->z8ccfbd4931[zaa5147cc6a];if(z00a6472bbe<DBL_EPSILON){
ITI_char zea4cd01646[(0x1671+3808-0x2452)];sprintf(zea4cd01646,
"\x54\x68\x65\x20\x63\x6f\x6d\x70\x75\x74\x65\x64\x20\x74\x61\x6e\x67\x65\x6e\x74\x20\x76\x65\x63\x74\x6f\x72\x20\x6f\x66\x20\x74\x68\x65\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x68\x61\x73\x20\x7a\x65\x72\x6f\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x76\x61\x6c\x75\x65\x20\x25\x65\x2e"
,zdcec0d15c5->z8ccfbd4931[zaa5147cc6a]);traceWarning(zea4cd01646,&_sInfo);__CAT(
zf162d5c8f1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zaa5147cc6a,
zbd762e14d2*zdcec0d15c5->z44a72f7bfb[zaa5147cc6a]/DBL_EPSILON);}else __CAT(
zf162d5c8f1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zaa5147cc6a,
zbd762e14d2*zdcec0d15c5->z44a72f7bfb[zaa5147cc6a]/z00a6472bbe);}else{ITI_real
ze005fc796d=__CAT(z224a93e97c,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5);
__CAT(zf162d5c8f1,_ebs_rebuild_generic_std_sf)(zb425515a78,zfb02fbb98b,zdcec0d15c5,zaa5147cc6a,
zbd762e14d2/ze005fc796d);}}else{ITI_real z26505f5082=__CAT(zab7ffcf1ba,
_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z44a72f7bfb,zdcec0d15c5->z34b6b98586,zdcec0d15c5->
z4eeebcd909);if(z26505f5082<DBL_EPSILON){ITI_char zea4cd01646[
(0x607+5755-0x1b83)];sprintf(zea4cd01646,
"\x54\x68\x65\x20\x63\x6f\x6d\x70\x75\x74\x65\x64\x20\x74\x61\x6e\x67\x65\x6e\x74\x20\x76\x65\x63\x74\x6f\x72\x20\x6f\x66\x20\x74\x68\x65\x20\x65\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x70\x61\x74\x68\x20\x68\x61\x73\x20\x7a\x65\x72\x6f\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x76\x61\x6c\x75\x65\x20\x25\x65\x2e"
,zdcec0d15c5->z8ccfbd4931[(0x103a+2384-0x198a)]);traceWarning(zea4cd01646,&
_sInfo);}for(zce99d8264d=(0x229a+665-0x2533);zce99d8264d<zdcec0d15c5->
z4eeebcd909;zce99d8264d++){if((z26505f5082<DBL_EPSILON)||(zaa5147cc6a>=
(0x10c8+4722-0x233a)))_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)=zdcec0d15c5
->z8ccfbd4931[zce99d8264d]+zbd762e14d2*zdcec0d15c5->z44a72f7bfb[zce99d8264d];
else _bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)=zdcec0d15c5->z8ccfbd4931[
zce99d8264d]+zbd762e14d2*zdcec0d15c5->z44a72f7bfb[zce99d8264d]/z26505f5082;
zdcec0d15c5->z8a41d0006a[zce99d8264d]=zdcec0d15c5->z44a72f7bfb[zce99d8264d];}}
z6952f3187e->z1a8d55b886=(0xd06+3900-0x1c42);}void __CAT(zf162d5c8f1,_ebs_rebuild_generic_std_sf
)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_int
zaa5147cc6a,ITI_real z82803ff4d1){zbd9e9bc5b8 ITI_uint zce99d8264d;ITI_real
z705a029a29=__CAT(zab7ffcf1ba,_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z44a72f7bfb,zdcec0d15c5
->z34b6b98586,zdcec0d15c5->z4eeebcd909);ITI_real z17727c7045,zf81159d307,
z89f5814a4b,z1100b66e46,z8cf49f35be,zbb236df42a,z528e38ee4f,zc25b82582e,
z8b03b8bfd8,z72506057c6,z6fcd2c121f;for(zce99d8264d=(0x64a+6483-0x1f9d);
zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++){_bstate(zce99d8264d+
zdcec0d15c5->z90bbed6de0)-=zdcec0d15c5->z8ccfbd4931[zce99d8264d];}z17727c7045=
0.0;for(zce99d8264d=(0x1900+216-0x19d8);zce99d8264d<zdcec0d15c5->z4eeebcd909;
zce99d8264d++)z17727c7045=max(z17727c7045,fabs(_bstate(zdcec0d15c5->z90bbed6de0+
zce99d8264d)*zdcec0d15c5->z34b6b98586[zce99d8264d]));if(z17727c7045!=0.){
z6fcd2c121f=0.0;for(zce99d8264d=(0xb82+5224-0x1fea);zce99d8264d<zdcec0d15c5->
z4eeebcd909;zce99d8264d++){ITI_real z7be9105675=((_bstate(zdcec0d15c5->
z90bbed6de0+zce99d8264d)*zdcec0d15c5->z34b6b98586[zce99d8264d])/z17727c7045);
z6fcd2c121f+=z7be9105675*z7be9105675;}z17727c7045*=sqrt(z6fcd2c121f);}
zf81159d307=z17727c7045*z17727c7045;z6fcd2c121f=0.0;for(zce99d8264d=
(0x15f4+760-0x18ec);zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++)
z6fcd2c121f+=_bstate(zdcec0d15c5->z90bbed6de0+zce99d8264d)*zdcec0d15c5->
z44a72f7bfb[zce99d8264d]*zdcec0d15c5->z34b6b98586[zce99d8264d]*zdcec0d15c5->
z34b6b98586[zce99d8264d];z89f5814a4b=z6fcd2c121f/z705a029a29;if(zaa5147cc6a>=
(0xf7f+4252-0x201b)){ITI_real z83faf7e699=zdcec0d15c5->z34b6b98586[zaa5147cc6a];
z83faf7e699*=z83faf7e699;z1100b66e46=z83faf7e699*zdcec0d15c5->z44a72f7bfb[
zaa5147cc6a]/z705a029a29;z8cf49f35be=z83faf7e699*_bstate(zaa5147cc6a+zdcec0d15c5
->z90bbed6de0);}else{z1100b66e46=z89f5814a4b;z8cf49f35be=zf81159d307;}
zbb236df42a=2.0*(zf81159d307-z89f5814a4b*z89f5814a4b);z528e38ee4f=sqrt(fabs(
zbb236df42a));zc25b82582e=0.5*z89f5814a4b;z8b03b8bfd8=zc25b82582e+z528e38ee4f;if
(fabs(0.5*z8cf49f35be)>fabs(z8b03b8bfd8*z1100b66e46))z72506057c6=z8b03b8bfd8;
else z72506057c6=0.5*z8cf49f35be/z1100b66e46;for(zce99d8264d=(0xff2+3873-0x1f13)
;zce99d8264d<zdcec0d15c5->z4eeebcd909;zce99d8264d++){zdcec0d15c5->z8a41d0006a[
zce99d8264d]=_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)*2.0*z82803ff4d1+
zdcec0d15c5->z44a72f7bfb[zce99d8264d]*2.0*z72506057c6*(1.0-2.0*z82803ff4d1)/
z705a029a29;_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)=zdcec0d15c5->
z8ccfbd4931[zce99d8264d]+_bstate(zce99d8264d+zdcec0d15c5->z90bbed6de0)*
z82803ff4d1*z82803ff4d1+zdcec0d15c5->z44a72f7bfb[zce99d8264d]*2.0*z72506057c6*
z82803ff4d1*(1.0-z82803ff4d1)/z705a029a29;}}void __CAT(z828752be51,_ebs_rebuild_generic_std_sf)(
void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,
ITI_EmbeddingParams*z6952f3187e){zbd9e9bc5b8 ITI_uint zce99d8264d;for(
zce99d8264d=(0x1226+2939-0x1da1);zce99d8264d<zdcec0d15c5->z4eeebcd909;
zce99d8264d++){zdcec0d15c5->z8ccfbd4931[zce99d8264d]=_bstate(zce99d8264d+
zdcec0d15c5->z90bbed6de0);zdcec0d15c5->z44a72f7bfb[zce99d8264d]=zdcec0d15c5->
z8a41d0006a[zce99d8264d];}zdcec0d15c5->z7450bac220=zdcec0d15c5->ze4482e84dd;
z6952f3187e->z1a8d55b886=(0xaea+3305-0x17d3);}void __CAT(zb3da54817e,_ebs_rebuild_generic_std_sf
)(void*zb425515a78,void*zfb02fbb98b,ITI_EmbeddingData*zdcec0d15c5,ITI_real*
zbd05723d83){z15f3b3f7db zbd9e9bc5b8 ITI_uint zce99d8264d,z26dbd73a5e;
zdcec0d15c5->z72506057c6=1.0;for(zce99d8264d=(0x1df9+1117-0x2255);zce99d8264d<
zdcec0d15c5->z4eeebcd909;++zce99d8264d){z26dbd73a5e=zce99d8264d+zdcec0d15c5->
z90bbed6de0;if((__hmm->considerMin[zce99d8264d])&&(_bstate(z26dbd73a5e)+
zbd05723d83[zce99d8264d]<=__hmm->minVal[zce99d8264d])){if(zbd05723d83[
zce99d8264d]!=0.0){ITI_char zea4cd01646[(0x6e1+875-0x858)];zdcec0d15c5->
z72506057c6=min(zdcec0d15c5->z72506057c6,0.5*((__hmm->minVal[zce99d8264d]-
_bstate(z26dbd73a5e))/zbd05723d83[zce99d8264d]));sprintf(zea4cd01646,
"\x54\x68\x65\x20\x76\x61\x6c\x75\x65\x20\x25\x2d\x2e\x31\x37\x67\x20\x69\x73\x20\x62\x65\x6c\x6f\x77\x20\x74\x68\x65\x20\x6d\x69\x6e\x69\x6d\x75\x6d\x20\x28\x25\x2d\x2e\x31\x37\x67\x29\x20\x6f\x66\x20\x74\x68\x65\x20\x45\x6d\x62\x65\x64\x64\x69\x6e\x67\x20\x73\x74\x61\x74\x65\x20\x25\x73\x20\x28\x44\x61\x6d\x70\x69\x6e\x67\x20\x66\x61\x63\x74\x6f\x72\x3a\x20\x25\x2d\x2e\x31\x37\x67\x29\x2e"
,_bstate(z26dbd73a5e)+zbd05723d83[zce99d8264d],__hmm->minVal[zce99d8264d],__hmm
->name[zce99d8264d],0.5*((__hmm->minVal[zce99d8264d]-_bstate(z26dbd73a5e))/
zbd05723d83[zce99d8264d]));traceWarning(zea4cd01646,&_sInfo);}while((_bstate(
z26dbd73a5e)+zdcec0d15c5->z72506057c6*zbd05723d83[zce99d8264d]<=__hmm->minVal[
zce99d8264d])&&(zdcec0d15c5->z72506057c6!=0.0)){ITI_char zea4cd01646[
(0xad4+2521-0x131d)];zdcec0d15c5->z72506057c6/=10.0;sprintf(zea4cd01646,
"\x52\x65\x64\x75\x63\x69\x6e\x67\x20\x74\x68\x65\x20\x64\x61\x6d\x70\x69\x6e\x67\x20\x66\x61\x63\x74\x6f\x72\x20\x74\x6f\x20\x25\x2d\x2e\x31\x37\x67\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6f\x66\x20\x74\x68\x65\x20\x44\x41\x45\x20\x73\x74\x61\x74\x65\x20\x25\x73\x2e"
,zdcec0d15c5->z72506057c6,__hmm->name[zce99d8264d]);traceWarning(zea4cd01646,&
_sInfo);}}if((__hmm->considerMax[zce99d8264d])&&(_bstate(z26dbd73a5e)+
zbd05723d83[zce99d8264d]>=__hmm->maxVal[zce99d8264d])){if(zbd05723d83[
zce99d8264d]!=0.0){ITI_char zea4cd01646[(0x1d28+237-0x1c21)];zdcec0d15c5->
z72506057c6=min(zdcec0d15c5->z72506057c6,0.5*((__hmm->maxVal[zce99d8264d]-
_bstate(z26dbd73a5e))/zbd05723d83[zce99d8264d]));sprintf(zea4cd01646,
"\x54\x68\x65\x20\x76\x61\x6c\x75\x65\x20\x25\x2d\x2e\x31\x37\x67\x20\x65\x78\x63\x65\x65\x64\x73\x20\x74\x68\x65\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x28\x25\x2d\x2e\x31\x37\x67\x29\x20\x6f\x66\x20\x74\x68\x65\x20\x44\x41\x45\x20\x73\x74\x61\x74\x65\x20\x25\x73\x20\x28\x44\x61\x6d\x70\x69\x6e\x67\x20\x66\x61\x63\x74\x6f\x72\x3a\x20\x25\x2d\x2e\x31\x37\x67\x29\x2e"
,_bstate(z26dbd73a5e)+zbd05723d83[zce99d8264d],__hmm->maxVal[zce99d8264d],__hmm
->name[zce99d8264d],0.5*((__hmm->maxVal[zce99d8264d]-_bstate(z26dbd73a5e))/
zbd05723d83[zce99d8264d]));traceWarning(zea4cd01646,&_sInfo);}while((_bstate(
z26dbd73a5e)+zdcec0d15c5->z72506057c6*zbd05723d83[zce99d8264d]>=__hmm->maxVal[
zce99d8264d])&&(zdcec0d15c5->z72506057c6!=0.0)){ITI_char zea4cd01646[
(0x9ef+1560-0xe77)];zdcec0d15c5->z72506057c6/=10.0;sprintf(zea4cd01646,
"\x52\x65\x64\x75\x63\x69\x6e\x67\x20\x74\x68\x65\x20\x64\x61\x6d\x70\x69\x6e\x67\x20\x66\x61\x63\x74\x6f\x72\x20\x74\x6f\x20\x25\x2d\x2e\x31\x37\x67\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6f\x66\x20\x74\x68\x65\x20\x44\x41\x45\x20\x73\x74\x61\x74\x65\x20\x25\x73\x2e"
,zdcec0d15c5->z72506057c6,__hmm->name[zce99d8264d]);traceWarning(zea4cd01646,&
_sInfo);}}if(zdcec0d15c5->z72506057c6==0.0){ITI_char zea4cd01646[
(0x17a2+3594-0x241c)];sprintf(zea4cd01646,
"\x44\x41\x45\x20\x73\x74\x61\x74\x65\x20\x25\x73\x20\x65\x78\x63\x65\x65\x64\x73\x20\x61\x20\x62\x6f\x72\x64\x65\x72\x2e"
,__hmm->name[zce99d8264d]);traceWarning(zea4cd01646,&_sInfo);break;}}}void __CAT
(z097b6f9bf5,_ebs_rebuild_generic_std_sf)(ITI_EmbeddingData*zdcec0d15c5,ITI_EmbeddingParams*
z6952f3187e){if((zdcec0d15c5->ze4482e84dd==(0x7cc+7311-0x245a))&&(zdcec0d15c5->
z7450bac220==(0x1004+1824-0x1723)))z6952f3187e->z0466e2bdbb=__CAT(zb82f30584a,
_ebs_rebuild_generic_std_sf)(zdcec0d15c5->z8a41d0006a,zdcec0d15c5->z44a72f7bfb,zdcec0d15c5->
z34b6b98586,zdcec0d15c5->z4eeebcd909);else{fprintf(stdout,
"\x64\x69\x6d\x5f\x66\x61\x63\x74\x6f\x72\x20\x3e\x20\x31\x2e\x20\x45\x78\x74\x65\x6e\x64\x20\x43\x61\x6c\x63\x41\x6e\x67\x6c\x65\x54\x61\x6e\x67\x65\x6e\x74\x73\x2e" "\n"
);}}
