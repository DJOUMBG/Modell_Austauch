/**
 * ITI_crt.h
 * SimulationX 4.0.5.60286 (08/29/19) x64
 * Copyright (c) ESI ITI GmbH
 * All rights reserved.
**/

#ifndef ITI_CRT_INCLUDE
#define ITI_CRT_INCLUDE

#ifdef MATLAB_MEX_FILE
#undef REAL_TIME
#define ITI_BLOCK_SIZE 8192
#else
#define REAL_TIME
#define ITI_BLOCK_SIZE 1048576
#include "rt_matrx.h"
#endif

#ifndef MAX_DELAY_BUFFER_SIZE
#define MAX_DELAY_BUFFER_SIZE 655360
#endif

#define ITI_SFuncSolver
#define ITI_FUNCTIONS_API

#if defined(_MRI)
#define _ITI_INLINE
#else
#define _ITI_INLINE __inline
#endif

#ifdef _MSC_VER
#pragma warning(disable : 4996)
#endif

#if defined(_DS1005) || defined(_DS1006) || defined(_DS1102) || defined(_DS1103) || defined(_DS1104) || defined(_DS1401) || defined(_DS1602) || defined(_DS1603)
#define ITI_DSPACE
#define NO_FILE_SYSTEM
#include <BRTENV.H>

 
#define ITI_MODEL_ERROR (503)
#define ITI_SOLVER_ERROR (655)

 
#define ITI_TERMINATE (705)

 
#define ITI_SOLVER_WARNING (800)
#endif

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <float.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#if !defined(ITI_DSPACE)
#include <signal.h>
#endif
#include "ITI_Types.h"
#include "ITI_Functions.h"
#include "ITI_BlockDeclarations.h"
#include "ITI_Memory.h"
#include "ITI_ArrayFunctions.h"

#endif
