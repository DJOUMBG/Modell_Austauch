function IntegrateSimXDLL(path_system, nameext_system, name_block, name_sfun, create_library, add_path, inputs, outputs, params, solver_settings)
% Opens/creates Simulink model and sets mask and position of generated block
% Called by Integrate_<ProjectName>.m

if nargin < 4, error('Not enough input arguments.'); end
if nargin < 5, create_library = 0; end
if nargin < 6, add_path = 0; end

[pathstr, name_system, ext] = fileparts(nameext_system);
if isempty(ext)
	ext = '.mdl';
end

existing_system = 1;
try
	find_system(name_system); % Is system already loaded?
catch
	if exist([path_system filesep name_system ext], 'file') ~= 0 % Does model file already exist?
		curr_path = cd;						% Keep current path
		cd(path_system);					% Change to target directory
		load_system(name_system);			% Load system
		cd(curr_path);						% return to curr_path
	else
		existing_system = 0;
		if create_library ~= 0
			create_str = 'Library';
		else
			create_str = 'Model';
		end
		curr_path = cd;						% Keep current path
		cd(path_system);					% Change to target directory
		new_system(name_system, create_str)	% Create new system
		save_system(name_system)			% Save system in target directory
		cd(curr_path);						% return to curr_path
	end
end

if add_path ~= 0
	addpath(path_system, 1);
end

name_obj = [name_system '/' name_block];
blocks = find_system(name_system, 'Name', name_block);
if isempty(blocks)
	pos = zeros(1, 4);
else
	pos = get_param(name_obj, 'Position');
	delete_block(name_obj); % delete (and recreate) since input/output ports order might have changed
end

left = pos(1); top = pos(2); right = pos(3); bottom = pos(4);

try
	% create new block
	add_block('built-in/S-Function', name_obj);
catch
	disp('Block could not be added!')
	max_ports = 0;
	return
end

Mask_S_Function(name_obj, name_sfun, inputs, outputs, params, solver_settings);

max_ports = max([0, max(length(inputs), length(outputs)) - 1]);

iBlockHeight = max_ports*50 + 25;

% Position
if bottom ~= 0
	top = top + 15; % Avoid auto connection

	if bottom - top < iBlockHeight
		bottom = top + iBlockHeight;
	else
		bottom = bottom + 15;
	end
else
	if strcmp(get_param(name_system, 'BlockDiagramType'), 'library')
		iBlockCount = size(get_param(name_system, 'Blocks'), 1) - 1;
	else
		iBlockCount = 0;
	end

	iBlocksPerLine = 5; % Maximal number of blocks side by side
	iFramePerBlock = 10; % Margin per block
	iBlockWidth = 200;
	iRow = floor(iBlockCount/iBlocksPerLine);
	iCol = iBlockCount - iRow*iBlocksPerLine;
	left = iCol*iBlockWidth + (iCol + 1)*iFramePerBlock*2;
	top = iRow*iBlockHeight + (iRow + 1)*iFramePerBlock*2;
	right = left + iBlockWidth;
	bottom = top + iBlockHeight;
end

set_param(name_obj, 'Position', [left top right bottom]);

if isfield(solver_settings, 'Solver') & strcmp(solver_settings.Solver, 'CVODE')
	CustomInclude = 'sundials/include';
	CustomSource = 'sundials/src/cvode/cvode.c;sundials/src/cvode/cvode_dense.c;sundials/src/cvode/cvode_io.c;sundials/src/cvode/cvode_serialization.c;sundials/src/nvec_ser/nvector_serial.c;sundials/src/sundials/sundials_dense.c;sundials/src/sundials/sundials_math.c;sundials/src/sundials/sundials_nvector.c;sundials/src/sundials/sundials_serialization.c;sundials/src/sundials/sundials_smalldense.c';
	try
		% Simulink Coder
		set_param(name_system, 'CustomInclude', CustomInclude, 'CustomSource', CustomSource);
	end
	try
		% Rapid Accelerator
		set_param(name_system, 'SimUserIncludeDirs', CustomInclude, 'SimUserSources', CustomSource);
	end
end

save_system(name_system, [name_system ext])
