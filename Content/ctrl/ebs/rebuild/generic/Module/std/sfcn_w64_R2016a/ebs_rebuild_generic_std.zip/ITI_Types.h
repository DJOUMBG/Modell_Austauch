/**
 * ITI_Types.h
 * SimulationX 4.0.5.60286 (08/29/19) x64
 * Copyright (c) ESI ITI GmbH
 * All rights reserved.
**/

#if !defined(_ITI_Types)
#define _ITI_Types

#ifdef __cplusplus
extern "C" {
#endif

#include <limits.h>
#include <float.h>
#include <setjmp.h>
#include <stdlib.h>

#define SimData ITI_SimData
#define SimVar ITI_SimVar

#ifdef ITI_SIMULINK_S_FUNC
#include "simstruc.h"
#define ITI_void	void
#define ITI_real	real_T
#define ITI_int		int_T
#define ITI_uint	uint_T
#define ITI_char	char_T
#define ITI_ushort	unsigned short
#define ITI_uchar	unsigned char
#define ITI_long	long int
#define ITI_shared	real_T
#else
#define ITI_void	void
#define ITI_real	double
#define ITI_int		int
#define ITI_uint	unsigned int
#define ITI_ushort	unsigned short
#define ITI_uchar	unsigned char
#define ITI_char	char
#define ITI_long	long int
#define ITI_big_uint unsigned int
#define ITI_big_uint_max UINT_MAX
#define ITI_shared	double
#endif

#define ITI_TRACE_STRING_SIZE 10000
#define ITI_WARNING_STACK_SIZE 5

#define ITI_INTERFACE_VERSION 4.00

#ifndef MAX_PATH
#define MAX_PATH 260
#endif

#define DBL_EPSILON_SQR (DBL_EPSILON*DBL_EPSILON)
#define V_EPSILON (DBL_EPSILON*10.0)
#define NHYSTZERO 7  
#define MW_IDX 0
#define LO_IDX 2
#define HI_IDX 1
#define __MAX_PERT 0.001

typedef void TRACE_FUNC(int, int, const char*, const char*, const void*);

enum {
	SimulationTab = 0,
	FileTab = 1
};

enum {
	Info = 0,
	Warning = 1,
	Error = 4,
	Debug = 5
};

typedef ITI_real ITI_real2[2];

enum MemoryType {
	INT_TYPE,
	REAL_TYPE,
	STRING_TYPE,
	STRING_PTR_TYPE
};

 
enum ITI_SimX_TraceMsgType {
	SimX_info = 0,
	SimX_warning = 1,
	SimX_stop = 2,
	SimX_question = 3,
	SimX_error = 4,
	SimX_debug = 5,
	SimX_none = 6,
	SimX_msgtype_size = 7
};

typedef struct ITI_SimX_TraceMsg {
	enum ITI_SimX_TraceMsgType type;
	ITI_char shortMsg[100];
	ITI_char longMsg[ITI_TRACE_STRING_SIZE];
	ITI_ushort isNewMSg;
} ITI_SimX_TraceMsg;

typedef struct ITI_WarningStack {
	ITI_int size;
	ITI_int lastMsg;
	ITI_SimX_TraceMsg msg[ITI_WARNING_STACK_SIZE];
} ITI_WarningStack;

 
enum SaveOutputsBits {
	SaveOutputsNoneBit =                           0,
	SaveOutputsAllBit =                            2,
	SaveOutputsEqidistantBit =                     4,
	SaveOutputsAtleastwithdtProtBit =              8,
	SaveOutputsAtleastwithdtProtPostEventsBit =    16,
	SaveOutputsAtleastwithdtProtPrePostEventsBit = 32,
	SaveOutputsAtleastwithdtProtAllEventStepsBit = 64,
	SaveOutputsLastValueBit =                      128,
	SaveOutputsAfterDoStepBit =                    256
};

enum SimX_ProtKind {
	SimX_PK_EquidistantTimeSteps,
	SimX_PK_MinTimeStepsNoEvents,
	SimX_PK_MinTimeStepsPostEvents,
	SimX_PK_MinTimeStepsPrePostEvents,
	SimX_PK_MinTimeStepsAllEventSteps,
	SimX_PK_LastValue
};

enum SaveOutputsApproach {
	SaveOutputsAll = 0,
	SaveOutputsEqidistant = 1,
	SaveOutputsAtleastwithdtProt = 2,
	SaveOutputsAtleastwithdtProtPostEvents = 3,
	SaveOutputsAtleastwithdtProtPrePostEvents = 4,
	SaveOutputsAtleastwithdtProtAllEventSteps = 5,
	SaveOutputsLastValue = 6
};

enum SharedType {
	SharedType_Int = 0,
	SharedType_Real = 1,
	SharedType_Str = 2,
	SharedType_Synch = 3
};

enum DelayValueType {
	DelayValueType_Int = 0,
	DelayValueType_Real = 1
};

enum VarDataKind {
	VDK_Default = 0,
	VDK_OdeStateSimX = 1,
	VDK_OdeStateVirtual = 2,
	VDK_OdeStateDp = 3,
	VDK_DiscreteSimX = 4,
	VDK_DiscreteVirtual = 5,
	VDK_DiscreteAttr = 6,
	VDK_StartAttr = 7,
	VDK_FormerAttr = 8,
	VDK_IV = 9,
	VDK_IZ = 10,
	VDK_IP = 11
};

enum AssertionLevel {
	AL_Error = 0,
	AL_Warning = 1
};

enum BlockMemoryAllocStrategy {
	UseFreeSpaceInOtherBlocks = 0,
	DontUseSpaceInOtherBlocks = 99
};

enum ITI_Relation {
	Rel_LT = 0,
	Rel_LE = 1,
	Rel_GT = 2,
	Rel_GE = 3,
	Rel_EQ = 4,
	Rel_NE = 5
};

enum ClockPartitionType {
	CPT_BaseClock = 0,
	CPT_SubClock = 1
};

typedef struct ITI_CompositeData {
#ifdef ITI_COMP_SIM
	ITI_real** realData;
#else
	ITI_real* realData;
#endif
	ITI_int* intData;
	ITI_char** strData;
	size_t* strSize;
} ITI_CompositeData;

typedef void (*SetInputsFunc)(ITI_CompositeData* pu, ITI_real t);

typedef struct ITI_varData {
	ITI_char* name;
	ITI_int index;
	ITI_int arrayIndex;
	ITI_char* dim;
	enum SharedType type;
	enum VarDataKind kind;
	ITI_char* recArrayIndex;
} ITI_varData;

typedef struct ITI_xData {
	ITI_char* name;
	enum VarDataKind kind;
	ITI_int it;		 
	ITI_int ii;		 
	ITI_int nd;		 
	ITI_int nod;	 
	ITI_int id;		 
	ITI_char ift;	 
	ITI_char ia;	 
	ITI_char ida;	 
	ITI_char idn;	 
	ITI_int inds;	 
	ITI_int iids;	 
	ITI_char iif;	 

	ITI_char* dim;	 
	ITI_int arrayIndex;	 
	ITI_char* recArrayIndex;
} ITI_xData;

typedef struct ITI_resData {
	ITI_int i;				 
	ITI_char init;			 
	ITI_char ia;			 
	ITI_int ie;				 
	ITI_char fi;			 
	ITI_char iorig; 		 
} ITI_resData;


typedef struct ITI_zerofunctionData {
	ITI_char* name;
	ITI_int index;
	ITI_char* parentIdent;
	enum ITI_Relation rel;
	ITI_uint needHysterese;
	ITI_char* expression;
} ITI_zerofunctionData;

typedef struct ITI_SynchStrsDataItem {
	ITI_char*** modelStrs;
	ITI_void** simxStrs;
	ITI_void** simxStrVars;
	ITI_int* simxStrSizes;
	ITI_uint size;
	ITI_uint* indices;
} ITI_SynchStrsDataItem;

typedef struct ITI_SynchStrsData {
	ITI_SynchStrsDataItem pStrData;
	ITI_SynchStrsDataItem zStrData;
	ITI_SynchStrsDataItem pre_zStrData;
	ITI_SynchStrsDataItem vStrData;
} ITI_SynchStrsData;

typedef struct ITI_MemoryBlock {
	struct ITI_MemoryBlock* nextBlock;
	ITI_char* currBuffer;
	ITI_char* startBuffer;
	ITI_char* endBuffer;
	ITI_char* saveBuffer;
	enum MemoryType memType;
} ITI_MemoryBlock;

typedef void* (*ITI_AllocateMemory)(size_t nobj, size_t size);
typedef void  (*ITI_FreeMemory)(void* obj);

typedef struct ITI_MemoryObject {
	ITI_AllocateMemory allocateMemory;
	ITI_FreeMemory freeMemory;
	ITI_MemoryBlock* currentIntBlock;
	ITI_MemoryBlock* firstIntBlock;
	ITI_MemoryBlock* currentRealBlock;
	ITI_MemoryBlock* firstRealBlock;
	ITI_MemoryBlock* currentStringBlock;
	ITI_MemoryBlock* firstStringBlock;
	ITI_char* flatMemory;
	enum BlockMemoryAllocStrategy allocStrategy;
} ITI_MemoryObject;

typedef struct ITI_TraceData {
	ITI_uint len;
	ITI_char* line;
	ITI_char* line_ext;
	ITI_char* buffer;
	ITI_char* temp;
	ITI_char* temp2;
	ITI_char* start;
	ITI_MemoryObject memObj;
	ITI_MemoryObject memObj2;
	ITI_MemoryObject memObj3;
	ITI_int* pTraceOn;
} ITI_TraceData;

typedef void (*ITI_UpdateStrDataInSimxFunc)(ITI_SynchStrsData* sStrData);

typedef struct ITI_InputData {
	ITI_char* name;
	ITI_char* comment;
	ITI_real defaultValue;
	ITI_ushort bInterpol;
	ITI_ushort bDirectThrough;
	ITI_char* signalName;
	ITI_int paramType;
	enum SharedType type;
	ITI_int typeIndex;
} ITI_inputData;

typedef struct ITI_OutputData {
	ITI_char* name;
	ITI_char* comment;
	ITI_char* unit;
	ITI_char* signalName;
	enum SharedType type;
	ITI_int typeIndex;
} ITI_outputData;

typedef struct ITI_ParameterData {
	ITI_char* name;
	ITI_char* comment;
	ITI_shared defaultValue;
	ITI_char* unit;
	ITI_char* signalName;
	ITI_int paramType;
	enum SharedType valType;
} ITI_parameterData;

typedef struct ITI_ArrayData {
	ITI_uint nDims;
	ITI_uint nValues;
	enum MemoryType memType;
} ITI_ArrayData;

typedef struct ITI_Data_Array {
	ITI_char* name;
	ITI_char* comment;
	ITI_char* altName;
	ITI_char* unit;
	ITI_char* dims;
	ITI_uint nDims;
	enum SharedType valType;
} ITI_Data_Array;

enum Interpol {
	InterpolNone,
	InterpolLinear,
	InterpolSpline,
	InterpolStairs,
	InterpolHyperbolicApprox,
	InterpolCircualArcApprox,
	InterpolQuadraticApprox
};

enum Extrapol {
	ExtrapolNull,
	ExtrapolLinear,
	ExtrapolConstant,	 
	ExtrapolMirror,
	ExtrapolMirrorLinear,
	ExtrapolCycle
};

enum HystMode {
	HystModeDiscontHorizontal,
	HystModeDiscontVertical,
	HystModeContinous
};

enum HystStartValue {
	HystStartValueUpper,
	HystStartValueLower,
	HystStartValueMeanValue,
	HystStartValueStartValue
};

typedef struct ITI_SeqInfoY {
	enum Interpol iPol;
	ITI_real param;
	ITI_uint bExtrapol : 1;
	ITI_uint bCycle : 1;
	ITI_uint bMirror : 1;
} ITI_SeqInfoY;

typedef struct ITI_AxisInfo {
	enum Interpol iPol;
	ITI_uint bExtrapol : 1;
	ITI_uint bCycle : 1;
	ITI_uint bMirror : 1;
} ITI_AxisInfo;

typedef struct ITI_YScale {
	ITI_real scale;
	ITI_uint bScaleInitialized;
} ITI_YScale;

typedef struct ITI_CurveSetData {
	ITI_uint size;
	ITI_uint nY;
	ITI_SeqInfoY* yInfo;
	ITI_real* pX;
	ITI_real** pY;
	ITI_real*** pYCoeff;
	ITI_char* name;
	ITI_uint nYScale;
	ITI_YScale* pYScale;
	ITI_int curveParamIndex;
} ITI_CurveSetData;

typedef struct ITI_CurveData_ND {
	ITI_uint sizeX;
	ITI_uint sizeY;
	ITI_uint sizeZ;
	ITI_AxisInfo* axisInfo;
	ITI_real* pX;
	ITI_real* pY;
	ITI_real* pZ;
	ITI_real* pVal;
	ITI_real*** pYCoeff;
	ITI_char* name;
	ITI_uint nYScale;
	ITI_YScale* pYScale;
} ITI_CurveData_ND;

typedef struct ITI_SeqCallState {
	ITI_int iPos;
	ITI_int nCycle;
	ITI_uint bExtra;
	ITI_uint bMirror;
} ITI_SeqCallState;

typedef struct ITI_CurveCallState {
	ITI_SeqCallState* pSeqCs;
} ITI_CurveCallState;

typedef struct ITI_HystCurveCallState {
	ITI_SeqCallState* pSeqCs;
	ITI_real lastY;
	 
	ITI_real lastYCi;
	 
	ITI_int direction;
	ITI_real yTurnBack;
	ITI_real xTurnBack;
	ITI_real lambdaTurnBack;
	ITI_ushort bInitialized;
} ITI_HystCurveCallState;

typedef struct ITI_AnimationData {
	ITI_real* realDelayData;
	ITI_int* intDelayData;
} ITI_AnimationData;

typedef struct ITI_AssertData {
	ITI_uchar* assertState1;
	ITI_uchar* assertState2;
	ITI_uchar* assertStateR;
	ITI_uchar* assertStateW;
	ITI_char** warnMsg;
	ITI_char** condMsg;
	ITI_ushort bAssertStateChanged;
	ITI_ushort bAssertError;
	size_t n;
} ITI_AssertData;

typedef struct {
	ITI_char trDiscrete;
	ITI_char trTimeStat;
	ITI_char trDummyPivoting;
	ITI_char trZeroFct;
	ITI_char trZeroFctTime;
	ITI_char trZeroFctTime2;
	ITI_char trFindDiscont;
	ITI_char trStartEventStep;
	ITI_char trEndEventStep;
	ITI_char trEndEventIter;
	ITI_char trTimerSet;
	ITI_char trTimerExpired;
	 
	ITI_char trResult;
	ITI_char trIdo;
	ITI_char trRes;
	ITI_char trStates;
	ITI_char trDer;
	ITI_char trNewtonUpdate;
	ITI_char trJac;
	ITI_char trIndex;
	ITI_char trStateBounds;
	ITI_char trErrorsLinSystem;
		 
	ITI_char trStepTrue;
	ITI_char trResTrue;
	ITI_char trStatesTrue;
	ITI_char trDerTrue;
		 
	ITI_char trStepFalse;
	ITI_char trResFalse;
	ITI_char trStatesFalse;
	ITI_char trDerFalse;
	ITI_char trNewtonUpdateFalse;
	ITI_char trBlockStatistics;
		 
	ITI_char trHomotopyStepSize;
	ITI_char trHomotopyTangentSpace;
} ITI_TraceFlags;

typedef struct ITI_SolverSettings {
	ITI_real fromFile;
	ITI_real tStart;
	ITI_real tStop;
	ITI_real dtMin;
	ITI_real dtMax;
	ITI_real dtDetect;
	ITI_real absTol;
	ITI_real relTol;
	ITI_real dtProtMin;
	ITI_int mode;
	ITI_int stopAttStop;
	ITI_int influence;
	ITI_int zeros;
	ITI_int eventHandlingMode;
	ITI_int saveMode;
	enum SaveOutputsBits saveModeB;
	ITI_real trace;
	ITI_int limitdtMin;
	ITI_int effJac;
	ITI_int parJac;
	ITI_int maxOrder;
	ITI_real gltol;
	ITI_int linSolv;
	ITI_int threadLimit;
	ITI_int ignoreMinMax;
	ITI_int minmax;
	ITI_int hysteresis;
	ITI_int scaleEpsilon;
	ITI_int adaptEpsilon;
	ITI_real epsilon;
	ITI_real maxEpsilon;
	ITI_int adaptThreshold;
	ITI_int adaptFactor;
	ITI_int useInitFile;
	ITI_int consistentInitialConditions;
	ITI_ushort bAssertOn;
	ITI_ushort bAssertTraceOn;
	ITI_ushort bStopOnError;
	ITI_ushort SDIRK;
	ITI_ushort maxNonlinIters;
}ITI_SolverSettings;

typedef void(*ITI_SetZeroFunctionBDFfunc)(void* pVoid, size_t index, double v1, double v2);
typedef double(*ITI_GetDelayValueBDFfunc)(void* pVoid, size_t index, double v, double tDelay, double t);
typedef double(*ITI_GetImpactBDF)(void* pVoid, size_t index);
typedef void(*DoClockTickFunc)(void* pVoid, size_t clockid);
typedef void(*DoClockedInitFunc)(void* pVoid, size_t clockid);
typedef void(*NextClockTickFunc)(void* pVoid, size_t clockid, const double nextActivationTime);

typedef struct ITI_SolverInfo {
	ITI_ushort bSolverNeedsReset;
	ITI_ushort bEventTriggered;
	ITI_ushort bDPAllowed;
	ITI_ushort bDPRequired;
	ITI_ushort bDPHappened;
	ITI_ushort bSetImpactCalled;
	ITI_uchar bInitializeConditions;
	ITI_uint isFirstRhsCall;
	ITI_uint isInitial;
	ITI_uint isEvent;
	ITI_uint isFirstEventStep;
	ITI_uint isTerminal;
	ITI_uint isCalcDependencies;
	ITI_uint iTerminalCalled;
	ITI_uint iTerminate;
	ITI_int iFailedEqu;
	ITI_char* strAnalysesType;
	ITI_char* strAnalysisTypeDetail;
	ITI_char strTrace[ITI_WARNING_STACK_SIZE*ITI_TRACE_STRING_SIZE];
	ITI_WarningStack warningStack;
	ITI_uint tracingAllowed;
	ITI_ushort bInitializeFuncCalled;
	ITI_real dt;
	ITI_real lambdaHomotopy;
	ITI_AnimationData aniData;
	ITI_uint isAnimation;
	int allowJump;
	jmp_buf buf;
	TRACE_FUNC* trace;
	ITI_uint isEmbed;
	int allowBlockJump;
	jmp_buf blockEnv;
	ITI_ushort bAssertOn;
	ITI_ushort bAssertTraceOn;
	ITI_ushort bAssertActive;
	void* pContainer;
	ITI_AssertData assertData;
	ITI_ushort MEcalled;
	ITI_SolverSettings* sSettings;
	ITI_uchar applyHysteresis;
	ITI_ushort bUseSimpleHomotopy;
	ITI_char strResourceFolder[1024];
	ITI_SetZeroFunctionBDFfunc SetZeroFunctionBDF;
	ITI_GetDelayValueBDFfunc GetDelayValueBDF;
	ITI_GetImpactBDF GetImpactBDF;
	DoClockTickFunc DoClockTick;
	DoClockedInitFunc DoClockedInit;
	NextClockTickFunc NextClockTick;
} ITI_SolverInfo;

typedef struct ITI_ModelInfo {
	ITI_ushort bNeedExtendedOnValidStep;
	ITI_ushort bHasDummyVariables;
} ITI_ModelInfo;

typedef struct ITI_SolverStatistic {
	ITI_uint iOrder;
	ITI_uint iValidSteps;
	ITI_uint iZero;
	ITI_uint iZeros;
	ITI_uint iJac;
	ITI_uint iCodegen;
	ITI_uint iDecomp;
	ITI_uint iElim;
	ITI_real dblChangeStepSize;
	ITI_real dblhTmp;
	ITI_real* dblInfluence;
	ITI_uint* discreteCount;
	ITI_uint* zeroCrossingCount;
	ITI_uint iErrTestFailStep;
	ITI_uint iErrTestFails;
	ITI_uint iRhsCalls;
	ITI_uint ix;
	ITI_real elapsedTime;
	ITI_uint ngrp;
	ITI_uint iRoots;
	ITI_uint iTimeEvents;
	ITI_uint iTimeEventsReinit;
	ITI_uint iStateSelections;
	ITI_uint iOtherEvents;
	ITI_uint iRfcalls;
	ITI_uint numBlocks;
	ITI_long *numBlockRes;
	ITI_long *numBlockJac;
	ITI_real *blockTimes;
	ITI_real calcDerivativesTime;
} ITI_SolverStatistic;

typedef struct ITI_SampleTime {
	ITI_real to;
	ITI_real ts;
} ITI_SampleTime;

typedef struct ITI_HystCurveInitData {
	ITI_char* curveIdent;
	ITI_ushort bEnabled;
	enum HystMode hystMode;
	ITI_ushort bClockwise;
	ITI_real startY;
	enum HystStartValue hystStartValue;
	ITI_real eps_xdot;
} ITI_HystCurveInitData;

typedef struct ITI_EqBlock {
	ITI_int stateStartIdx;
	ITI_int stateSize;
	ITI_int eqStartIdx;
	ITI_int eqSize;
	ITI_int derEqSize;
} ITI_EqBlock;

typedef struct ITI_DerEquation {
	ITI_int idx_State;
	ITI_int idx_BaseState;
} ITI_DerEquation;

typedef struct ITI_VarNext {
	ITI_int state_i;
	ITI_int state_i_orig;
	ITI_char iState_dc;
	ITI_char iState_dd;
	ITI_char iState_fcsp;
	ITI_char iState_ibs;
	ITI_char ider;
	ITI_int der_si;
	ITI_char ider_dc;
	ITI_char ider_dd;
} ITI_VarNext;

typedef struct ITI_VarAttributes {
	ITI_int stateIdx;
	ITI_int startIdx;
	ITI_int minIdx;
	ITI_int maxIdx;
	ITI_int fixedIdx;
	ITI_int notFixedIdx;
	ITI_int nominalIdx;
	ITI_int minNotReachedIdx;
	ITI_int maxNotReachedIdx;
	ITI_int absTolIdx;
	ITI_int relTolIdx;
	ITI_int discontChangeIdx;
} ITI_VarAttributes;

typedef struct ITI_BlockSizes {
	ITI_int ires;
	ITI_int iDAE;
	ITI_int iHybrid_Z_Real;
	ITI_int iHybrid_Z_Int;
	ITI_int iHybrid_Z_Str;
	ITI_int iHybrid_Zf;
	ITI_int nrDPBlock;
	ITI_int isNonlinear;
} ITI_BlockSizes;

typedef struct ITI_DelayInfo {
	ITI_uint bufSize;
	enum DelayValueType valType;
	ITI_char* name;
} ITI_DelayInfo;

typedef struct ITI_DelayBuffer {
	ITI_int size;
	ITI_int lastPosIn;
	ITI_int lastPosOut;
	ITI_real* times;
	ITI_real* realValues;
	ITI_int* intValues;
	ITI_int iL;
	ITI_int iR;
	ITI_int iSearch;
	ITI_int iNewVal;
	enum DelayValueType valType;
#ifdef ITI_ANIMATION
	ITI_int aniIndex;
#endif
} ITI_DelayBuffer;

typedef struct ITI_Array {
	ITI_int nDims;
	ITI_int* dims;
	ITI_char** charValues;
	ITI_int* intValues;
	ITI_real* realValues;
	enum MemoryType memType;
} ITI_Array;

typedef struct ITI_WorkMemory {
	ITI_real* ker;
	ITI_real* kerCopy;
	ITI_real* vecCopy;
	ITI_real* dWork;
	ITI_int*  lPermVecCol;
} ITI_WorkMemory;

typedef struct {
	ITI_real *a;
	ITI_real *b;
	ITI_real *work;
	ITI_real *wp1;
	ITI_real *wp2;
	ITI_int  *jpvt;
	ITI_real bignum;
	ITI_real smlnum;
	ITI_real anrm;
	ITI_int  m;
	ITI_int  n;
	ITI_int  ldb;
	ITI_int  lwork;
	ITI_int  rank;
	ITI_int  mn;
	ITI_real rcond;
	ITI_int  iascl;
} ITI_LLSData;


struct ITI_BlockData;
typedef struct ITI_BlockDataVTable {
	void(*ErrorExceedsBorder) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i);
	void(*ErrorInitialBracketNotFound) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo);
	void(*ErrorLambdaMin)(struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint n);
	void(*ErrorMaxIter)(struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint n);
	void(*ErrorResidualImage) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint n);
	void(*WarningBelowMin) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i, ITI_uint j);
	void(*WarningBelowMinDamping) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i);
	void(*WarningBelowMinDamping2) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i, ITI_uint k);
	void(*WarningExceedsMax) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i, ITI_uint j);
	void(*WarningExceedsMaxDamping) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i);
	void(*WarningExceedsMaxDamping2) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i, ITI_uint k);
	void(*WarningReducingDampFac) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint i);
	void(*WarningResidualImage) (struct ITI_BlockData* pBd, ITI_SolverInfo* pInfo, ITI_uint m, ITI_uint n, ITI_uint l);
	void(*SetAnalysisTypeDetail) (struct ITI_SolverInfo* pInfo, char* typeDetail);
} ITI_BlockDataVTable;

typedef struct ITI_BlockData {
	ITI_BlockDataVTable* vTable;
	ITI_uint nRes;
	ITI_uint nDAE;
	ITI_real* x;
	ITI_real* minVal;
	ITI_real* maxVal;
	ITI_real* nomVal;
	ITI_uint ignoreLimits;
	ITI_ushort* considerMin;
	ITI_ushort* considerMax;
	ITI_ushort considerLimit;
	ITI_uint nViolLimit;
	ITI_uint* iViolLimit;
	ITI_real alpha;
	ITI_real beta;
	ITI_char** name;
	ITI_real* sjac;
	ITI_real* v;
	ITI_real* mv;
	ITI_real* jac;
	ITI_real* res;
	ITI_real* tmpres;
	ITI_real* s;
	ITI_int*  ipiv;
	ITI_int*  colpiv;
	ITI_real* tol;
	ITI_real* delta;
	ITI_real* xorg;
	ITI_WorkMemory *workMem;
	ITI_ushort mode;
	ITI_real* xstart;
	ITI_ushort saveStartValues;
	ITI_ushort error;
	ITI_int *numJacCols;
	ITI_int nCol;
	ITI_int iCol;
	ITI_uint repeat;
	ITI_real d;
	ITI_real preNorm;
	ITI_real firstNorm;
	ITI_int corrStep;
	ITI_ushort firstTime;
	ITI_ushort justOnceMore;
	ITI_real* sjactemp;
	ITI_uint* permVecCol;
	ITI_char* strAnalysisTypeDetail;
	ITI_real* xsave;
	ITI_int* zintsave;
	ITI_real* zrealsave;
	ITI_char** zstrsave;
	ITI_real* zfsave;
	ITI_real normdx;
	ITI_real* dxbar;
	ITI_real* w;
	ITI_real lambda;
	ITI_real normdxbar;
	ITI_real normdxkm1;
	ITI_real* xjac;
	ITI_uint reduced;
	ITI_int maxiter;
	ITI_real gltol;
	ITI_int linSolv;
	ITI_real lambda_min;
	ITI_uint iMax;
	ITI_real rect_error;
	ITI_real* colsc;
	ITI_real* rowsc;
	ITI_real xh;
	ITI_real xl;
	ITI_real resSav;
	ITI_real dxSav;
	ITI_real sSav;
	ITI_uint hybrid;
	ITI_LLSData llsData;
	ITI_int zfSwitch;
	ITI_uint undamped;
	ITI_uint isNonlinear;
	ITI_int autoLinSolv;
	ITI_uint useNumJac;
	ITI_long resCalls;
	ITI_long jacCalls;
} ITI_BlockData;

typedef struct ITI_DPBlockData {
	ITI_uint* M;
	ITI_real* Vdot;
	ITI_ushort MC;
	ITI_ushort MCP;
} ITI_DPBlockData;

typedef struct ITI_HomMinMax {
	ITI_ushort considerLimit;
	ITI_ushort* considerMin;
	ITI_real* minVal;
	ITI_ushort* considerMax;
	ITI_real* maxVal;
	ITI_real* nomVal;
	ITI_char** name;
}ITI_HomMinMax;

typedef struct ITI_StateMinMax {
	ITI_int nMin;
	ITI_int nMax;
	ITI_int* minInd;
	ITI_int* maxInd;
	ITI_real* minVal;
	ITI_real* maxVal;
}ITI_StateMinMax;

typedef struct ITI_ModelSize {
	ITI_int ix;
	ITI_int ibx;
	ITI_int ix_i;
	ITI_int ires_i;
	ITI_int ihomres;
	ITI_int iy_int;
	ITI_int iy_real;
	ITI_int iy_str;
	ITI_int ip_int;
	ITI_int ip_real;
	ITI_int ip_str;
	ITI_int ip_arr;
	ITI_int iu_int;
	ITI_int iu_real;
	ITI_int iu_str;
	ITI_int iz_int;
	ITI_int iz_real;
	ITI_int iz_str;
	ITI_int iv_int;
	ITI_int iv_real;
	ITI_int iv_str;
	ITI_int i_inc;
	ITI_int izf;
	ITI_int ics;
	ITI_int isv;
	ITI_int ihcs;
	ITI_int idb;
	ITI_int iExtObj;
	ITI_int iarr;
	ITI_int iRec;
	ITI_int iStrs;
	ITI_int icset;
	ITI_int ipcset;
	ITI_int icnd;
	ITI_int iass;
	ITI_int ieb;
	ITI_int ide;
	ITI_int ivn;

	ITI_int numBlocks;
	ITI_int numStateAttr;
	ITI_int numInitStateAttr;
	ITI_int numRESBlock;
	ITI_int numXBlock;

	ITI_int iSimX_X;
	ITI_int iSimX_V;
	ITI_int iSimX_Z;
	ITI_int iSimX_BX;

	ITI_int iDPB;
	ITI_int iInEq_n;
	ITI_int iInEq_n_Min_m;
	ITI_int iInEq_n_Mul_n_Min_m;
	ITI_int iInEq_35_Mul_n_Min_m_Plus_32;

	ITI_int bxind_lambda;
	ITI_int bxind_cdfirst;
	ITI_int bxind_homlast;

	ITI_int ipart;
	ITI_int iig;
	ITI_int* iig_nodes;
	ITI_int* iig_edges;
	ITI_int* iig_children;
	ITI_int* iig_roots;
	ITI_int* iig_baseclocks;
	ITI_int* iig_solverclocks;
	ITI_int* iig_solverneeded;
	ITI_int* iig_paths;
	ITI_int* iig_steps;
} ITI_ModelSize;

typedef struct ITI_PartitionData {
	enum ClockPartitionType type;
	ITI_int id;
	ITI_int baseid;
	ITI_int subid;
	ITI_int sampleActive;
	ITI_int holdChanged;
	ITI_int activated;
	ITI_char periodic;
	ITI_char continous;
	ITI_int solvermethod;
	ITI_char eventClock;
} ITI_PartitionData;

typedef struct ITI_WorkSpace {
	ITI_real* xdot_tmp;
	 
	ITI_CompositeData vtmp;
	ITI_CompositeData v;
	ITI_CompositeData p;
	ITI_CompositeData z;
	ITI_real* x;
	ITI_real* bx;
	ITI_real* bx_tmp;
	ITI_real** px;
	ITI_CompositeData pre_z;
#ifdef ITI_COMP_SIM
	ITI_real* vtmp_mem_real;
	ITI_real* v_mem_real;
	ITI_real* p_mem_real;
	ITI_real* z_mem_real;
	ITI_real* pre_z_mem_real;
#endif
}ITI_WorkSpace;

struct inferenceGraph;

typedef struct ITI_SimData {
	ITI_MemoryObject currMem;
	ITI_MemoryObject funcMem;
	ITI_MemoryObject strMem;
	ITI_void** extObj;
	ITI_HomMinMax* hmm;
	ITI_real* hom_res;
	ITI_real* hom_jac;
	int maxThreads;
	void *parDat;
	ITI_uint* strLengths;
	ITI_uint* pre_strLengths;
	ITI_TraceData traceData;
	ITI_TraceFlags traceFlags;
	void *performanceData;
#ifdef ITI_COMP_SIM
	void(*oldHandler)(int);
	int oldCW;
#endif
	char **stateNames;
	char **dstateNames;
	int trwidth;
	int dtrwidth;
} ITI_SimData;

typedef struct ITI_SimOld {
	ITI_real* x;
	ITI_real* xdot;
	ITI_real* xdot_tmp;
	ITI_real* bxd;
	ITI_real** res;
	ITI_real** res_i;
	ITI_real* x_i;
#ifdef ITI_COMP_SIM
	ITI_real** bx;
	ITI_real** bx_tmp;
	ITI_real* y_mem_real;
	ITI_real* u_mem_real;
#else
	ITI_real* bx;
	ITI_real* bx_tmp;
#endif
	ITI_CompositeData v;
	ITI_CompositeData vtmp;
	ITI_CompositeData y;
	ITI_CompositeData u;
	ITI_CompositeData p;
	ITI_CompositeData z;
	ITI_CompositeData pre_z;
	ITI_Array* arr_p;
	ITI_Array* arrays;
	ITI_real* zf;
	ITI_real* pre_zf;
	ITI_uchar* czf;
	ITI_uchar* ezf;
	ITI_int* cszf;
	ITI_int* oszf;
	ITI_int* szf;
	ITI_int* relzf;
	ITI_real* epszf;
	ITI_real* e1zf;
	ITI_real* e2zf;
	ITI_uint* sczf;
	ITI_real** pszf;
	ITI_CurveSetData* cSet;
	ITI_CurveData_ND* cNd;
	ITI_CurveCallState* cs;
	ITI_HystCurveCallState* hcs;
	ITI_real t;
	ITI_real tLastStep;
	ITI_SolverInfo sInfo;
	ITI_uint* iReinit;
	ITI_real* xReinit;
	ITI_ushort* xImpact;
	ITI_int* sv;
	ITI_DelayBuffer* db;
	ITI_void* pRecord;
	ITI_BlockData* ibd;
	ITI_DPBlockData* iDPbd;
	ITI_uint incCount;
	ITI_uint* stateIncidence;
	ITI_ModelSize size;
	ITI_SampleTime* sampleTime;
	ITI_StateMinMax* smm;
	struct inferenceGraph *partitionIG;
} ITI_SimOld;

typedef struct ITI_SimVar {
	ITI_real* x;
	ITI_real* xdot;
	ITI_real* xdot_tmp;
	ITI_real* bxd;
	ITI_real** res;
	ITI_real** res_i;
	ITI_real* x_i;
#ifdef ITI_COMP_SIM
	ITI_real** bx;
	ITI_real** bx_tmp;
	ITI_real* y_mem_real;
	ITI_real* u_mem_real;
#else
	ITI_real* bx;
	ITI_real* bx_tmp;
#endif
	ITI_CompositeData v;
	ITI_CompositeData vtmp;
	ITI_CompositeData y;
	ITI_CompositeData u;
	ITI_CompositeData p;
	ITI_CompositeData z;
	ITI_CompositeData pre_z;
	ITI_Array* arr_p;
	ITI_Array* arrays;
	ITI_real* zf;
	ITI_real* pre_zf;
	ITI_uchar* czf;
	ITI_uchar* ezf;
	ITI_int* cszf;
	ITI_int* oszf;
	ITI_int* szf;
	ITI_int* relzf;
	ITI_real* epszf;
	ITI_real* e1zf;
	ITI_real* e2zf;
	ITI_uint* sczf;
#ifdef ITI_COMP_SIM
	ITI_uchar *curve_zf;
#endif
	ITI_real** pszf;
	ITI_void** extObj;
	ITI_CurveSetData* cSet;
	ITI_CurveData_ND* cNd;
	ITI_CurveCallState* cs;
	ITI_HystCurveCallState* hcs;
	ITI_real t;
	ITI_real tLastStep;
	ITI_SolverInfo sInfo;
	ITI_uint* iReinit;
	ITI_real* xReinit;
	ITI_ushort* xImpact;
	ITI_int* sv;
	ITI_DelayBuffer* db;
	ITI_BlockData* ibd;
	ITI_DPBlockData* iDPbd;
	ITI_uint incCount;
	ITI_uint* stateIncidence;
	ITI_MemoryObject currMem;
	ITI_MemoryObject funcMem;
	ITI_ModelSize size;
	ITI_SampleTime* sampleTime;
	ITI_MemoryObject strMem;
	ITI_void* pRecord;
	ITI_HomMinMax* hmm;
	ITI_real* hom_res;
	ITI_real* hom_jac;
	ITI_StateMinMax* smm;
	ITI_ModelInfo modelInfo;
	int maxThreads;
	void *parDat;
	ITI_uint* strLengths;
	ITI_uint* pre_strLengths;
	ITI_HystCurveInitData* _hyst_init_data;
	struct inferenceGraph *partitionIG;
	ITI_PartitionData *partitionData;
} ITI_SimVar;

typedef ITI_int(*ModelFunc2)(SimVar* _pData, SimData* _data);
typedef ITI_int(*ModelFunc4)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*ModelFunc5)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data, ITI_real* __jac);
typedef ITI_int(*CalcDerivativesFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*CalcResidualsFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*CalcOutputsFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*SynchOutputsFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*ValidStepFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*DoAcceptStatesFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef void(*AssignLastVarFunc)(SimVar* _pData, SimData* _data);
typedef void(*AssignDiscreteRealFunc)(SimVar* _pData, SimData* _data);
typedef void(*SampleFunctionFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*InitializeFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*InitializeConstantsFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*InitializeParameterDependentFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*InitializeTunableParameterFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*InitializeConditionsFunc)(SimVar* _pData, SimData* _data);
typedef ITI_int(*TerminateFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*CalcResidualsInitFunc)(SimVar* _pData, SimData* _data);
typedef void(*GetJacobianAPatternFunc)(SimVar* _pData, SimData* _data, ITI_char*);
typedef void(*GetJacobianEPatternFunc)(SimVar* _pData, SimData* _data, ITI_char*);
typedef void(*GetJacobianInitPatternFunc)(SimVar* _pData, SimData* _data, ITI_char*);
typedef ITI_int(*CalcJacPrefixInitFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*CalcJacInitFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data, ITI_real* __jac);
typedef ITI_int(*CalcJacPrefixFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*CalcJacAFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data, ITI_real* __jac);
typedef ITI_int(*CalcJacEFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data, ITI_real* __jac);
typedef ITI_int(*PreActivationFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef ITI_int(*PostActivationFunc)(SimVar* _pData, SimVar* _bcVarData, SimVar* _scVarData, SimData* _data);
typedef void(*InitBlockVarsFunc)(ITI_BlockData *bd);
typedef void(*GetModelSizesFunc)(ITI_AllocateMemory allocateMemory, ITI_ModelSize* pSize);
typedef void(*GetStateNamesFunc)();
typedef void(*GetModelInfoFunc)(ITI_ModelInfo* pInfo);

typedef struct ITI_PartitionFunctionAccess {
	CalcDerivativesFunc CalcDerivatives;
	CalcResidualsFunc CalcResiduals;
	CalcOutputsFunc CalcOutputs;
	SynchOutputsFunc SynchOutputs;
	ValidStepFunc ValidStep;
	DoAcceptStatesFunc DoAcceptStates;
	AssignLastVarFunc AssignLastVar;
	AssignDiscreteRealFunc AssignDiscreteReal;
	SampleFunctionFunc SampleFunction;
	InitializeFunc Initialize;
	InitializeConstantsFunc InitializeConstants;
	InitializeParameterDependentFunc InitializeParameterDependent;
	InitializeTunableParameterFunc InitializeTunableParameter;
	InitializeConditionsFunc InitializeConditions;
	CalcResidualsInitFunc CalcResidualsInit;
	TerminateFunc Terminate;
	GetJacobianAPatternFunc GetJacobianAPattern;
	GetJacobianEPatternFunc GetJacobianEPattern;
	GetJacobianInitPatternFunc GetJacobianInitPattern;
	CalcJacPrefixInitFunc CalcJacPrefixInit;
	CalcJacInitFunc CalcJacInit;
	CalcJacPrefixFunc CalcJacPrefix;
	CalcJacAFunc CalcJacA;
	CalcJacEFunc CalcJacE;
	PreActivationFunc PreActivation;
	PostActivationFunc PostActivation;
	InitBlockVarsFunc InitBlockVars;
	GetModelSizesFunc GetPartitionSizes;
	GetStateNamesFunc GetStateNames;
	GetModelInfoFunc GetModelInfo;
	ITI_ArrayData* arrayData;
	ITI_varData* dataV;
	ITI_varData* dataZ;
	ITI_xData* dataX;
	ITI_varData* dataBX;
	ITI_resData* dataRES;
	ITI_zerofunctionData* dataZF;
	ITI_CurveSetData* curveSets;
	ITI_CurveData_ND* curveNDs;
	ITI_BlockSizes *blockSizes;
	ITI_VarAttributes* stateAttributes;
	ITI_VarAttributes* initialStateAttributes;
	ITI_uint* seqCsSizes;
	ITI_DelayInfo* delayInfos;
	ITI_HystCurveInitData* _hyst_init_data;
	ITI_int *numJacColsData;
	ITI_uint* DPBlockSizes;
	ITI_EqBlock* eqblocks;
	ITI_DerEquation* der_equations;
	ITI_VarNext* varnext;
}ITI_PartitionFunctionAccess;

 
typedef int (*GetSizeOfStateAttrFunc)();
typedef int(*GetSizeOfInitialStateAttrFunc)();
typedef size_t(*GetSizeOfRESBlockFunc)();
typedef size_t(*GetSizeOfXBlockFunc)();
typedef void (*InitInferenceGraphFunc)(SimVar* _pData, SimData* _data);
typedef void(*GetPartitionDataFunc)(SimVar* _pData, SimData* _data);
typedef void(*GetPartitionAccessFunc)(ITI_PartitionFunctionAccess* _partitions);
typedef unsigned long (*GetCheckSumFunc)();
typedef void (*InitMemoryFunc)(ITI_MemoryObject* _currMem, ITI_AllocateMemory allocateMemory, ITI_FreeMemory freeMemory);
typedef void (*FreeAllMemoryFunc)(ITI_MemoryObject* _currMem);
typedef void (*ReleaseAllMemoryFunc)(ITI_MemoryObject* _currMem);
typedef ITI_real (*GetInterfaceVersionFunc)();
typedef int (*ConstConditionsChangedFunc)(SimVar* _pData, SimData* _data);
typedef void (*SynchronizeParametersFunc)(SimVar* _pData, SimData* _data);
typedef ITI_char* (*GetStringMemoryFunc)(ITI_MemoryObject* currMem, ITI_int nChar);
typedef void (*AllocateRecordsFunc)(SimVar* _pData);
typedef void (*FreeRecordsFunc)(SimVar* _pData, SimData* _data);

typedef struct ITI_Model {
	ITI_PartitionFunctionAccess* fpartitions;
	 
	 
	 
	 
	 
	 
	GetModelSizesFunc GetModelSizes;
	InitInferenceGraphFunc InitInferenceGraph;
	GetPartitionDataFunc GetPartitionData;
	GetPartitionAccessFunc GetPartitionAccess;

	 
	 
	 
	 
	 
	 
	 
	 

	InitMemoryFunc InitMemory;
	FreeAllMemoryFunc FreeAllMemory;
	ReleaseAllMemoryFunc ReleaseAllMemory;
	GetStringMemoryFunc GetStringMemory;
	AllocateRecordsFunc AllocateRecords;
	FreeRecordsFunc FreeRecords;
#ifdef ITI_COMP_SIM
	GetCheckSumFunc GetCheckSum;
	GetInterfaceVersionFunc GetInterfaceVersion;
	ConstConditionsChangedFunc ConstConditionsChanged;
	SynchronizeParametersFunc SynchronizeParameters;
	void* hModel;
#endif
	ITI_parameterData* parameters;
	ITI_outputData* outputData;
	ITI_inputData* inputData;
	 
	ITI_varData* dataV;
	ITI_varData* dataZ;
	ITI_xData* dataX;
	ITI_varData* dataBX;
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}ITI_Model;

typedef struct ITI_CSTmpData {
	ITI_int allocated;
	ITI_SolverInfo sInfo;
	ITI_real* bx;
	ITI_CompositeData z;
	ITI_CompositeData pre_z;
	ITI_real* z_mem_real;
	ITI_real* pre_z_mem_real;
	ITI_real* zf;
	ITI_real* pre_zf;
	ITI_int* cszf;
	ITI_int* oszf;
	ITI_uint* stateIncidence;
}ITI_CSTmpData;

#ifdef __cplusplus
}   
#endif

#endif
