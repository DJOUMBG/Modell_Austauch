#include "ITI_crt.h"
#include "ITI_SFuncHelper.h"

#ifdef MATLAB_MEX_FILE
#include "matrix.h"
#ifndef MWSIZE_MAX
#define mwSize ITI_int
#endif
#define ITI_mwSize mwSize
#else
#include "rt_matrx.h"
/* There is a undetectable API break of mxGetDimensions in rt_matrx.h introduced by Simulink Coder 8.12 of MATLAB R2017a:
   * mxGetDimensions of MATLAB R2017a returns a pointer of type mwSize,
     whereas in older MATLAB releases it is an int_T pointer
   * Define ITI_NEW_API_MXGETDIMENSIONS in the make options if ITI_SFuncHelper.c is built by MATLAB >= R2017a
 */
#ifndef ITI_NEW_API_MXGETDIMENSIONS
#define ITI_mwSize ITI_int
#else
#define ITI_mwSize mwSize
#endif
#endif

static void ReportArrayError(SimStruct* S, const char* name, ITI_int mxErrDimIdx, ITI_int sfErrDimIdx, ITI_int mxErrDim, ITI_int sfErrDim);
static ITI_int CheckVectorCompatibility(SimStruct* S, const char* name, ITI_Array* paramArr, const mxArray* mxArr);
static ITI_int CheckArrayCompatibility(SimStruct* S, const char* name, ITI_Array* paramArr, const mxArray* mxArr);

static void ReportArrayError(SimStruct* S, const char* name, ITI_int mxErrDimIdx, ITI_int sfErrDimIdx, ITI_int mxErrDim, ITI_int sfErrDim){
	static char buffer[400];
	sprintf(buffer, "Check array compatibility for parameter \"%s\" failed, "
		"because expected dimension[%d]=%d does not match passed dimension[%d]=%d",
		name, sfErrDimIdx, sfErrDim, mxErrDimIdx, mxErrDim);
	ssSetErrorStatus(S, buffer);
}

static ITI_int CheckVectorCompatibility(SimStruct* S, const char* name, ITI_Array* paramArr, const mxArray* mxArr){
	if (paramArr && mxArr) {
		ITI_int nDims = (ITI_int)mxGetNumberOfDimensions(mxArr);
		if (nDims == 2) {
			const ITI_mwSize* dims = mxGetDimensions(mxArr);
			if (dims[0] == 1) {
				if (paramArr->dims[0] == -1) {
					paramArr->dims[0] = (ITI_int)dims[1];
					return 1;
				}
				if (dims[1] == paramArr->dims[0])
					return 1;
				ReportArrayError(S, name, 0, paramArr->dims[0], 1, (ITI_int)dims[1]);
			}
		}
	}
	ReportArrayError(S, name, -1, -1, -1, -1);
	return 0;
}

static ITI_int CheckArrayCompatibility(SimStruct* S, const char* name, ITI_Array* paramArr, const mxArray* mxArr){
	if (paramArr && mxArr) {
		ITI_int nDims = (ITI_int)mxGetNumberOfDimensions(mxArr);
		if (nDims == paramArr->nDims) {
			ITI_int i = 0, paramArrDim = 0;
			const ITI_mwSize* dims = mxGetDimensions(mxArr);
			for (i = nDims-1; i >= 0; i--) {
				paramArrDim = paramArr->dims[i];
				if (paramArrDim == -1)
					paramArr->dims[i] = (ITI_int)dims[i];
				else if (dims[i] != paramArrDim) {
					ReportArrayError(S, name, i, nDims-2, (ITI_int)dims[i], paramArrDim);
					return -i;
				}
			}
			return 1;
		}
	}
	ReportArrayError(S, name, -1, -1, -1, -1);
	return 0;
}

void PropagateArrayParam(const mxArray* mxArr, ITI_Array*  paramArrays, ITI_Data_Array da, SimStruct* S, int_T nValues, int_T iArr){
	int_T n = 0;
	int_T v = 0;
	int_T idx = 0;
	int_T ret = 0;
	int_T index = 0;
	int_T nDims = (int_T)mxGetNumberOfDimensions(mxArr);
	int_T* dimIndizes = (int_T*)calloc(nDims, sizeof(int_T));
	ITI_Array* paramArr = &paramArrays[iArr];
	const ITI_char del[] = ",";
	ITI_char* token;
	ITI_char* strDims = (ITI_char*)malloc((strlen(da.dims)+1)*(sizeof(ITI_char)));
	strcpy(strDims, da.dims);

	paramArr->dims = (ITI_int*)calloc(nDims, sizeof(ITI_int));
	token = strtok(strDims, del);

	while (token) {
		ITI_int d = (ITI_int)strtol(token, 0, 10);
		if (n < nDims)
			paramArr->dims[n] = d;
		token = strtok(NULL, del);
		n++;
	}

	paramArr->nDims = n;

	if (paramArr->nDims == 1)
		ret = CheckVectorCompatibility(S, da.altName, paramArr, mxArr);
	else
		ret = CheckArrayCompatibility(S, da.altName, paramArr, mxArr);
	if (ret <= 0) {
		free(strDims);
		free(dimIndizes);
		return;
	}

	switch (da.valType) {
		case SharedType_Real:
			paramArr->realValues = (ITI_real*)calloc(nValues, sizeof(ITI_real));
			paramArr->memType = REAL_TYPE;
			break;
		case SharedType_Int:
			paramArr->intValues = (ITI_int*)calloc(nValues, sizeof(ITI_int));
			paramArr->memType = INT_TYPE;
			break;
		case SharedType_Str:
			paramArr->charValues = (ITI_char**)calloc(nValues, sizeof(ITI_char*));
			paramArr->memType = STRING_TYPE;
			break;
	}

	for (v = 0; v < nValues; v++) {
		index = 0;
		if (paramArr->nDims == 1) {
			index = v;
		}
		else {
			for (idx = 0; idx < nDims; idx++) {
				int_T temp = dimIndizes[idx];
				for (n = idx+1; n < nDims; n++) {
					temp *= paramArr->dims[n];
				}
				index += temp;
			}
		}

		switch (da.valType) {
			case SharedType_Real :
				paramArr->realValues[index] = mxGetPr(mxArr)[v];
				break;
			case SharedType_Int :
				paramArr->intValues[index] = (ITI_int)mxGetPr(mxArr)[v];
				break;
		}

		if (paramArr->nDims > 1) {
			for (idx = 0; idx < nDims; idx++) {
				int_T dimIndex = dimIndizes[idx];
				if (dimIndex+1 == paramArr->dims[idx])
					dimIndizes[idx] = 0;
				else {
					dimIndizes[idx] = dimIndizes[idx] + 1;
					break;
				}
			}
		}
	}
	free(strDims);
	free(dimIndizes);
}
