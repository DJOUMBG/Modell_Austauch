#include "ITI_crt.h"
#include "ITI_Declarations_pne_pne3d_generic_std_sf.h"
#include "ITI_FixStep_pne_pne3d_generic_std_sf.h"

#define S_FUNCTION_NAME ITI_projectName
#define S_FUNCTION_LEVEL 2

#include "ITI_ModelInclude_pne_pne3d_generic_std_sf.h"
#include "ITI_SFuncHelper.h"

/*Constant Data*/
extern ITI_CurveSetData curveSets_pne_pne3d_generic_std_sf[];
extern ITI_CurveData_ND curveNDs_pne_pne3d_generic_std_sf[];
extern ITI_uint seqCsSizes_pne_pne3d_generic_std_sf[];
extern ITI_DelayInfo delayInfos_pne_pne3d_generic_std_sf[];
extern ITI_uint DPBlockSizes_pne_pne3d_generic_std_sf[];
extern ITI_inputData inputs_pne_pne3d_generic_std_sf[];
extern ITI_outputData outputData_pne_pne3d_generic_std_sf[];
extern ITI_parameterData parameters_pne_pne3d_generic_std_sf[];
extern ITI_Data_Array parametersArr_pne_pne3d_generic_std_sf[];
extern ITI_ArrayData arrayData_pne_pne3d_generic_std_sf[];

static void HandleTraceMessage(SimStruct* S, void* pData);
static void Simulink_TraceFunc(int iTab, int iKind, const char* strCapt, const char* strTxt, const void* pVoid);

static void mdlInitializeSizes(SimStruct* S)
{
	int_T i = 0;
	ITI_ModelSize size;

	#ifdef MATLAB_MEX_FILE
	/* first call to mdlInitializeSizes */
	int_T firstCall = ssGetNumDiscStates(S) != 1 /* ITI_size_iz */;
	#endif

	InitModelSizes(&size);
	GetModelSizes_pne_pne3d_generic_std_sf(calloc, &size);

	/* Number of parameters */
	ssSetNumSFcnParams(S, size.ip_int + size.ip_real + size.ip_str + size.ip_arr + 2);

	/* Number of discrete states */
	ssSetNumDiscStates(S, 1);

	/* Number of inputs */
	if (!ssSetNumInputPorts(S, size.iu_real + size.iu_int + size.iu_str))
		return;

	for (i = 0; i < size.iu_real + size.iu_int; i++)
	{
		ssSetInputPortWidth(S, i, 1);

		/*input signals occupy contiguous area of memory*/
		ssSetInputPortRequiredContiguous(S, i, true);
		/*memory of inputs should not be overwritten*/
		ssSetInputPortOverWritable(S, i, false);
		/*
		 * Set direct feedthrough flag (1=yes, 0=no).
		 * A port has direct feedthrough if the input is used in either
		 * the mdlOutputs or mdlGetTimeOfNextVarHit functions.
		 * See matlabroot/simulink/src/sfuntmpl_directfeed.txt.
		 */
		ssSetInputPortDirectFeedThrough(S, i, 1);

		switch (inputs_pne_pne3d_generic_std_sf[i].type)
		{
		case SharedType_Real:
			ssSetInputPortDataType(S, i, SS_DOUBLE);
			break;
		case SharedType_Int:
			ssSetInputPortDataType(S, i, SS_INT32);
			break;
		default:
			break;
		}
	}

	/* Number of outputs */
	if (!ssSetNumOutputPorts(S, size.iy_int + size.iy_real + size.iy_str))
		return;

	for (i = 0; i < ssGetNumOutputPorts(S); i++)
	{
		ssSetOutputPortWidth(S, i, 1);
		switch (outputData_pne_pne3d_generic_std_sf[i].type)
		{
			case SharedType_Real:
				ssSetOutputPortDataType(S, i, SS_DOUBLE);
				break;
			case SharedType_Int:
				ssSetOutputPortDataType(S, i, SS_INT32);
				break;
			default:
				break;
		}
	}

	/*pData*/
	ssSetNumPWork(S, 1);

	ssSetNumIWork(S, 1);

	/* Number of sample times */
	/* ssSetNumSampleTimes(S, 1); */

	/* Not used until now */
	ssSetNumModes(S, 0);
	ssSetOptions(S, 0);

	#ifdef MATLAB_MEX_FILE
	if ((ssGetSimMode(S) == SS_SIMMODE_SIZES_CALL_ONLY) && /* prevent recursive calls of mdlInitializeSizes */ firstCall)
	{
		if (size.ip_int + size.ip_real + size.ip_str + size.ip_arr + 2 != ssGetSFcnParamsCount(S))
		{
			uint_T paramsLen = (size.ip_int + size.ip_real + size.ip_str + size.ip_arr + 2)*64 + 2;
			char* paramsStr = malloc(paramsLen*sizeof(char));
			char* buffer = malloc((paramsLen + strlen("try, set_param(gcb, 'Parameters', '%s', 'SFunctionModules', 'pne_pne3d_generic_std_sf_decl pne_pne3d_generic_std_sf_functions pne_pne3d_generic_std_sf_init pne_pne3d_generic_std_sf_initjac pne_pne3d_generic_std_sf_jac ITI_SFuncFixStepSolver_pne_pne3d_generic_std_sf ITI_FixStep_pne_pne3d_generic_std_sf ITI_big_uint ITI_Functions ITI_Memory ITI_ArrayFunctions ITI_LinSolver ModelicaUtilities snprintf ITI_SFuncHelper ITI_NonLinSolver_pne_pne3d_generic_std_sf ModelicaStandardTables ModelicaStandardTablesUsertab zlib c_aes ModelicaIO ModelicaMatIO'); end"))*sizeof(char));
			if (paramsStr && buffer)
			{
				ITI_int solverMode = ITI_solverMode;
				ITI_real dtMin = ITI_dtMin;

				sprintf(paramsStr, "%d, %.15lg, ", solverMode + 1, dtMin);

				for (i = 0; i < size.ip_int + size.ip_real + size.ip_str; ++i)
				{
					switch (parameters_pne_pne3d_generic_std_sf[i].valType)
					{
						case SharedType_Real:
							sprintf(buffer, "%.15lg, ", parameters_pne_pne3d_generic_std_sf[i].defaultValue);
							break;
						case SharedType_Int:
							sprintf(buffer, "%d, ", (int_T)parameters_pne_pne3d_generic_std_sf[i].defaultValue);
							break;
						case SharedType_Str:
							free(paramsStr);
							free(buffer);
							ssSetErrorStatus(S, "String parameters are not supported!");
							return;
						default:
							break;
					}
					strcat(paramsStr, buffer);
				}
				for (i = 0; i < size.ip_arr; ++i)
				{
					switch (parameters_pne_pne3d_generic_std_sf[i].valType)
					{
						case SharedType_Real:
						case SharedType_Int:
							sprintf(buffer, "%s, ", parametersArr_pne_pne3d_generic_std_sf[i].altName);
							break;
						case SharedType_Str:
							free(paramsStr);
							free(buffer);
							ssSetErrorStatus(S, "String parameters are not supported!");
							return;
						default:
							break;
					}
					strcat(paramsStr, buffer);
				}
				paramsStr[strlen(paramsStr) - 2] = '\0';
				sprintf(buffer, "try, set_param(gcb, 'Parameters', '%s', 'SFunctionModules', 'pne_pne3d_generic_std_sf_decl pne_pne3d_generic_std_sf_functions pne_pne3d_generic_std_sf_init pne_pne3d_generic_std_sf_initjac pne_pne3d_generic_std_sf_jac ITI_SFuncFixStepSolver_pne_pne3d_generic_std_sf ITI_FixStep_pne_pne3d_generic_std_sf ITI_big_uint ITI_Functions ITI_Memory ITI_ArrayFunctions ITI_LinSolver ModelicaUtilities snprintf ITI_SFuncHelper ITI_NonLinSolver_pne_pne3d_generic_std_sf ModelicaStandardTables ModelicaStandardTablesUsertab zlib c_aes ModelicaIO ModelicaMatIO'); end" , paramsStr);

				mexEvalString(buffer);
			}
			if (paramsStr)
			{
				free(paramsStr);
				paramsStr = NULL;
			}
			if (buffer)
			{
				free(buffer);
				buffer = NULL;
			}
		}
	}
	#endif
}

static void mdlInitializeSampleTimes(SimStruct* S)
{
}

#define MDL_START
static void mdlStart(SimStruct* S)
{
	int_T i = 0;
	void* pData = (void*)0;

	if (!CreateSolverInstance_pne_pne3d_generic_std_sf(&pData, 0, 0))
	{
		ssSetErrorStatus(S, "Error: SimulationX S-Function could not be instantiated!");
	}
	SetTraceCallback_pne_pne3d_generic_std_sf(pData, &Simulink_TraceFunc);
	SetContainerData_pne_pne3d_generic_std_sf(pData, (void*) S);

	for (i = 0; i < Get_size_p_allTypes(pData) + 2; i++)
		ssSetSFcnParamTunable(S, i, 0);

	ssGetPWork(S)[0] = pData;

	/*Initialization is necessary*/
	ssSetIWorkValue(S, 0, 1);
}

#define MDL_INITIALIZE_CONDITIONS
static void mdlInitializeConditions(SimStruct* S)
{

}

static void mdlOutputs(SimStruct* S, int_T tid)
{
	void* pData = ssGetPWork(S)[0];
	real_T tSimulink = ssGetT(S);
	int_T i;
	int_T bCompute=0;

	/*Initialization necessary?*/
	if (ssGetIWorkValue(S, 0) == 1){
		ITI_SolverSettings SSettings;
		double t = ssGetT(S);
		int_T iReal = 0, iInt = 0, iArr = 0;
		int_T iOK = 0;
		ITI_Array* paramArrays = ((ITI_FixStepData*)pData)->pData.arr_p;

		/*Initialization is done*/
		ssSetIWorkValue(S, 0, 0);

		for (i = 0; i < Get_size_u_allTypes(pData); i++)
		{
			switch (inputs_pne_pne3d_generic_std_sf[i].type)
			{
			case SharedType_Real:
				Get_uReal(pData)[inputs_pne_pne3d_generic_std_sf[i].typeIndex] = ssGetInputPortRealSignal(S, i)[0];
				break;
			case SharedType_Int:
				Get_uInt(pData)[inputs_pne_pne3d_generic_std_sf[i].typeIndex] = ((ITI_int*)ssGetInputPortSignal(S, i))[0];
				break;
			default:
				break;
			}
		}

		SSettings.tStart = t;
		SSettings.tStop = ITI_tStop;
		SSettings.dtMin = mxGetScalar(ssGetSFcnParam(S,1));
		SSettings.dtMax = ITI_dtMax;
		SSettings.dtDetect = ITI_dtDetect;
		SSettings.absTol = ITI_absTol;
		SSettings.relTol = ITI_relTol;
		SSettings.dtProtMin = mxGetScalar(ssGetSFcnParam(S,1));
		SSettings.mode = (int_T)mxGetScalar(ssGetSFcnParam(S,0)) - 1;
		SSettings.minmax = ITI_minmax;
		if (SSettings.mode < 0)
			SSettings.mode = 0;
		if (SSettings.mode > 4)
			SSettings.mode = 4;
		SSettings.saveMode = 0;
		SSettings.trace = _Trace_On;
		SSettings.limitdtMin = 0;
		SSettings.gltol = ITI_blockTol;
		SSettings.linSolv = ITI_blockLinSolv;
		SSettings.bAssertOn = _Modelica_Assert_On;
		SSettings.bAssertTraceOn = _Modelica_Assert_Trace_On;
		SSettings.parJac = 0;

		SetSolverSettings_pne_pne3d_generic_std_sf(pData, &SSettings);

		for (i = 0; i < Get_size_p_allTypes(pData) + Get_size_p_arr(pData); i++) {
			const mxArray* mxArr = ssGetSFcnParam(S, i + 2);
			int_T nValues = mxGetNumberOfElements(mxArr);
			if (i < Get_size_p_allTypes(pData)) {
				switch (parameters_pne_pne3d_generic_std_sf[i].valType) {
				case SharedType_Real:
					Get_pReal(pData)[iReal] = mxGetScalar(mxArr);
					iReal++;
					break;
				case SharedType_Int:
					Get_pInt(pData)[iInt] = (int_T)mxGetScalar(mxArr);
					iInt++;
					break;
				default:
					break;
				}
			}
			else {
				PropagateArrayParam(mxArr, paramArrays, parametersArr_pne_pne3d_generic_std_sf[iArr], S, nValues, iArr);
				iArr++;
			}
		}

		iOK = InitializeModel_pne_pne3d_generic_std_sf(pData);
		if (iOK==1)
			iOK = InitializeConditionsModel_pne_pne3d_generic_std_sf(pData);

		if (iOK==1)
		{
			HandleTraceMessage(S, pData);
			CalcOneStep_pne_pne3d_generic_std_sf(pData);
			/*HandleTraceMessage(S, pData);*/
			bCompute = 1;

			if (Get_TerminateState(pData)){
				ssSetErrorStatus(S, "SimulationX S-Function caused termination of the simulation run.\nAdditional Information can be found in the MATLAB output area.\n");
				return;
			}
		}
		else
		{
			HandleTraceMessage(S, pData);
			ssSetErrorStatus(S, "Initialization of SimulationX S-Function failed!\nAdditional Information can be found in the MATLAB output area.\n");
			return;
		}
	}

	while (Get_t(pData) < tSimulink)
	{
		if (!bCompute)
		{
			for (i = 0; i < Get_size_u_allTypes(pData); i++)
			{
				switch (inputs_pne_pne3d_generic_std_sf[i].type)
				{
				case SharedType_Real:
					Get_uReal(pData)[inputs_pne_pne3d_generic_std_sf[i].typeIndex] = ssGetInputPortRealSignal(S, i)[0];
					break;
				case SharedType_Int:
					Get_uInt(pData)[inputs_pne_pne3d_generic_std_sf[i].typeIndex] = ((ITI_int*)ssGetInputPortSignal(S, i))[0];
					break;
				default:
					break;
				}
			}
		}
		CalcOneStep_pne_pne3d_generic_std_sf(pData);
		HandleTraceMessage(S, pData);
		/*Check if anything happened*/
		if (Get_TerminateState(pData))
		{
			ssSetErrorStatus(S, "SimulationX S-Function caused termination of the simulation run.\nAdditional Information can be found in the MATLAB output area.\n");
			return;
		}
		bCompute = 1;
	}

	if (bCompute)
	{
		CalcModelOutputs_pne_pne3d_generic_std_sf(pData);
		HandleTraceMessage(S, pData);
		if (Get_TerminateState(pData)){
			ssSetErrorStatus(S, "SimulationX S-Function caused termination of the simulation run.\nAdditional Information can be found in the MATLAB output area.\n");
			return;
		}
		for (i = 0; i < Get_size_y_allTypes(pData); i++)
		{
			switch (outputData_pne_pne3d_generic_std_sf[i].type)
			{
			case SharedType_Real:
				ssGetOutputPortRealSignal(S, i)[0] = Get_yReal(pData)[outputData_pne_pne3d_generic_std_sf[i].typeIndex];
				break;
			case SharedType_Int:
				((int_T*)ssGetOutputPortSignal(S, i))[0] = Get_yInt(pData)[outputData_pne_pne3d_generic_std_sf[i].typeIndex];
				break;
			default:
				break;
			}
		}
	}
}

static void mdlTerminate(SimStruct* S)
{
	void* pData = ssGetPWork(S)[0];

	if (pData)
	{
		if (TerminateModel_pne_pne3d_generic_std_sf(pData) == 0) {
			ssSetErrorStatus(S, "SimulationX S-Function caused termination of the simulation run.\nAdditional Information can be found in the MATLAB output area.\n");
			return;
		}
		HandleTraceMessage(S, pData);
		FreeSolverInstance_pne_pne3d_generic_std_sf(pData);
		pData = (void*)0;
	}
}

#define MDL_ENABLE
static void mdlEnable(SimStruct *S)
{
	Set_t_pne_pne3d_generic_std_sf(ssGetPWork(S)[0], ssGetT(S));
}

static void HandleTraceMessage(SimStruct* S, void* pData)
{
	#if defined(SS_STDIO_AVAILABLE)
	if (Is_TraceStringAvailable(pData))
	{
		ssPrintf(Get_TraceString(pData));
		Clear_TraceString(pData);
	}
	#endif
}

static void Simulink_TraceFunc(int iTab, int iKind, const char* strCapt, const char* strTxt, const void* pVoid) {
	if (pVoid) {
		ITI_SolverInfo* psInfo = (ITI_SolverInfo*)pVoid;
		char strOut[100];
		char strMsg[5120];
		char strText[5120];

		if ((strlen(strTxt) > 0) && (strlen(strTxt) < 5119)) {
			sprintf(strText, strTxt);
		}
		else {
			sprintf(strText, "");
		}
		strcpy(strOut, "\n\nAdditional Information can be found in the MATLAB output area.\n\n");

		if (psInfo->pContainer) {
			SimStruct* S = (SimStruct*)psInfo->pContainer;

			switch (iKind)
			{
			case Info:
				sprintf(strMsg, "Information: %s. %s\n\n", strCapt, strText);
#if defined(SS_STDIO_AVAILABLE)
				ssPrintf(strMsg);
#endif
				break;
			case Warning:
				sprintf(strMsg, "Warning: %s. %s\n", strCapt, strText);
				ssWarning(S, strMsg);
				break;
			case Error:
				sprintf(strMsg, "Error: %s. %s\n", strCapt, strText);
				ssWarning(S, strMsg);
				sprintf(strMsg, "Error: %s. %s %s", strCapt, strText, strOut);
				ssSetErrorStatus(S, strMsg);
				break;
			case Debug:
				sprintf(strMsg, "Debug: %s. %s\n\n", strCapt, strText);
#if defined(SS_STDIO_AVAILABLE)
				ssPrintf(strMsg);
#endif
				break;
			}
		}
	}
}


/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
