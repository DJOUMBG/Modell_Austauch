#ifndef ITI_FIXSTEP_DECLARATIONS_H
#define ITI_FIXSTEP_DECLARATIONS_H

#ifdef _MSC_VER
#include <excpt.h>
#endif
#ifdef ITI_COMP_SIM
#include "ITI_ClockInference.h"
#endif

#define _state(i) _pData->x[i]
#define _der_state(i) _pData->xdot[i]

#define _bstate(i) _pData->bx[i]

#define _zero(i) _pData->zf[i]
#define _pre_zero(i) _pData->pre_zf[i]

#define _parameter_real(i, gi) _pData->p.realData[i]
#define _parameter_int(i, gi) _pData->p.intData[i]
#define _parameter_str(i, gi) _pData->p.strData[i]

#define _bcdiscrete_real(i) _bcVarData->z.realData[i]
#define _scdiscrete_real(i) _scVarData->z.realData[i]
#define _discrete_real(i) _pData->z.realData[i]
#define _bcdiscrete_int(i) _bcVarData->z.intData[i]
#define _scdiscrete_int(i) _scVarData->z.intData[i]
#define _discrete_int(i) _pData->z.intData[i]
#define _bcdiscrete_str(i) _bcVarData->z.strData[i]
#define _scdiscrete_str(i) _scVarData->z.strData[i]
#define _discrete_str(i) _pData->z.strData[i]
#define _bcpre_discrete_real(i) _bcVarData->pre_z.realData[i]
#define _scpre_discrete_real(i) _scVarData->pre_z.realData[i]
#define _pre_discrete_real(i) _pData->pre_z.realData[i]
#define _bcpre_discrete_int(i) _bcVarData->pre_z.intData[i]
#define _scpre_discrete_int(i) _scVarData->pre_z.intData[i]
#define _pre_discrete_int(i) _pData->pre_z.intData[i]
#define _bcpre_discrete_str(i) _bcVarData->pre_z.strData[i]
#define _scpre_discrete_str(i) _scVarData->pre_z.strData[i]
#define _pre_discrete_str(i) _pData->pre_z.strData[i]

#define _bcinput_real(i, gi) _bcVarData->u.realData[i]
#define _scinput_real(i, gi) _scVarData->u.realData[i]
#define _input_real(i, gi) _pData->u.realData[i]
#define _bcinput_int(i, gi) _bcVarData->u.intData[i]
#define _scinput_int(i, gi) _scVarData->u.intData[i]
#define _input_int(i, gi) _pData->u.intData[i]
#define _bcinput_str(i, gi) _bcVarData->u.strData[i]
#define _scinput_str(i, gi) _scVarData->u.strData[i]
#define _input_str(i, gi) _pData->u.strData[i]
#define _bcvariable_real(i) _bcVarData->v.realData[i]
#define _scvariable_real(i) _scVarData->v.realData[i]
#define _variable_real(i) _pData->v.realData[i]
#define _bcvariable_int(i) _bcVarData->v.intData[i]
#define _scvariable_int(i) _scVarData->v.intData[i]
#define _variable_int(i) _pData->v.intData[i]
#define _bcvariable_str(i) _bcVarData->v.strData[i]
#define _scvariable_str(i) _scVarData->v.strData[i]
#define _variable_str(i) _pData->v.strData[i]
#define _bccurve_sets(i) _bcVarData->cSet[i]
#define _sccurve_sets(i) _scVarData->cSet[i]
#define _curve_sets(i) _pData->cSet[i]
#define _bccurve_nds(i) _bcVarData->cNd[i]
#define _sccurve_nds(i) _scVarData->cNd[i]
#define _curve_nds(i) _pData->cNd[i]
#define _bccall_state(i) _bcVarData->cs[i]
#define _sccall_state(i) _scVarData->cs[i]
#define _call_state(i) _pData->cs[i]
#define _bcsample_variable(i) _bcVarData->sv[i]
#define _scsample_variable(i) _scVarData->sv[i]
#define _sample_variable(i) _pData->sv[i]
#define _bchyst_call_state(i) _bcVarData->hcs[i]
#define _schyst_call_state(i) _scVarData->hcs[i]
#define _hyst_call_state(i) _pData->hcs[i]

#define _parameter_real_arr(i,j) _pData->arr_p[i].realValues[j]
#define _parameter_int_arr(i,j) _pData->arr_p[i].intValues[j]
#define _parameter_str_arr(i,j) _pData->arr_p[i].strValues[j]

#define _parameter_arr(i) _pData->arr_p[i]

#define __bcOUT_INT(i, gi, var) _bcVarData->y.intData[i] = var;
#define __scOUT_INT(i, gi, var) _scVarData->y.intData[i] = var;
#define __OUT_INT(i, gi, var) _pData->y.intData[i] = var;
#define __bcOUT_REAL(i, gi, var) _bcVarData->y.realData[i] = var;
#define __scOUT_REAL(i, gi, var) _scVarData->y.realData[i] = var;
#define __OUT_REAL(i, gi, var) _pData->y.realData[i] = var;
#define __bcOUT_STR(i, gi, var) _bcVarData->y.strData[i] = var;
#define __scOUT_STR(i, gi, var) _scVarData->y.strData[i] = var;
#define __OUT_STR(i, gi, var) _pData->y.strData[i] = var;

#define _ext_object(i) _data->extObj[i]

#define __RECORD(name) ((ITI_Records*)_pData->pRecord)->name
#define __DUMMY_RECORD typedef struct ITI_Records {char* dummy;}ITI_Records;

#define _sInfo _pData->sInfo
#define __ibd (&_pData->ibd[blockNr])
#define __iDPbd(k) _pData->iDPbd[k]
#define __hmm _data->hmm
#define __hom_res _data->hom_res
#define __hom_jac _data->hom_jac
#define _hcs _pData->hcs
#define _db _pData->db
#define _t _pData->t
#define _time _t
#define __array(i) _pData->arrays[i]
#define _dt _sInfo.dt

#define __azf(index,b,cond,e1,e2) \
if(cond){ \
	if(b) __ITI_UpdateEpsilonOsZF(_pData, index); \
	__ITI_AssignZF((e1),(e2),index,_pData); \
	_pData->ezf[index]=1; \
	_pData->czf[index]=1;} \
else \
	_pData->czf[index]=0;

#define __szf(index) _pData->szf[index]

#define __IF_IS_EVENT if(_sInfo.isEvent)

/*
#ifdef _MSC_VER
	#define DLL_Export __declspec(dllexport)
#else
	#define DLL_Export
#endif
*/

#define Param_Declare_SimData ITI_SimData* _data
#define Param_Declare_SimVar ITI_SimVar* _pData
#define Param_Passing_SimData _data
#define Param_Passing_SimVar _pData
#define Param_SInfo_Mem &_pData->sInfo, &_data->currMem
#define Param_Mem &_data->currMem
#define Param_Str_Mem &_data->strMem

#define ResolveResource(strFile) \
__ITI_ResolveResourceFolder(Param_Passing_SimVar, Param_Passing_SimData, strFile)

#define AllocateRecords_Head void AllocateRecords_pne_pne3d_generic_std_sf(ITI_SimVar* _pData)
#define AllocateRecords_Declare AllocateRecords_Head ;

#define DLL_Export

#if defined(ITI_DSPACE)

#define F_BEGIN \
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	if (setjmp(_sInfo.buf) == 0) {

#define FM_BEGIN \
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	if (setjmp(_sInfo.buf) == 0) {

#define FD_BEGIN \
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	if (setjmp(_sInfo.buf) == 0) {

#define F_END \
		_sInfo.allowJump = 0;\
		return 0;\
	} else {\
		_sInfo.allowJump = 0;\
		return 1;\
	}\
}

#elif defined(ITI_SCALERT)

#define F_BEGIN
#define FM_BEGIN
#define F_END \
	return 0;\
}

#elif defined(_MSC_VER)

#define F_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	UnmaskExceptions(&oldCW, &oldHandler);\
	__try {

#define FM_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	DisableExceptions(&oldCW, &oldHandler);\
	__try {

#define FD_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	UnmaskExceptions(&oldCW, &oldHandler);\
	CHECK_REAL_INPUTS\
	__try {

#define F_END \
		RestoreMask(oldCW, oldHandler);\
		return 0;\
	}\
	__except (FPEfilter(GetExceptionCode(), &_sInfo)) {\
		RestoreMask(oldCW, oldHandler);\
		return 1;\
	}\
}

#else

#define F_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	UnmaskExceptions(&oldCW, &oldHandler);\
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	if (setjmp(_sInfo.buf) == 0) {

#define FM_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	DisableExceptions(&oldCW, &oldHandler);\
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	if (setjmp(_sInfo.buf) == 0) {

#define FD_BEGIN \
	void (*oldHandler)(int);\
	int oldCW;\
	UnmaskExceptions(&oldCW, &oldHandler);\
	_sInfo.allowJump = 1;\
	_sInfo.allowBlockJump = 0;\
	CHECK_REAL_INPUTS\
	if (setjmp(_sInfo.buf) == 0) {

#define F_END \
		RestoreMask(oldCW, oldHandler);\
		_sInfo.allowJump = 0;\
		return 0;\
	} else {\
		RestoreMask(oldCW, oldHandler);\
		_sInfo.allowJump = 0;\
		return 1;\
	}\
}

#endif

#ifndef isfinite
#ifdef _MSC_VER
#define isfinite _finite
#elif defined(__gnu_linux__)
#define isfinite finite
#else
#define isfinite ITI_finite
#endif
#endif

#define CHECK_REAL_INPUTS {\
	ITI_int i;\
	for (i = 0; i < _pData->size.iu_real; i++)\
		if (!isfinite(_pData->u.realData[i])) {\
			char msg[100];\
			sprintf(msg, "Input u[%d] to the model is not valid (Inf or NaN).\n", i);\
			_errorFunction(0, msg, &_sInfo);\
		}\
}

#define InitializeConstants_Head static ITI_int InitializeConstants(ITI_SimVar* _pData, ITI_SimData* _data)
#define InitializeConstants_Declare InitializeConstants_Head ;
#define InitializeConstants_Begin InitializeConstants_Head {\
	FM_BEGIN
#define InitializeConstants_End F_END

#define InitializeParameterDependent_Head static ITI_int InitializeParameterDependent(ITI_SimVar* _pData, ITI_SimData* _data)
#define InitializeParameterDependent_Declare InitializeParameterDependent_Head ;
#define InitializeParameterDependent_Begin InitializeParameterDependent_Head {\
	FM_BEGIN
#define InitializeParameterDependent_End F_END

#define InitializeTunableParameter_Head static ITI_int InitializeTunableParameter(ITI_SimVar* _pData, ITI_SimData* _data)
#define InitializeTunableParameter_Declare InitializeTunableParameter_Head ;
#define InitializeTunableParameter_Begin InitializeTunableParameter_Head {\
	FM_BEGIN
#define InitializeTunableParameter_End F_END

#define Initialize_Head static ITI_int Initialize(ITI_SimVar* _pData, ITI_SimData* _data)
#define Initialize_Declare Initialize_Head ;
#define Initialize_Begin Initialize_Head {\
	FM_BEGIN
#define Initialize_End F_END

#define GetModelSizes_Head void GetModelSizes_pne_pne3d_generic_std_sf(ITI_AllocateMemory allocateMemory, ITI_ModelSize* pSize)
#define GetModelSizes_Declare GetModelSizes_Head ;
#define Declare_ModelSizes_Begin GetModelSizes_Head \
{pSize->numBlocks = GetNumberOfBlocks_pne_pne3d_generic_std_sf(); pSize->numStateAttr = GetSizeOfStateAttr_pne_pne3d_generic_std_sf();
#define Declare_ModelSizes_End }
#define GetPartitionSizes_Head static void GetPartitionSizes(ITI_AllocateMemory allocateMemory, ITI_ModelSize* pSize)
#define GetPartitionSizes_Declare GetPartitionSizes_Head ;
#define Declare_PartitionSizes_Begin GetPartitionSizes_Head \
{pSize->numBlocks = GetNumberOfBlocks_pne_pne3d_generic_std_sf(); pSize->numStateAttr = GetSizeOfStateAttr_pne_pne3d_generic_std_sf();
#define Declare_PartitionSizes_End }

#define GetModelSolverSettings_Head DLL_Export void GetModelSolverSettings_pne_pne3d_generic_std_sf(ITI_SolverSettings* pSS)
#define GetModelSolverSettings_Declare GetModelSolverSettings_Head ;

#define InitializeConditions_Head static ITI_int InitializeConditions(ITI_SimVar* _pData, ITI_SimData* _data)
#define InitializeConditions_Declare InitializeConditions_Head ;
#define InitializeConditions_Begin InitializeConditions_Head {\
	FD_BEGIN
#define InitializeConditions_End F_END

#define CalcOutputs_Head static ITI_int CalcOutputs(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define CalcOutputs_Declare CalcOutputs_Head ;
#define CalcOutputs_Begin CalcOutputs_Head {\
	F_BEGIN
#define CalcOutputs_End F_END

#define SynchOutputs_Head static ITI_int SynchOutputs(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define SynchOutputs_Declare SynchOutputs_Head ;
#define SynchOutputs_Begin SynchOutputs_Head {\
	F_BEGIN
#define SynchOutputs_End F_END

#define ValidStep_Head static ITI_int ValidStep(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define ValidStep_Declare ValidStep_Head ;
#define ValidStep_Begin ValidStep_Head {\
	F_BEGIN
#define ValidStep_End F_END

#define CalcDerivatives_Head static ITI_int CalcDerivatives(ITI_SimVar* _pData, ITI_SimData* _data)
#define CalcDerivatives_Declare CalcDerivatives_Head ;
#define CalcDerivatives_Begin CalcDerivatives_Head {\
	FD_BEGIN
#define CalcDerivatives_End F_END

#define Declare_StateNames_Head
#define Declare_StateNames_None
#define Declare_StateNames_Begin
#define Declare_StateNames_End

#define Declare_StateName(n,name)
#define Declare_DStateName(n,name)

#define Declare_ModelInfo_Head static void GetModelInfo(ITI_ModelInfo* pInfo)
#define ModelInfo_Declare Declare_ModelInfo_Head ;
#define Declare_ModelInfo_Begin Declare_ModelInfo_Head {
#define Declare_ModelInfo_End }

#define Declare_bNeedExtendedOnValidStep(b) pInfo->bNeedExtendedOnValidStep=b;
#define Declare_bHasDummyVariables(b) pInfo->bHasDummyVariables=b;

#define SampleFunction_Head static void SampleFunction(ITI_SimVar* _pData, ITI_SimData* _data)
#define SampleFunction_Declare SampleFunction_Head ;
#define SampleFunction_Begin SampleFunction_Head {
#define SampleFunction_WorkVar ITI_int __i=0;
#define SampleFunction_End }
#define Declare_SampleFunction(_to, _ts) \
	_pData->sampleTime[__i].to = _to;\
	_pData->sampleTime[__i++].ts = _ts;\

#define AssignLastVar_Head static void AssignLastVar(ITI_SimVar* _pData, ITI_SimData* _data)
#define AssignLastVar_Declare AssignLastVar_Head ;
#define AssignLastVar_Begin AssignLastVar_Head {
#define AssignLastVar_End }

#define AssignDiscreteReal_Head static void AssignDiscreteReal(ITI_SimVar* _pData, ITI_SimData* _data)
#define AssignDiscreteReal_Declare AssignDiscreteReal_Head ;
#define AssignDiscreteReal_Begin AssignDiscreteReal_Head {
#define AssignDiscreteReal_End }

#define FreeRecords_Head void FreeRecords_pne_pne3d_generic_std_sf(ITI_SimVar* _pData, ITI_SimData* _data)
#define FreeRecords_Declare FreeRecords_Head ;

#define Terminate_Head static ITI_int Terminate(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define Terminate_Declare Terminate_Head ;
#define Terminate_Begin Terminate_Head {\
	F_BEGIN
#define Terminate_End F_END \
FreeRecords_Head { \
  if (_pData->size.iRec > 0){ \
	free(_pData->pRecord); \
	_pData->pRecord = NULL; \
  } \
}

#define PreActivation_Head static ITI_int PreActivation(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define PreActivation_Declare PreActivation_Head ;
#define PreActivation_Begin PreActivation_Head {\
	F_BEGIN
#define PreActivation_End F_END

#define PostActivation_Head static ITI_int PostActivation(ITI_SimVar* _pData, ITI_SimVar* _bcVarData, ITI_SimVar* _scVarData, ITI_SimData* _data)
#define PostActivation_Declare PostActivation_Head ;
#define PostActivation_Begin PostActivation_Head {\
	F_BEGIN
#define PostActivation_End F_END

#define CLOCK_TICK(clockid) _sInfo.DoClockTick(_sInfo.pContainer, clockid);
#define CLOCKED_INIT(clockid) _sInfo.DoClockedInit(_sInfo.pContainer, clockid);
#define NEXT_CLOCK_TICK(clockid, nexttick) _sInfo.NextClockTick(_sInfo.pContainer, clockid, nexttick);

#define GetCheckSum_Decl unsigned long GetCheckSum(void);
#define GetCheckSum_Impl(check_sum) \
	unsigned long GetCheckSum(void){return check_sum;}

#define GetInterfaceVersion_DeclITI_real GetInterfaceVersion(void);
#define GetInterfaceVersion_Impl \
	ITI_real GetInterfaceVersion(void){return ITI_INTERFACE_VERSION;}

#define Declare_Parameter_None DLL_Export ITI_parameterData parameters_pne_pne3d_generic_std_sf[1];
#define Declare_Parameter_Begin DLL_Export ITI_parameterData parameters_pne_pne3d_generic_std_sf[] = {
#define Declare_Parameter_End };
#define Declare_Parameter(name,comment,default_value,unit, signalName, paramType, valType) \
	{name, comment, default_value, unit, signalName, paramType, valType},

#define Declare_Parameter_Arr_None DLL_Export ITI_Data_Array parametersArr_pne_pne3d_generic_std_sf[1];
#define Declare_Parameter_Arr_Begin DLL_Export ITI_Data_Array parametersArr_pne_pne3d_generic_std_sf[] = {
#define Declare_Parameter_Arr_End };
#define Declare_Data_Arr(name, comment, altName, unit, dims, nDims, valType) \
	{name, comment, altName, unit, dims, nDims, valType},


#define Declare_Input_None DLL_Export ITI_inputData inputs_pne_pne3d_generic_std_sf[1];
#define Declare_Input_Begin DLL_Export ITI_inputData inputs_pne_pne3d_generic_std_sf[] = {
#define Declare_Input_End };
#define Declare_Input(name,comment,default_value, bInterpol, bDirectThrough, signalName, paramType, typeStr, typeIndex) \
	{name, comment, default_value, bInterpol, bDirectThrough, signalName, paramType, typeStr, typeIndex},

/*
#define Declare_V_None DLL_Export ITI_varData dataV[1];
#define Declare_V_Begin DLL_Export ITI_varData dataV[] = {
#define Declare_V_End };
#define Declare_V(name,index, indexSimX, dim) \
	{name, index, indexSimX, dim},

#define Declare_Z_None DLL_Export ITI_varData dataZ[1];
#define Declare_Z_Begin DLL_Export ITI_varData dataZ[] = {
#define Declare_Z_End };
#define Declare_Z(name,index, indexSimX, dim) \
	{name, index, indexSimX, dim},

#define Declare_X_None DLL_Export ITI_varData dataX[1];
#define Declare_X_Begin DLL_Export ITI_varData dataX[] = {
#define Declare_X_End };
#define Declare_X(name,index, indexSimX, dim) \
	{name, index, indexSimX, dim},
*/

#define Declare_Output_None DLL_Export ITI_outputData outputData_pne_pne3d_generic_std_sf[1];
#define Declare_Output_Begin DLL_Export ITI_outputData outputData_pne_pne3d_generic_std_sf[] = {
#define Declare_Output_End };
#define Declare_Output(name,comment,unit, signalName, type, typeIndex) \
	{name, comment, unit, signalName, type, typeIndex},

#define Declare_ZF_None ITI_zerofunctionData dataZF_pne_pne3d_generic_std_sf[1];
#define Declare_ZF_Begin ITI_zerofunctionData dataZF_pne_pne3d_generic_std_sf[] = {
#define Declare_ZF_End };
#define Declare_ZF(name, index, parent, rel, needHysterese, expr) \
	{name, index, parent, rel, needHysterese, expr},

#define Declare_CurveSetData_None DLL_Export ITI_CurveSetData curveSets_pne_pne3d_generic_std_sf[1];
#define Declare_CurveSetData_Begin DLL_Export ITI_CurveSetData curveSets_pne_pne3d_generic_std_sf[] = {
#define Declare_CurveSetData_End };
#define Declare_CurveSetData(name, orig_name, nYScale, param_idx) \
	{sizeof(name##_X)/sizeof(ITI_real), sizeof(name##_pY)/sizeof(ITI_real*),\
	name##_YInfo, name##_X, name##_pY, name##_pYCoeff, #orig_name, nYScale, 0, param_idx},

#define Declare_CurveNDData_None DLL_Export ITI_CurveData_ND curveNDs_pne_pne3d_generic_std_sf[1];
#define Declare_CurveNDData_Begin DLL_Export ITI_CurveData_ND curveNDs_pne_pne3d_generic_std_sf[] = {
#define Declare_CurveNDData_End };
#define Declare_CurveNDData(name, orig_name, nYScale) \
	{sizeof(name##_X)/sizeof(ITI_real), sizeof(name##_Y)/sizeof(ITI_real),\
	sizeof(name##_Z)/sizeof(ITI_real), name##_AxisInfo, name##_X, name##_Y,\
	name##_Z, name##_Val, name##_pYCoeff, #orig_name, nYScale, 0},

#define Declare_SeqCsSize_None DLL_Export ITI_uint seqCsSizes_pne_pne3d_generic_std_sf[1];
#define Declare_SeqCsSize_Begin DLL_Export ITI_uint seqCsSizes_pne_pne3d_generic_std_sf[] = {
#define Declare_SeqCsSize_End };
#define Declare_SeqCsSize(size) size,

#define Declare_DelayInfo_None DLL_Export ITI_DelayInfo delayInfos_pne_pne3d_generic_std_sf[1];
#define Declare_DelayInfo_Begin DLL_Export ITI_DelayInfo delayInfos_pne_pne3d_generic_std_sf[] = {
#define Declare_DelayInfo_End };
#define Declare_DelayInfo(bufSize, valType, name) \
	{bufSize, valType, name},

#define Declare_HystInitFunction_None ITI_HystCurveInitData _hyst_init_data_pne_pne3d_generic_std_sf[1];
#define Declare_HystInitFunction_Begin ITI_HystCurveInitData _hyst_init_data_pne_pne3d_generic_std_sf[] = {
#define Declare_HystInitFunction_End };
#define Declare_HystInitFunction(name, enabled, hystMode, clockwise, startPoint, startValue, eps_xdot) \
	{name, enabled, hystMode, clockwise, startPoint, startValue, eps_xdot},

#define HYST_INIT_DATA(idx) _pData->_hyst_init_data[idx]

#define Declare_StateAttributes_None DLL_Export ITI_VarAttributes stateAttributes_pne_pne3d_generic_std_sf[1]; \
GetSizeOfStateAttr_Head \
{ \
	return 0; \
}

#define Declare_StateAttributes_Begin DLL_Export ITI_VarAttributes stateAttributes_pne_pne3d_generic_std_sf[] = {
#define Declare_StateAttributes_End }; \
GetSizeOfStateAttr_Head \
{ \
	return sizeof(stateAttributes_pne_pne3d_generic_std_sf) / sizeof(stateAttributes_pne_pne3d_generic_std_sf[0]); \
}

#define Declare_StateAttributes(stateIdx, startIdx, minIdx, maxIdx, fixedIdx, notFixedIdx, nominalIdx, minNotReachedIdx, maxNotReachedIdx, absTolIdx, relTolIdx, discontChangeIdx) \
	{stateIdx, startIdx, minIdx, maxIdx, fixedIdx, notFixedIdx, nominalIdx, minNotReachedIdx, maxNotReachedIdx, absTolIdx, relTolIdx, discontChangeIdx},

#define GetSizeOfStateAttr_Head static int GetSizeOfStateAttr_pne_pne3d_generic_std_sf(void)
#define GetSizeOfStateAttr_Declare GetSizeOfStateAttr_Head ;

#define GetNumberOfBlocks_Head static int GetNumberOfBlocks_pne_pne3d_generic_std_sf()
#define GetNumberOfBlocks_Declare GetNumberOfBlocks_Head;

#define Declare_BlockSizes_None ITI_BlockSizes blockSizes_pne_pne3d_generic_std_sf[1]; \
GetNumberOfBlocks_Head \
{ \
	return 0; \
} \
InitBlockVars_Begin \
InitBlockVars_End


#define Declare_BlockSizes_Begin ITI_BlockSizes blockSizes_pne_pne3d_generic_std_sf[] = {
#define Declare_BlockSizes_End }; \
GetNumberOfBlocks_Head \
{ \
	return sizeof(blockSizes_pne_pne3d_generic_std_sf) / sizeof(blockSizes_pne_pne3d_generic_std_sf[0]); \
}

#define Declare_BlockSizes(ires, iDAE, iHybrid_Z_Real, iHybrid_Z_Int, iHybrid_Z_Str, iHybrid_Zf, nrDPBlock, isNonlinear) \
	{ires, iDAE, iHybrid_Z_Real, iHybrid_Z_Int, iHybrid_Z_Str, iHybrid_Zf, nrDPBlock, isNonlinear},

#define InitBlockVars_Head static void InitBlockVars(ITI_BlockData *bd)
#define InitBlockVars_Declare InitBlockVars_Head;
#define InitBlockVars_Begin InitBlockVars_Head {
#define InitBlockVars_End }

#define Declare_NumJacCols_None ITI_int numJacColsData_pne_pne3d_generic_std_sf[1];
#define Declare_NumJacCols_Begin ITI_int numJacColsData_pne_pne3d_generic_std_sf[] = {
#define Declare_NumJacCols_End };

#define Declare_DPBlock_None DLL_Export ITI_uint DPBlockSizes_pne_pne3d_generic_std_sf[1];
#define Declare_DPBlock_Begin ITI_uint DPBlockSizes_pne_pne3d_generic_std_sf[] = {
#define Declare_DPBlock_End };

#define Declare_Array_None DLL_Export ITI_ArrayData arrayData_pne_pne3d_generic_std_sf[1];
#define Declare_Array_Begin DLL_Export ITI_ArrayData arrayData_pne_pne3d_generic_std_sf[] = {
#define Declare_Array_End };
#define Declare_Array(nDims, nValues, memType) \
	{nDims, nValues, memType},

#define Declare_SeqInfo(name, n) \
		ITI_SeqInfoY name##_YInfo[n];

#define Declare_AxisInfo(name, n) \
		ITI_AxisInfo name##_AxisInfo[n];

#define Declare_SimXCurveSetData(name, orig_name, nYScale) \
		{0, 0, name##_YInfo, 0, 0, 0, #orig_name, nYScale, 0},

#define Declare_SimXCurveNDData(name, orig_name, nYScale) \
		{0, 0, 0, name##_AxisInfo, 0, 0, 0, 0, 0, #orig_name, nYScale, 0},

#define Declare_IntSize(var, size) \
	pSize->var = size;

#define Declare_InferenceGraph_Head void InitInferenceGraph_pne_pne3d_generic_std_sf(ITI_SimVar* _pData)
#define InferenceGraph_Declare Declare_InferenceGraph_Head ;
#define Declare_InferenceGraph_None Declare_InferenceGraph_Head {}
#define Declare_InferenceGraph_Begin Declare_InferenceGraph_Head {
#define Declare_InferenceGraph_End }
#define Declare_GraphInfo(idx, clockType, baseInterval) initInferenceGraph(&(_pData->partitionIG[idx]), clockType, baseInterval);
#define Declare_Node(id, nodeId, firstChld, numChldrn, ival, resolut, slvMeth, baseClk, needSlv, slv, constr) \
initNode(&(_pData->partitionIG[id]), nodeId, firstChld, numChldrn, ival, resolut, slvMeth, baseClk, needSlv, slv, constr);
#define Declare_Edge(id, nodeFrom, nodeTo, edgeId, neighbFrom, neighbTo, edgeT, factor, shift, alias, aliasFrom, path, constr) \
initEdge(&(_pData->partitionIG[id]), nodeFrom, nodeTo, edgeId, neighbFrom, neighbTo, edgeT, factor, shift, alias, aliasFrom, path, constr);

#define Declare_PartitionData_Head void GetPartitionData_pne_pne3d_generic_std_sf(ITI_SimVar* _pData, ITI_SimData* _data)
#define GetPartitionData_Declare Declare_PartitionData_Head ;
#define Declare_PartitionData_Begin Declare_PartitionData_Head {
#define Declare_PartitionData_End }
#define Declare_Partition(cpt, pid, bcid, scid, sa, hc, activ, p, c, sm, ec) \
	_pData->partitionData[pid].type=cpt; \
	_pData->partitionData[pid].id=pid; \
	_pData->partitionData[pid].baseid=bcid; \
	_pData->partitionData[pid].subid=scid; \
	_pData->partitionData[pid].sampleActive=sa; \
	_pData->partitionData[pid].holdChanged=hc; \
	_pData->partitionData[pid].activated=activ; \
	_pData->partitionData[pid].periodic=p; \
	_pData->partitionData[pid].continous=c; \
	_pData->partitionData[pid].solvermethod=sm; \
	_pData->partitionData[pid].eventClock=ec;

#define UpdateInferenceGraph_Head void UpdateInferenceGraph_pne_pne3d_generic_std_sf(ITI_SimVar* _pData, ITI_SimData* _data)
#define UpdateInferenceGraph_Begin UpdateInferenceGraph_Head {
#define UpdateInferenceGraph_End }

#define update_ignode(idx,nidx,interval,resolution,ticks,maxticks,solvermethod) \
	updateIGNode(&(_pData->partitionIG[idx]),nidx,interval,resolution,ticks,maxticks,GetIGSolverType(solvermethod))

#define update_igedge(idx,eidx,factor,shift) \
	updateIGEdge(&(_pData->partitionIG[idx]),eidx,factor,shift)

#define PerformInferenceGraph_Head void PerformInferenceGraph_pne_pne3d_generic_std_sf(ITI_SimVar* _pData, ITI_SimData* _data)
#define PerformInferenceGraph_Define PerformInferenceGraph_Head { \
	int i; \
	int iig = _pData->size.iig; \
	for (i = 0; i < iig; i++) { \
		performClockInference(&(_pData->partitionIG[i])); \
	} \
}

#define LoadInferenceGraphResults_Head void LoadInferenceGraphResults(ITI_SimVar* _pData, ITI_SimData* _data)
#define LoadInferenceGraphResults_Begin LoadInferenceGraphResults_Head {
#define LoadInferenceGraphResults_End }

#define loadres_BaseInterval(idx,binterval) \
	loadResultBaseInterval(&(_pData->partitionIG[idx]),binterval)

#define loadres_ignode(idx,nidx,interval,maxTicks,ticks,solvermethod,stridx) \
	AssignString2(&_data->strMem, (const ITI_char**)solvermethod, loadResult_ignode(&(_pData->partitionIG[idx]),nidx,interval,maxTicks,ticks), \
		(const ITI_char**)_pData->v.strData, _pData->v.strSize, stridx)

#define Factory_Partition_Access_Init_Name(pidx) FactoryPartitionAccessInit_pne_pne3d_generic_std_sf_##pidx
#define Factory_Partition_Access_Init_Head(pidx) void Factory_Partition_Access_Init_Name(pidx)(ITI_PartitionFunctionAccess* _partition)
#define Factory_Partition_Access_Init_Begin(pidx) Factory_Partition_Access_Init_Head(pidx) {
#define Factory_Partition_Access_Init_End }
#define Factory_Partition_Access_Main_Name(pidx) FactoryPartitionAccessMain_pne_pne3d_generic_std_sf_##pidx
#define Factory_Partition_Access_Main_Head(pidx) void Factory_Partition_Access_Main_Name(pidx)(ITI_PartitionFunctionAccess* _partition)
#define Factory_Partition_Access_Main_Begin(pidx) Factory_Partition_Access_Main_Head(pidx) {
#define Factory_Partition_Access_Main_End }
#define Factory_Partition_Access_Decl_Name(pidx) FactoryPartitionAccessDecl_pne_pne3d_generic_std_sf_##pidx
#define Factory_Partition_Access_Decl_Head(pidx) void Factory_Partition_Access_Decl_Name(pidx)(ITI_PartitionFunctionAccess* _partition)
#define Factory_Partition_Access_Decl_Begin(pidx) Factory_Partition_Access_Decl_Head(pidx) { \
_partition->arrayData = arrayData_pne_pne3d_generic_std_sf; \
_partition->dataZF = dataZF_pne_pne3d_generic_std_sf; \
_partition->curveSets = curveSets_pne_pne3d_generic_std_sf; \
_partition->curveNDs = curveNDs_pne_pne3d_generic_std_sf; \
_partition->blockSizes = blockSizes_pne_pne3d_generic_std_sf; \
_partition->stateAttributes = stateAttributes_pne_pne3d_generic_std_sf; \
_partition->seqCsSizes = seqCsSizes_pne_pne3d_generic_std_sf; \
_partition->delayInfos = delayInfos_pne_pne3d_generic_std_sf; \
_partition->_hyst_init_data = _hyst_init_data_pne_pne3d_generic_std_sf; \
_partition->numJacColsData = numJacColsData_pne_pne3d_generic_std_sf; \
_partition->DPBlockSizes = DPBlockSizes_pne_pne3d_generic_std_sf;

#define Factory_Partition_Access_Decl_End }

#define Factory(function) _partition->function = function;

#define GetPartitionAccess_Head DLL_Export void GetPartitionAccess_pne_pne3d_generic_std_sf(ITI_PartitionFunctionAccess* _partitions)
#define GetPartitionAccess_Declare GetPartitionAccess_Head ;
#define GetPartitionAccess_Begin GetPartitionAccess_Head {
#define GetPartitionAccess_End }

#define DeclareFactoryPartitionAccessInit(pidx) {\
extern Factory_Partition_Access_Init_Head(pidx);\
Factory_Partition_Access_Init_Name(pidx)(&(_partitions[pidx]));}
#define DeclareFactoryPartitionAccessMain(pidx) {\
extern Factory_Partition_Access_Main_Head(pidx);\
Factory_Partition_Access_Main_Name(pidx)(&(_partitions[pidx]));}
#define DeclareFactoryPartitionAccessDecl(pidx) Factory_Partition_Access_Decl_Name(pidx)(&(_partitions[pidx]));

#define initial() initialFunction(&_pData->sInfo)
#define terminal() terminalFunction(&_pData->sInfo)
#define analysisTypeDetail() analysisTypeDetailFunction(&_pData->sInfo)
#define analysisType() analysisTypeFunction(&_pData->sInfo)
#define inAnimation() 0
#define terminate(string) terminateFunction(string, &_pData->sInfo)

#define GetIntMemory_M(size) GetIntMemory(&_data->currMem, size)
#define GetRealMemory_M(size) GetRealMemory(&_data->currMem, size)
#define GetStringPtrMemory_M(size) GetStringPtrMemory(&_data->currMem, size)
#define ArrayAdd_M(a1, a2) ArrayAdd(&_pData->sInfo, &_data->currMem, a1, a2)
#define ArraySub_M(a1, a2) ArraySub(&_pData->sInfo, &_data->currMem, a1, a2)
#define ArrayMulReal_M(a, v) ArrayMulReal(&_pData->sInfo, &_data->currMem, a, v)
#define ArrayMulInt_M(a, v) ArrayMulInt(&_pData->sInfo, &_data->currMem, a, v)
#define ArrayDivReal_M(a, v) ArrayDivReal(&_pData->sInfo, &_data->currMem, a, v)
#define ArrayDivInt_M(a, v) ArrayDivInt(&_pData->sInfo, &_data->currMem, a, v)
#define ArrayMulMM_M(a1, a2) ArrayMulMM(&_pData->sInfo, &_data->currMem, a1, a2)
#define ArrayMulMV_M(a1, a2) ArrayMulMV(&_pData->sInfo, &_data->currMem, a1, a2)
#define ArrayMulVM_M(a1, a2) ArrayMulVM(&_pData->sInfo, &_data->currMem, a1, a2)
#define AddString_M(s1, s2) AddString(&_data->currMem, s1, s2)
#define ArrayToString_M(arr) ArrayToString(&_pData->sInfo, &_data->currMem, arr)
#define RealToString_M(r, o1, o2, o3) RealToString(&_pData->sInfo, &_data->currMem, r, o1, o2, o3)
#define IntToString_M(i, o1, o2, o3) IntToString(&_pData->sInfo, &_data->currMem, i, o1, o2, o3)
#define BooleanToString_M(b, o1, o2) BooleanToString(&_pData->sInfo, &_data->currMem, b, o1, o2)
#define RealToStringFormat_M(r, f) RealToStringFormat(&_pData->sInfo, &_data->currMem, r, f)

#define GetIntMemory_F(size) GetIntMemory(&_data->funcMem, size)
#define GetRealMemory_F(size) GetRealMemory(&_data->funcMem, size)
#define GetStringPtrMemory_F(size) GetStringPtrMemory(&_data->funcMem, size)
#define ReleaseFuncMemory() ReleaseAllMemory(&_data->funcMem)

#define __STRING_ASSIGN(dest, src) AssignString(&_data->strMem, (const ITI_char**)&dest, src)
#define __STRING_ASSIGN2(dest, src, index) AssignString2(&_data->strMem, (const ITI_char**)&dest, src, (const ITI_char**)_pData->v.strData, _pData->v.strSize, index)
#define __Z_STRING_ASSIGN2(dest, src, index) AssignString2(&_data->strMem, (const ITI_char**)&dest, src, (const ITI_char**)_pData->z.strData, _pData->z.strSize, index)
#define __V_STRING_ASSIGN2(dest, src, index) AssignString2(&_data->strMem, (const ITI_char**)&dest, src, (const ITI_char**)_pData->v.strData, _pData->v.strSize, index)
#define __PRE_STRING_ASSIGN2(dest, src, index) AssignString2(&_data->strMem, (const ITI_char**)&dest, src, (const ITI_char**)_pData->pre_z.strData, _pData->pre_z.strSize, index)
#define __SAVE_LOCAL_STR_MEM SaveCurrentBuffer(&_data->strMem, STRING_TYPE);
#define __RESTORE_LOCAL_STR_MEM RestoreSavedBuffer(&_data->strMem, STRING_TYPE);
#define __STRING_INIT(dest, size) InitString(&_data->strMem, (const ITI_char**)&dest, size)
#define __STRING_INIT2(dest, size, index) InitString2(&_data->strMem, (const ITI_char**)&dest, size, _data->strLengths, index)
#define __STRING_CAT(dest, src) strcat(dest, src)

#define __ARRAY_NDIMS(arr) arr.nDims
#define __ARRAY_SIZE(arr, index) arr.dims[index-1]
#define __ARRAY_SIZE_V(arr) ArraySize(&_data->currMem, arr)
#define __ARRAY_VECTOR(arr) ArrayVector(&_data->currMem, arr)
#define __ARRAY_VECTOR_REAL(v) ArrayVectorReal(&_data->currMem, v)
#define __ARRAY_VECTOR_INT(v) ArrayVectorInt(&_data->currMem, v)
#define __ARRAY_MATRIX(arr) ArrayMatrix(&_pData->sInfo, &_data->currMem, arr)
#define __ARRAY_TRANSPOSE(arr) ArrayTranspose(&_pData->sInfo, &_data->currMem, arr)
#define __ARRAY_REF_TRANSPOSE(arr) ArrayRefTranspose(&_pData->sInfo, &_data->currMem, arr)
#define __ARRAY_OUTERPRODUCT(arr1, arr2) ArrayOuterProduct(&_pData->sInfo, &_data->currMem, arr1, arr2)
#define __ARRAY_CROSS(arr1, arr2) ArrayCross(&_pData->sInfo, &_data->currMem, arr1, arr2)
#define __ARRAY_SKEW(arr) ArraySkew(&_pData->sInfo, &_data->currMem, arr)
#define __ARRAY_SYMMETRIC(arr) ArraySymmetric(&_pData->sInfo, &_data->currMem, arr)
#define __ARRAY_LINSPACE(x1, x2, n) ArrayLinspace(&_pData->sInfo, &_data->currMem, x1, x2, n)
#define __ARRAY_MIN(arr) (arr.memType==REAL_TYPE?ArrayRealMin(arr):ArrayIntMin(arr))
#define __ARRAY_MAX(arr) (arr.memType==REAL_TYPE?ArrayRealMax(arr):ArrayIntMax(arr))
#define __ARRAY_SUM(arr) (arr.memType==REAL_TYPE?ArrayRealSum(arr):ArrayIntSum(arr))
#define __ARRAY_PRODUCT(arr) (arr.memType==REAL_TYPE?ArrayRealProduct(arr):ArrayIntProduct(arr))
#define __ARRAY_SCALAR(arr) (arr.memType==REAL_TYPE?ArrayRealScalar(&_pData->sInfo, arr):ArrayIntScalar(&_pData->sInfo, arr))
#define __ARRAY_DIAGONAL(arr) (arr.memType==REAL_TYPE?ArrayRealDiagonal(&_pData->sInfo, &_data->currMem, arr):ArrayIntDiagonal(&_pData->sInfo, &_data->currMem, arr))
#define __ARRAY_IDENTITY(n) ArrayIdentity(&_data->currMem, n)
#define __ARRAY_ASSIGN(a1, a2) ArrayAssign(&_data->currMem, &_pData->sInfo, a1, a2)
#define __ARRAY_STRING_ASSIGN(a1, a2) ArrayAssign(&_data->strMem, &_pData->sInfo, a1, a2)
#define __ARRAY_UNARY_MINUS(arr) ArrayUnaryMinus(&_data->currMem, arr)
#define __ARRAY_PROMOTE(arr, n) Promote(&_data->currMem, arr, n)
#define __ARRAY_PROMOTE_REAL(x, n) RealPromoteScalar(&_data->currMem, x, n)
#define __ARRAY_PROMOTE_INT(x, n) IntPromoteScalar(&_data->currMem, x, n)
#define __ARRAY_COMPARE(a1,rel_op,a2) ArrayCompare(&_pData->sInfo, a1, a2, rel_op)
#define __ARRAY_ARRAY_OP(a1, a2, op) ArrayArrayOp(&_pData->sInfo, &_data->currMem, a1, a2, op)
#define __ARRAY_SCALAR_OP_REAL(a, v, op, swap) ArrayScaleOpReal(&_pData->sInfo, &_data->currMem, op, a, v, swap)
#define __ARRAY_SCALAR_OP_REAL_SWAP(v, a, op) ArrayScaleOpReal(&_pData->sInfo, &_data->currMem, op, a, v, 0)
#define __ARRAY_SCALAR_OP_INT_SWAP(v, a, op) ArrayScaleOpInt(&_pData->sInfo, &_data->currMem, op, a, v, 0)
#define __SCALAR_ADD(v1, v2) (v1 + v2)
#define __ARRAY_SCALAR_OP_INT(a, v, op, swap) ArrayScaleOpInt(&_pData->sInfo, &_data->currMem, op, a, v, swap)
#define __ARRAY_CAST_TO_INT(a) CastArray(&_pData->sInfo, &_data->currMem, a, INT_TYPE)
#define __ARRAY_CAST_TO_REAL(a) CastArray(&_pData->sInfo, &_data->currMem, a, REAL_TYPE)
#define __ARRAY_CAST_TO_STR(a) CastArray(&_pData->sInfo, &_data->currMem, a, STRING_TYPE)
#define __ARRAY_APPLY_FUNC(func_ident, a) ApplyFuncOnArray(&_pData->sInfo, &_data->currMem, a, func_ident)
#define __ARRAY_SET_REAL(a, index, val) SetRealInArray(&_pData->sInfo, a, index, val)
#define __ARRAY_SET_INT(a, index, val) SetIntInArray(&_pData->sInfo, a, index, val)
#define __ARRAY_SET_STR(a, index, val) SetStrInArray(&_pData->sInfo, a, index, val)
#define __GET_STATE_INDEX(stateVar) GetRealIndex(_pData->x, _pData->size.ix, stateVar)

#define __triggerEvent() \
_pData->sInfo.bEventTriggered = 1;

#define __SOLVER_NEEDS_RESET \
_pData->sInfo.bSolverNeedsReset = 1;

#define __reinit(state, index, val) \
if(state!=val) { \
	_pData->iReinit[index] = 1;\
	_pData->xReinit[index] = val;\
	state = val;\
	__SOLVER_NEEDS_RESET\
} \

GetModelSolverSettings_Declare
GetModelSizes_Declare
InferenceGraph_Declare
GetPartitionData_Declare
GetPartitionAccess_Declare

AllocateRecords_Declare
FreeRecords_Declare

#define DECLARE_STATICS_DECL(pidx) \
Factory_Partition_Access_Decl_Begin(pidx) \
	Factory(SampleFunction) \
	Factory(InitBlockVars) \
	Factory(GetModelInfo) \
	_partition->GetPartitionSizes = GetModelSizes_pne_pne3d_generic_std_sf; \
Factory_Partition_Access_Decl_End

#define DECLARE_BPARTITION_STATICS_DECL(pidx) \
Factory_Partition_Access_Decl_Begin(pidx) \
Factory_Partition_Access_Decl_End

#define DECLARE_PARTITION_STATICS_DECL(pidx) \
Factory_Partition_Access_Decl_Begin(pidx) \
	Factory(GetPartitionSizes) \
	Factory(SampleFunction) \
	Factory(InitBlockVars) \
	Factory(GetModelInfo) \
Factory_Partition_Access_Decl_End

#define DECLARE_STATICS(pidx) \
Factory_Partition_Access_Main_Begin(pidx) \
	Factory(CalcDerivatives) \
	Factory(CalcOutputs) \
	Factory(SynchOutputs) \
	Factory(ValidStep) \
	Factory(AssignLastVar) \
	Factory(AssignDiscreteReal) \
	Factory(Terminate) \
	Factory(PreActivation) \
	Factory(PostActivation) \
Factory_Partition_Access_Main_End

#define DECLARE_BPARTITION_STATICS(pidx) \
Factory_Partition_Access_Main_Begin(pidx) \
	Factory(PreActivation) \
	Factory(PostActivation) \
Factory_Partition_Access_Main_End

#define DECLARE_PARTITION_STATICS(pidx) \
Factory_Partition_Access_Main_Begin(pidx) \
	Factory(CalcDerivatives) \
	Factory(CalcOutputs) \
	Factory(SynchOutputs) \
	Factory(ValidStep) \
	Factory(AssignLastVar) \
	Factory(AssignDiscreteReal) \
	Factory(PreActivation) \
	Factory(PostActivation) \
Factory_Partition_Access_Main_End

#define DECLARE_STATICS_INIT(pidx) \
Factory_Partition_Access_Init_Begin(pidx) \
	Factory(InitializeConstants) \
	Factory(InitializeParameterDependent) \
	Factory(InitializeTunableParameter) \
	Factory(Initialize) \
	Factory(InitializeConditions) \
Factory_Partition_Access_Init_End \
AllocateRecords_Head\
{if (_pData->size.iRec > 0)_pData->pRecord = (ITI_void*)calloc(1, sizeof(ITI_Records)); } \
GetModelSolverSettings_Head \
{\
pSS->tStart = ITI_tStart; \
pSS->tStop = ITI_tStop; \
pSS->dtMin = ITI_dtMin; \
pSS->dtMax = ITI_dtMax; \
pSS->dtDetect = ITI_dtDetect; \
pSS->absTol = ITI_absTol; \
pSS->relTol = ITI_relTol; \
pSS->dtProtMin = ITI_dtProtMin; \
pSS->mode = ITI_mode; \
pSS->ignoreMinMax = ITI_ignoreMinMax; \
pSS->minmax = ITI_minmax; \
if (pSS->minmax == 1)\
pSS->ignoreMinMax = 0; \
pSS->zeros = ITI_zeros; \
pSS->saveMode = ITI_SaveOutputs_Approach; \
pSS->trace = _Trace_On; \
pSS->limitdtMin = ITI_limitdtMin; \
pSS->effJac = ITI_effJac; \
pSS->parJac = ITI_parJac; \
pSS->maxOrder = ITI_maxOrder; \
pSS->gltol = ITI_blockTol; \
pSS->linSolv = ITI_blockLinSolv; \
pSS->threadLimit = -1; \
pSS->hysteresis = ITI_hysteresis; \
pSS->scaleEpsilon = ITI_scaleEpsilon; \
pSS->adaptEpsilon = ITI_adaptEpsilon; \
pSS->epsilon = ITI_epsilon; \
pSS->maxEpsilon = ITI_maxEpsilon; \
pSS->adaptThreshold = ITI_adaptThreshold; \
pSS->adaptFactor = ITI_adaptFactor; \
pSS->bAssertOn = _Modelica_Assert_On; \
pSS->bAssertTraceOn = _Modelica_Assert_Trace_On; \
pSS->stopAttStop = 1; \
pSS->eventHandlingMode = ITI_EventHandlingMode; \
}

#define DECLARE_BPARTITION_STATICS_INIT(pidx) \
Factory_Partition_Access_Init_Begin(pidx) \
Factory_Partition_Access_Init_End

#define DECLARE_PARTITION_STATICS_INIT(pidx) \
Factory_Partition_Access_Init_Begin(pidx) \
	Factory(InitializeTunableParameter) \
	Factory(Initialize) \
	Factory(InitializeConditions) \
Factory_Partition_Access_Init_End


#endif
