/**
 * ITI_SFuncHelper.h
 * SimulationX 4.0.5.60286 (08/29/19) x64
 * Copyright (c) ESI ITI GmbH
 * All rights reserved.
**/

#ifndef ITI_SFUNC_HELPER_H
#define ITI_SFUNC_HELPER_H

#include "simstruc.h"
#include "ITI_Types.h"

void PropagateArrayParam(const mxArray* mxArr, ITI_Array* paramArrays, ITI_Data_Array da, SimStruct* S, int_T nValues, int_T iArr);

#endif
