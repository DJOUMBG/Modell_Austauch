try
	path_model = pwd;
	name_model = 'pne_pne3d_generic_std.slx';
	name_block = 'pne_pne3d_generic_std_sf';
	name_sfun = 'pne_pne3d_generic_std_sf';

	Mask_Interface_SimX2DIVe;

	IntegrateSimXDLL(path_model, name_model, name_block, name_sfun, 0, 0, inputs_alt_SimX2DIVe, outputs_alt_SimX2DIVe, params_SimX2DIVe, solver_settings_SimX2DIVe);

	clear('inputs_SimX2DIVe', 'inputs_alt_SimX2DIVe', 'outputs_SimX2DIVe', 'outputs_alt_SimX2DIVe', 'params_SimX2DIVe', 'solver_settings_SimX2DIVe');
	clear('path_model', 'name_model', 'name_block', 'name_sfun');
catch
	errmsg = lasterr;
	disp(errmsg)
end
