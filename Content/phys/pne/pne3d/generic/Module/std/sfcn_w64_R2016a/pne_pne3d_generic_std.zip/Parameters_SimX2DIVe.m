sMP.phys.pne.susp1.dxMax = 0.;
sMP.phys.pne.susp1.dxMin = 0.;
sMP.phys.pne.susp1.dxRef = 40.;
sMP.phys.pne.susp1.vLift = 25.;
sMP.phys.pne.susp1.vLow = 25.;
sMP.phys.pne.susp2.dxMax = 0.;
sMP.phys.pne.susp2.dxMin = 0.;
sMP.phys.pne.susp2.dxRef = 40.;
sMP.phys.pne.susp2.vLift = 25.;
sMP.phys.pne.susp2.vLow = 25.;
sMP.phys.pne.susp3.dxMax = 0.;
sMP.phys.pne.susp3.dxMin = 0.;
sMP.phys.pne.susp3.dxRef = 40.;
sMP.phys.pne.susp3.vLift = 25.;
sMP.phys.pne.susp3.vLow = 25.;
sMP.phys.pne.susp4.dxMax = 0.;
sMP.phys.pne.susp4.dxMin = 0.;
sMP.phys.pne.susp4.dxRef = 40.;
sMP.phys.pne.susp4.vLift = 25.;
sMP.phys.pne.susp4.vLow = 25.;
sMP.phys.pne.brk1.brakeType = 0;
sMP.phys.pne.brk1.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brk1.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brk1.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brk1.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brk1.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brk1.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brk1.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brk1.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brk1.bt_rad_offset = 0.;
sMP.phys.pne.brk1.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brk1.considerTg = 0;
sMP.phys.pne.brk1.Cs = 0.;
sMP.phys.pne.brk1.eta = 0.;
sMP.phys.pne.brk1.fac_T_Dim = 17;
sMP.phys.pne.brk1.fac_v_Dim = 2;
sMP.phys.pne.brk1.Fdx_Dim = 2;
sMP.phys.pne.brk1.Gwear = 1.;
sMP.phys.pne.brk1.i_Dim = 2;
sMP.phys.pne.brk1.reff = 0.;
sMP.phys.pne.brk1.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brk1.useVarTempCalc = 0;
sMP.phys.pne.brk1.wearRate_T_Dim = 12;
sMP.phys.pne.brk2.brakeType = 0;
sMP.phys.pne.brk2.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brk2.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brk2.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brk2.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brk2.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brk2.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brk2.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brk2.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brk2.bt_rad_offset = 0.;
sMP.phys.pne.brk2.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brk2.considerTg = 0;
sMP.phys.pne.brk2.Cs = 0.;
sMP.phys.pne.brk2.eta = 0.;
sMP.phys.pne.brk2.fac_T_Dim = 17;
sMP.phys.pne.brk2.fac_v_Dim = 2;
sMP.phys.pne.brk2.Fdx_Dim = 2;
sMP.phys.pne.brk2.Gwear = 1.;
sMP.phys.pne.brk2.i_Dim = 2;
sMP.phys.pne.brk2.reff = 0.;
sMP.phys.pne.brk2.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brk2.useVarTempCalc = 0;
sMP.phys.pne.brk2.wearRate_T_Dim = 12;
sMP.phys.pne.brk3.brakeType = 0;
sMP.phys.pne.brk3.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brk3.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brk3.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brk3.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brk3.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brk3.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brk3.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brk3.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brk3.bt_rad_offset = 0.;
sMP.phys.pne.brk3.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brk3.considerTg = 0;
sMP.phys.pne.brk3.Cs = 0.;
sMP.phys.pne.brk3.eta = 0.;
sMP.phys.pne.brk3.fac_T_Dim = 17;
sMP.phys.pne.brk3.fac_v_Dim = 2;
sMP.phys.pne.brk3.Fdx_Dim = 2;
sMP.phys.pne.brk3.Gwear = 1.;
sMP.phys.pne.brk3.i_Dim = 2;
sMP.phys.pne.brk3.reff = 0.;
sMP.phys.pne.brk3.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brk3.useVarTempCalc = 0;
sMP.phys.pne.brk3.wearRate_T_Dim = 12;
sMP.phys.pne.brk4.brakeType = 0;
sMP.phys.pne.brk4.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brk4.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brk4.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brk4.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brk4.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brk4.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brk4.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brk4.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brk4.bt_rad_offset = 0.;
sMP.phys.pne.brk4.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brk4.considerTg = 0;
sMP.phys.pne.brk4.Cs = 0.;
sMP.phys.pne.brk4.eta = 0.;
sMP.phys.pne.brk4.fac_T_Dim = 17;
sMP.phys.pne.brk4.fac_v_Dim = 2;
sMP.phys.pne.brk4.Fdx_Dim = 2;
sMP.phys.pne.brk4.Gwear = 1.;
sMP.phys.pne.brk4.i_Dim = 2;
sMP.phys.pne.brk4.reff = 0.;
sMP.phys.pne.brk4.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brk4.useVarTempCalc = 0;
sMP.phys.pne.brk4.wearRate_T_Dim = 12;
sMP.phys.pne.cyl1.dxFSpring_Dim = 2;
sMP.phys.pne.cyl1.dxVolPB_Dim = 2;
sMP.phys.pne.cyl1.dxVolSB_Dim = 2;
sMP.phys.pne.cyl1.FNom = 0.;
sMP.phys.pne.cyl1.maxStroke = 0.;
sMP.phys.pne.cyl1.pApp = 0.;
sMP.phys.pne.cyl1.pNom = 0.;
sMP.phys.pne.cyl1.pR_PB = 0.;
sMP.phys.pne.cyl1.xR_PB = 0.;
sMP.phys.pne.cyl2.dxFSpring_Dim = 2;
sMP.phys.pne.cyl2.dxVolPB_Dim = 2;
sMP.phys.pne.cyl2.dxVolSB_Dim = 2;
sMP.phys.pne.cyl2.FNom = 0.;
sMP.phys.pne.cyl2.maxStroke = 0.;
sMP.phys.pne.cyl2.pApp = 0.;
sMP.phys.pne.cyl2.pNom = 0.;
sMP.phys.pne.cyl2.pR_PB = 0.;
sMP.phys.pne.cyl2.xR_PB = 0.;
sMP.phys.pne.cyl3.dxFSpring_Dim = 2;
sMP.phys.pne.cyl3.dxVolPB_Dim = 2;
sMP.phys.pne.cyl3.dxVolSB_Dim = 2;
sMP.phys.pne.cyl3.FNom = 0.;
sMP.phys.pne.cyl3.maxStroke = 0.;
sMP.phys.pne.cyl3.pApp = 0.;
sMP.phys.pne.cyl3.pNom = 0.;
sMP.phys.pne.cyl3.pR_PB = 0.;
sMP.phys.pne.cyl3.xR_PB = 0.;
sMP.phys.pne.cyl4.dxFSpring_Dim = 2;
sMP.phys.pne.cyl4.dxVolPB_Dim = 2;
sMP.phys.pne.cyl4.dxVolSB_Dim = 2;
sMP.phys.pne.cyl4.FNom = 0.;
sMP.phys.pne.cyl4.maxStroke = 0.;
sMP.phys.pne.cyl4.pApp = 0.;
sMP.phys.pne.cyl4.pNom = 0.;
sMP.phys.pne.cyl4.pR_PB = 0.;
sMP.phys.pne.cyl4.xR_PB = 0.;
sMP.phys.pne.cylTrailer1.dxFSpring_Dim = 2;
sMP.phys.pne.cylTrailer1.dxVolPB_Dim = 2;
sMP.phys.pne.cylTrailer1.dxVolSB_Dim = 2;
sMP.phys.pne.cylTrailer1.FNom = 0.;
sMP.phys.pne.cylTrailer1.maxStroke = 0.;
sMP.phys.pne.cylTrailer1.pApp = 0.;
sMP.phys.pne.cylTrailer1.pNom = 0.;
sMP.phys.pne.cylTrailer1.pR_PB = 0.;
sMP.phys.pne.cylTrailer1.xR_PB = 0.;
sMP.phys.pne.cylTrailer2.dxFSpring_Dim = 2;
sMP.phys.pne.cylTrailer2.dxVolPB_Dim = 2;
sMP.phys.pne.cylTrailer2.dxVolSB_Dim = 2;
sMP.phys.pne.cylTrailer2.FNom = 0.;
sMP.phys.pne.cylTrailer2.maxStroke = 0.;
sMP.phys.pne.cylTrailer2.pApp = 0.;
sMP.phys.pne.cylTrailer2.pNom = 0.;
sMP.phys.pne.cylTrailer2.pR_PB = 0.;
sMP.phys.pne.cylTrailer2.xR_PB = 0.;
sMP.phys.pne.cylTrailer3.dxFSpring_Dim = 2;
sMP.phys.pne.cylTrailer3.dxVolPB_Dim = 2;
sMP.phys.pne.cylTrailer3.dxVolSB_Dim = 2;
sMP.phys.pne.cylTrailer3.FNom = 0.;
sMP.phys.pne.cylTrailer3.maxStroke = 0.;
sMP.phys.pne.cylTrailer3.pApp = 0.;
sMP.phys.pne.cylTrailer3.pNom = 0.;
sMP.phys.pne.cylTrailer3.pR_PB = 0.;
sMP.phys.pne.cylTrailer3.xR_PB = 0.;
sMP.phys.pne.brkTrailer1.brakeType = 0;
sMP.phys.pne.brkTrailer1.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brkTrailer1.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brkTrailer1.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brkTrailer1.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brkTrailer1.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brkTrailer1.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brkTrailer1.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brkTrailer1.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brkTrailer1.bt_rad_offset = 0.;
sMP.phys.pne.brkTrailer1.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brkTrailer1.considerTg = 0;
sMP.phys.pne.brkTrailer1.Cs = 0.;
sMP.phys.pne.brkTrailer1.eta = 0.;
sMP.phys.pne.brkTrailer1.fac_T_Dim = 17;
sMP.phys.pne.brkTrailer1.fac_v_Dim = 2;
sMP.phys.pne.brkTrailer1.Fdx_Dim = 2;
sMP.phys.pne.brkTrailer1.Gwear = 1.;
sMP.phys.pne.brkTrailer1.i_Dim = 2;
sMP.phys.pne.brkTrailer1.reff = 0.;
sMP.phys.pne.brkTrailer1.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brkTrailer1.useVarTempCalc = 0;
sMP.phys.pne.brkTrailer1.wearRate_T_Dim = 12;
sMP.phys.pne.brkTrailer2.brakeType = 0;
sMP.phys.pne.brkTrailer2.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brkTrailer2.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brkTrailer2.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brkTrailer2.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brkTrailer2.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brkTrailer2.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brkTrailer2.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brkTrailer2.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brkTrailer2.bt_rad_offset = 0.;
sMP.phys.pne.brkTrailer2.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brkTrailer2.considerTg = 0;
sMP.phys.pne.brkTrailer2.Cs = 0.;
sMP.phys.pne.brkTrailer2.eta = 0.;
sMP.phys.pne.brkTrailer2.fac_T_Dim = 17;
sMP.phys.pne.brkTrailer2.fac_v_Dim = 2;
sMP.phys.pne.brkTrailer2.Fdx_Dim = 2;
sMP.phys.pne.brkTrailer2.Gwear = 1.;
sMP.phys.pne.brkTrailer2.i_Dim = 2;
sMP.phys.pne.brkTrailer2.reff = 0.;
sMP.phys.pne.brkTrailer2.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brkTrailer2.useVarTempCalc = 0;
sMP.phys.pne.brkTrailer2.wearRate_T_Dim = 12;
sMP.phys.pne.brkTrailer3.brakeType = 0;
sMP.phys.pne.brkTrailer3.bt_A_norm = 0.19719999999999999;
sMP.phys.pne.brkTrailer3.bt_A_pad = 0.032199999999999999;
sMP.phys.pne.brkTrailer3.bt_alpha_conv_fac_cool = 0.;
sMP.phys.pne.brkTrailer3.bt_alpha_conv_fac_fric = 0.47999999999999998;
sMP.phys.pne.brkTrailer3.bt_base_conduction_corr = 0.27582000000000001;
sMP.phys.pne.brkTrailer3.bt_delta_r = 0.0082500000000000004;
sMP.phys.pne.brkTrailer3.bt_density_correction = 1.1200000000000001;
sMP.phys.pne.brkTrailer3.bt_epsilon_corr = 1.3846153846153846;
sMP.phys.pne.brkTrailer3.bt_rad_offset = 0.;
sMP.phys.pne.brkTrailer3.bt_radiation_area_corr = 2.46;
sMP.phys.pne.brkTrailer3.considerTg = 0;
sMP.phys.pne.brkTrailer3.Cs = 0.;
sMP.phys.pne.brkTrailer3.eta = 0.;
sMP.phys.pne.brkTrailer3.fac_T_Dim = 17;
sMP.phys.pne.brkTrailer3.fac_v_Dim = 2;
sMP.phys.pne.brkTrailer3.Fdx_Dim = 2;
sMP.phys.pne.brkTrailer3.Gwear = 1.;
sMP.phys.pne.brkTrailer3.i_Dim = 2;
sMP.phys.pne.brkTrailer3.reff = 0.;
sMP.phys.pne.brkTrailer3.sPad_sum0 = 0.040000000000000001;
sMP.phys.pne.brkTrailer3.useVarTempCalc = 0;
sMP.phys.pne.brkTrailer3.wearRate_T_Dim = 12;
sMP.phys.pne.circ.T_pipe_AM_ABSValve_FL = 0.01;
sMP.phys.pne.circ.T_pipe_AM_ABSValve_FR = 0.01;
sMP.phys.pne.circ.T_pipe_AM_BC_AL = 0.01;
sMP.phys.pne.circ.T_pipe_AM_BC_AR = 0.01;
sMP.phys.pne.circ.T_pipe_AM_BC_RL = 0.01;
sMP.phys.pne.circ.T_pipe_AM_BC_RR = 0.01;
sMP.phys.pne.circTrlr.flagTrailerABS = 0;
sMP.phys.pne.circTrlr.T_pipe_Trailer_RV_Front = 0.040000000000000001;
sMP.phys.pne.circTrlr.T_pipe_Trailer_RV_Front_Rear = 0.040000000000000001;
sMP.phys.pne.circTrlr.VTrailer = 60.;
sMP.phys.pne.com.pACoverflow = 0.;
sMP.phys.pne.auxil.Drs_dVClose = 0.;
sMP.phys.pne.auxil.Drs_dVOpen = 0.;
sMP.phys.pne.auxil.Drs_pMeas = 0.;
sMP.phys.pne.auxil.Drs_tClose = 0.;
sMP.phys.pne.auxil.Drs_tOpen = 0.;
sMP.phys.pne.in.ebs_AdditionalAxle_left_pDmd = 0.;
sMP.phys.pne.in.ebs_AdditionalAxle_left_setABS = 0.;
sMP.phys.pne.in.ebs_AdditionalAxle_right_pDmd = 0.;
sMP.phys.pne.in.ebs_AdditionalAxle_right_setABS = 0.;
sMP.phys.pne.in.ebs_ESCsens_y_acceleration = 0.;
sMP.phys.pne.in.ebs_FrontAxle_left_pDmd = 0.;
sMP.phys.pne.in.ebs_FrontAxle_left_setABS = 0.;
sMP.phys.pne.in.ebs_FrontAxle_right_pDmd = 0.;
sMP.phys.pne.in.ebs_FrontAxle_right_setABS = 0.;
sMP.phys.pne.in.ebs_RearAxle_left_pDmd = 0.;
sMP.phys.pne.in.ebs_RearAxle_left_setABS = 0.;
sMP.phys.pne.in.ebs_RearAxle_right_pDmd = 0.;
sMP.phys.pne.in.ebs_RearAxle_right_setABS = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Addl_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Addl_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Front_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Front_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_RCMax_Front = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_RCMax_Rear = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSInValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Addl_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Addl_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Front_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Front_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_RCMax_Front = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_RCMax_Rear = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stABSOutValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stAPCVBuValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stAPCVInValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stAPCVOutValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stAtcCutOffValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stAxmoBuValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stAxmoInValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stAxmoInValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stAxmoOutValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stAxmoOutValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stCMaxBuValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stCMaxInValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stCMaxInValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stCMaxOutValve_Rear_Left = 0.;
sMP.phys.pne.in.ebs_sBSP_stCMaxOutValve_Rear_Right = 0.;
sMP.phys.pne.in.ebs_sBSP_stRCMaxInValve_Front = 0.;
sMP.phys.pne.in.ebs_sBSP_stRCMaxInValve_Rear = 0.;
sMP.phys.pne.in.ebs_sBSP_stRCMaxOutValve_Front = 0.;
sMP.phys.pne.in.ebs_sBSP_stRCMaxOutValve_Rear = 0.;
sMP.phys.pne.in.ebs_sBSP_stTCVBuValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stTCVInValve = 0.;
sMP.phys.pne.in.ebs_sBSP_stTCVOutValve = 0.;
sMP.phys.pne.in.ebs_sil_AAle_force = 999999.;
sMP.phys.pne.in.ebs_sil_AAle_vel = 999999.;
sMP.phys.pne.in.ebs_sil_AAri_force = 999999.;
sMP.phys.pne.in.ebs_sil_AAri_vel = 999999.;
sMP.phys.pne.in.ebs_sil_FAle_force = 999999.;
sMP.phys.pne.in.ebs_sil_FAle_vel = 999999.;
sMP.phys.pne.in.ebs_sil_FAri_force = 999999.;
sMP.phys.pne.in.ebs_sil_FAri_vel = 999999.;
sMP.phys.pne.in.ebs_sil_RAle_force = 999999.;
sMP.phys.pne.in.ebs_sil_RAle_vel = 999999.;
sMP.phys.pne.in.ebs_sil_RAri_force = 999999.;
sMP.phys.pne.in.ebs_sil_RAri_vel = 999999.;
sMP.phys.pne.in.ebs_st3by2_First = 0.;
sMP.phys.pne.in.ebs_st3by2_Second = 0.;
sMP.phys.pne.in.ebs_TCV_pDmd = 0.;
sMP.phys.pne.in.env_air_frontVel = 0.;
sMP.phys.pne.in.env_pressure = 1013.;
sMP.phys.pne.in.env_Temperature = 20.;
sMP.phys.pne.in.Failure_electric_circuit_AA = 0.;
sMP.phys.pne.in.Failure_electric_circuit_FA = 0.;
sMP.phys.pne.in.Failure_electric_circuit_RA = 0.;
sMP.phys.pne.in.Failure_pneumatic_circuit_FA = 0.;
sMP.phys.pne.in.Failure_pneumatic_circuit_RA = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_AirSuspension = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_auxiliaries = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_doors = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_EnduranceBrakes = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_engine = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_gearbox = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_leakage = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_PowerBoost = 0.;
sMP.phys.pne.out.pne_AirConsumptionFlow_SCR = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_AL = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_AR = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_FA = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_FOPB = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_Front = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_Rear = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_RL = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_RR = 0.;
sMP.phys.pne.out.pne_brk_Actual_Pressure_TCV = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_AxMo_left_rotVel = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_AxMo_right_rotVel = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_left_pAct = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_left_rotVel = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_right_pAct = 0.;
sMP.phys.pne.out.pne_brk_AdditionalAxle_right_rotVel = 0.;
sMP.phys.pne.in.pne_brk_AirCompressor_angAcc = 0.;
sMP.phys.pne.in.pne_brk_AirCompressor_angPos = 0.;
sMP.phys.pne.in.pne_brk_AirCompressor_angVel = 73.930000000000007;
sMP.phys.pne.out.pne_brk_AirCompressor_delivery = 0.;
sMP.phys.pne.out.pne_brk_AirCompressor_torque = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpEng_massfracH2O = 0.;
sMP.phys.pne.in.pne_brk_AirConsumpEng_mdot = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpEng_pressure = 8500.;
sMP.phys.pne.out.pne_brk_AirConsumpEng_Temperature = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpRet_massfracH2O = 0.;
sMP.phys.pne.in.pne_brk_AirConsumpRet_mdot = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpRet_pressure = 8500.;
sMP.phys.pne.out.pne_brk_AirConsumpRet_Temperature = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpTx_massfracH2O = 0.;
sMP.phys.pne.in.pne_brk_AirConsumpTx_mdot = 0.;
sMP.phys.pne.out.pne_brk_AirConsumpTx_pressure = 8500.;
sMP.phys.pne.out.pne_brk_AirConsumpTx_Temperature = 0.;
sMP.phys.pne.out.pne_brk_Axle1_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_Axle1_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_Axle1_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle1_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle1_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle1_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle1_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle1_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle1_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle1_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle1_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle1_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_Axle1_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle1_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle1_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle1_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle1_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle1_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle1_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle1_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle1_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle1_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_Axle1_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_Axle1Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_Axle1Brake_left_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle1Brake_right_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle1Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_Axle1Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_Axle2_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_Axle2_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_Axle2_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle2_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle2_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle2_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle2_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle2_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle2_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle2_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle2_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle2_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_Axle2_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle2_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle2_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle2_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle2_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle2_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle2_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle2_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle2_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle2_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_Axle2_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_Axle2Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_Axle2Brake_left_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle2Brake_right_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle2Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_Axle2Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_Axle3_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_Axle3_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_Axle3_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle3_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle3_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle3_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle3_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle3_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle3_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle3_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle3_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle3_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_Axle3_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle3_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle3_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle3_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle3_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle3_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle3_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle3_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle3_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle3_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_Axle3_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_Axle3Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_Axle3Brake_left_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle3Brake_right_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle3Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_Axle3Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_Axle4_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_Axle4_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_Axle4_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle4_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle4_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle4_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle4_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle4_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle4_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle4_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle4_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle4_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_Axle4_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_Axle4_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_Axle4_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_Axle4_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_Axle4_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_Axle4_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_Axle4_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_Axle4_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_Axle4_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_Axle4_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_Axle4_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_Axle4Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_Axle4Brake_left_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle4Brake_right_pRel = 5.;
sMP.phys.pne.out.pne_brk_Axle4Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_Axle4Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_BrkWearAALt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearAARt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearFA1Lt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearFA1Rt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearFA2Lt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearFA2Rt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearRA1Lt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearRA1Rt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearRA2Lt = 102.;
sMP.phys.pne.out.pne_brk_BrkWearRA2Rt = 102.;
sMP.phys.pne.out.pne_brk_CompON = 0.;
sMP.phys.pne.out.pne_brk_CompOut_Temp = 0.;
sMP.phys.pne.in.pne_brk_CompressorInlet_massfracH2O = 0.;
sMP.phys.pne.out.pne_brk_CompressorInlet_mdot = 0.;
sMP.phys.pne.in.pne_brk_CompressorInlet_pressure = 1000.;
sMP.phys.pne.in.pne_brk_CompressorInlet_Temperature = 20.;
sMP.phys.pne.out.pne_brk_CoolingPipe_pRel = 0.;
sMP.phys.pne.out.pne_brk_CoolingPipe_Temp = 0.;
sMP.phys.pne.out.pne_brk_EAPU_pRel = 0.;
sMP.phys.pne.out.pne_brk_EAPU_Temp = 0.;
sMP.phys.pne.out.pne_brk_FrontAxle_left_rotVel = 0.;
sMP.phys.pne.out.pne_brk_FrontAxle_pAct = 0.;
sMP.phys.pne.out.pne_brk_FrontAxle_right_rotVel = 0.;
sMP.phys.pne.out.pne_brk_PowerBoost_massfracH2O = 0.;
sMP.phys.pne.in.pne_brk_PowerBoost_mdot = 0.;
sMP.phys.pne.out.pne_brk_PowerBoost_pressure = 1000.;
sMP.phys.pne.out.pne_brk_PowerBoost_Temperature = 20.;
sMP.phys.pne.out.pne_brk_pRelPkBrk = 8.5;
sMP.phys.pne.out.pne_brk_RearAxle_left_pAct = 0.;
sMP.phys.pne.out.pne_brk_RearAxle_left_rotVel = 0.;
sMP.phys.pne.out.pne_brk_RearAxle_right_pAct = 0.;
sMP.phys.pne.out.pne_brk_RearAxle_right_rotVel = 0.;
sMP.phys.pne.out.pne_brk_reg_active = 0.;
sMP.phys.pne.out.pne_brk_rotVel_al = 0.;
sMP.phys.pne.out.pne_brk_rotVel_ar = 0.;
sMP.phys.pne.out.pne_brk_rotVel_fl = 0.;
sMP.phys.pne.out.pne_brk_rotVel_fr = 0.;
sMP.phys.pne.out.pne_brk_rotVel_rl = 0.;
sMP.phys.pne.out.pne_brk_rotVel_rr = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t1l = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t1r = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t2l = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t2r = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t3l = 0.;
sMP.phys.pne.out.pne_brk_rotVel_t3r = 0.;
sMP.phys.pne.out.pne_brk_TCV_pAct = 0.;
sMP.phys.pne.out.pne_brk_Trailer_RV_Front_pAct = 0.;
sMP.phys.pne.out.pne_brk_Trailer_RV_Rear_pAct = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle1_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle1_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle1Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1Brake_left_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle1Brake_right_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle1Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle1Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle2_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle2_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle2Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2Brake_left_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle2Brake_right_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle2Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle2Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_BrakingForce_at8p5bar = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_BrakingPower = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_left_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_left_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_left_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_left_torque_grinding = 15000.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_right_angAcc = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_right_angPos = 0.;
sMP.phys.pne.in.pne_brk_TrailerAxle3_right_angVel = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_kvT = 1.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_sPad_sum = 102.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_Tcooldown = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_Tfriction = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_Tinterior = 25.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_torque = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_right_torque_grinding = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle3_torque_sns = 15000.;
sMP.phys.pne.out.pne_brk_TrailerAxle3Brake_Fcyl = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3Brake_left_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle3Brake_right_pRel = 4.;
sMP.phys.pne.out.pne_brk_TrailerAxle3Brake_stroke = 0.;
sMP.phys.pne.out.pne_brk_TrailerAxle3Brake_Vol = 0.;
sMP.phys.pne.out.pne_brk_V1_pRel = 12.5;
sMP.phys.pne.out.pne_brk_V1_Temp = 20.;
sMP.phys.pne.out.pne_brk_V2_pRel = 12.5;
sMP.phys.pne.out.pne_brk_V2_Temp = 20.;
sMP.phys.pne.out.pne_brk_V3_pRel = 8.5;
sMP.phys.pne.out.pne_brk_V3_Temp = 20.;
sMP.phys.pne.out.pne_brk_V4_pRel = 8.5;
sMP.phys.pne.out.pne_brk_V4_Temp = 20.;
sMP.phys.pne.out.pne_brk_V5_pRel = 8.5;
sMP.phys.pne.out.pne_brk_V5_Temp = 20.;
sMP.phys.pne.out.pne_brk_V6_pRel = 8.5;
sMP.phys.pne.out.pne_brk_V6_Temp = 20.;
sMP.phys.pne.out.pne_brk_V7_pRel = 12.5;
sMP.phys.pne.out.pne_brk_V7_Temp = 20.;
sMP.phys.pne.out.pne_brk_V8_pRel = 12.5;
sMP.phys.pne.out.pne_brk_V8_Temp = 20.;
sMP.phys.pne.out.pne_brk_Vsup_pRel = 12.5;
sMP.phys.pne.out.pne_brk_Vsup_Temp = 20.;
sMP.phys.pne.out.pne_brk_VTrailer_pRel = 8.5;
sMP.phys.pne.out.pne_brk_VTrailer_Temp = 20.;
sMP.phys.pne.out.pne_brk_WetLvl_Cntr = 0.;
sMP.phys.pne.out.pne_susp_A1_Le_Posn = 0.;
sMP.phys.pne.out.pne_susp_A1_Ri_Posn = 0.;
sMP.phys.pne.out.pne_susp_A2_Le_Posn = 0.;
sMP.phys.pne.out.pne_susp_A2_Ri_Posn = 0.;
sMP.phys.pne.out.pne_susp_A3_Le_Posn = 0.;
sMP.phys.pne.out.pne_susp_A3_Ri_Posn = 0.;
sMP.phys.pne.in.pneAux_A1_Le_Rq = 0.;
sMP.phys.pne.in.pneAux_A1_LoLi_Rq = 0.;
sMP.phys.pne.in.pneAux_A1_Ri_Rq = 0.;
sMP.phys.pne.in.pneAux_A2_Le_Rq = 0.;
sMP.phys.pne.in.pneAux_A2_LoLi_Rq = 0.;
sMP.phys.pne.in.pneAux_A2_Ri_Rq = 0.;
sMP.phys.pne.in.pneAux_A3_Le_Rq = 0.;
sMP.phys.pne.in.pneAux_A3_LoLi_Rq = 0.;
sMP.phys.pne.in.pneAux_A3_Ri_Rq = 0.;
sMP.phys.pne.in.pneAux_Axle1_load = 0.;
sMP.phys.pne.in.pneAux_Axle2_load = 0.;
sMP.phys.pne.in.pneAux_Axle3_load = 0.;
sMP.phys.pne.in.pneAux_Axle4_load = 0.;
sMP.phys.pne.in.pneAux_Drs_Rq = 0.;
sMP.phys.pne.in.pneAux_EAPU_overrun = 0.;
sMP.phys.pne.in.pneAux_pSoll_TCV_p43 = 8.5;
sMP.phys.pne.in.pneAux_pSollPkBrk = 8.5;
sMP.phys.pne.in.pneAux_TCV_pDmd_Front_Left = 0.;
sMP.phys.pne.in.pneAux_TCV_pDmd_Front_Right = 0.;
sMP.phys.pne.in.pneAux_TCV_pDmd_Rear_Left = 0.;
sMP.phys.pne.in.pneAux_TCV_pDmd_Rear_Right = 0.;
sMP.phys.pne.in.pneAux_trailerAxle1_left_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle1_left_stABSOutValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle1_load = 0.;
sMP.phys.pne.in.pneAux_trailerAxle1_right_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle1_right_stABSOutValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle2_left_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle2_left_stABSOutValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle2_load = 0.;
sMP.phys.pne.in.pneAux_trailerAxle2_right_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle2_right_stABSOutValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle3_left_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle3_left_stABSOutValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle3_load = 0.;
sMP.phys.pne.in.pneAux_trailerAxle3_right_stABSInValve = 0.;
sMP.phys.pne.in.pneAux_trailerAxle3_right_stABSOutValve = 0.;
sMP.phys.pne.auxil.QnLeak = 0.;
sMP.phys.pne.veh.stepSize = 0.01;
sMP.phys.pne.veh.T1_APCV = 0.014999999999999999;
sMP.phys.pne.veh.T1_CMAX = 0.014999999999999999;
sMP.phys.pne.pro.dT_CompInlet = 0.;
sMP.phys.pne.pro.flagUS = 0.;
sMP.phys.pne.pro.pRelCI = 0.;
sMP.phys.pne.pro.pRelCI_RO = 0.;
sMP.phys.pne.pro.pRelCO = 0.;
sMP.phys.pne.pro.pRelCO_RO = 0.;
sMP.phys.pne.pro.pRelLimit_C1C2 = 8.5;
sMP.phys.pne.pro.pRelLimit_C3C4 = 8.5;
sMP.phys.pne.pro.RegenPct = 12.;
sMP.phys.pne.pro.V1 = 0.;
sMP.phys.pne.pro.V2 = 0.;
sMP.phys.pne.pro.V3 = 0.;
sMP.phys.pne.pro.V4 = 0.;
sMP.phys.pne.pro.V5 = 0.;
sMP.phys.pne.pro.V6 = 0.;
sMP.phys.pne.pro.V7 = 0.;
sMP.phys.pne.pro.V8 = 0.;
sMP.phys.pne.pro.Vcartridge = 2.;
sMP.phys.pne.pro.Vintake = 1.;
sMP.phys.pne.pro.Vreg = 0.;
sMP.phys.pne.pro.Vsup = 0.;
sMP.phys.pne.auxil.QnSCR = 0.;
sMP.phys.pne.initialTemperatures.TemperatureCalculation = 0;

sMP.phys.pne.susp1.dV_mAxle_Ref = [4803.,5.7000000000000002;
5505.,6.0300000000000002;
6207.,6.5099999999999998];

sMP.phys.pne.susp2.dV_mAxle_Ref = [4803.,5.7000000000000002;
5505.,6.0300000000000002;
6207.,6.5099999999999998];

sMP.phys.pne.susp3.dV_mAxle_Ref = [4803.,5.7000000000000002;
5505.,6.0300000000000002;
6207.,6.5099999999999998];

sMP.phys.pne.susp4.dV_mAxle_Ref = [4803.,5.7000000000000002;
5505.,6.0300000000000002;
6207.,6.5099999999999998];

sMP.phys.pne.brk1.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brk1.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brk1.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brk1.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brk1.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brk1.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brk1.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brk1.i_yAxis = [0.,0.];

sMP.phys.pne.brk1.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brk1.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.brk2.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brk2.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brk2.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brk2.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brk2.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brk2.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brk2.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brk2.i_yAxis = [0.,0.];

sMP.phys.pne.brk2.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brk2.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.brk3.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brk3.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brk3.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brk3.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brk3.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brk3.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brk3.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brk3.i_yAxis = [0.,0.];

sMP.phys.pne.brk3.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brk3.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.brk4.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brk4.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brk4.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brk4.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brk4.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brk4.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brk4.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brk4.i_yAxis = [0.,0.];

sMP.phys.pne.brk4.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brk4.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.cyl1.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cyl1.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cyl1.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cyl1.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cyl1.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cyl1.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cyl2.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cyl2.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cyl2.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cyl2.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cyl2.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cyl2.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cyl3.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cyl3.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cyl3.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cyl3.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cyl3.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cyl3.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cyl4.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cyl4.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cyl4.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cyl4.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cyl4.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cyl4.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer1.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer1.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cylTrailer1.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer1.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer1.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer1.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer2.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer2.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cylTrailer2.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer2.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer2.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer2.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer3.dxFSpring_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer3.dxFSpring_yAxis = [1.,0.];

sMP.phys.pne.cylTrailer3.dxVolPB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer3.dxVolPB_yAxis = [0.,0.];

sMP.phys.pne.cylTrailer3.dxVolSB_xAxis = [0.,1.];

sMP.phys.pne.cylTrailer3.dxVolSB_yAxis = [0.,0.];

sMP.phys.pne.brkTrailer1.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brkTrailer1.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brkTrailer1.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brkTrailer1.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brkTrailer1.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brkTrailer1.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brkTrailer1.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brkTrailer1.i_yAxis = [0.,0.];

sMP.phys.pne.brkTrailer1.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brkTrailer1.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.brkTrailer2.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brkTrailer2.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brkTrailer2.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brkTrailer2.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brkTrailer2.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brkTrailer2.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brkTrailer2.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brkTrailer2.i_yAxis = [0.,0.];

sMP.phys.pne.brkTrailer2.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brkTrailer2.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.brkTrailer3.fac_T_xAxis = [0.,50.,100.,150.,200.,250.,300.,350.,400.,450.,500.,550.,600.,650.,700.,750.,800.];

sMP.phys.pne.brkTrailer3.fac_T_yAxis = [0.95999999999999996,0.982325,0.99829999999999997,1.007925,1.0112000000000001,1.0081249999999999,0.99870000000000003,0.98292500000000005,0.96079999999999999,0.910775,0.86350000000000005,0.81877500000000003,0.77659999999999996,0.73697500000000005,0.69989999999999997,0.66537500000000005,0.63339999999999996];

sMP.phys.pne.brkTrailer3.fac_v_xAxis = [0.,27.777999999999999];

sMP.phys.pne.brkTrailer3.fac_v_yAxis = [1.1040000000000001,0.81499999999999995];

sMP.phys.pne.brkTrailer3.Fdx_xAxis = [0.,1.];

sMP.phys.pne.brkTrailer3.Fdx_yAxis = [0.,0.001];

sMP.phys.pne.brkTrailer3.i_xAxis = [0.,0.059999999999999998];

sMP.phys.pne.brkTrailer3.i_yAxis = [0.,0.];

sMP.phys.pne.brkTrailer3.wearRate_T_xAxis = [20.,100.,200.,250.,300.,350.,400.,500.,600.,700.,900.,1000.];

sMP.phys.pne.brkTrailer3.wearRate_T_yAxis = [0.10000000000000001,0.10000000000000001,0.10000000000000001,0.12,0.185,0.28999999999999998,0.44,0.84999999999999998,1.4299999999999999,2.2599999999999998,3.6200000000000001,3.6200000000000001];

sMP.phys.pne.circ.brkCircuit = [1,2,0,0];

sMP.phys.pne.circ.speedSensorPosnVeh = [1,1,0,0];

sMP.phys.pne.circ.t_asymp75 = [0.40000000000000002,0.40000000000000002,0.40000000000000002,0.40000000000000002];

sMP.phys.pne.circ.t_release10 = [0.40000000000000002,0.40000000000000002,0.40000000000000002,0.40000000000000002];

sMP.phys.pne.circTrlr.brkCircuitTrailer = [0,0,0];

sMP.phys.pne.circTrlr.flagTrailerControlActive = [2.,1.,2.,3.,4.,5.,0.,0.,0.,0.,0.];

sMP.phys.pne.circTrlr.speedSensorPosnTrailer = [0,0,0];

sMP.phys.pne.circTrlr.t_asymp75_Trlr = [0.25,0.25,0.25];

sMP.phys.pne.circTrlr.t_release10_Trlr = [0.40999999999999998,0.40999999999999998,0.40999999999999998];

sMP.phys.pne.com.dim_PmechMap = [5,14];

sMP.phys.pne.com.dim_QnMap = [7,14];

sMP.phys.pne.com.dim_ToutMap = [5,14];

sMP.phys.pne.com.Pmech_Map_kW = [0.,0.10000000000000001,0.20000000000000001,0.29999999999999999,0.40000000000000002,0.5,0.69999999999999996,0.90000000000000002,1.1000000000000001,1.5,2.2000000000000002,2.6000000000000001,3.,3.2000000000000002;
0.,1.3,1.6000000000000001,2.,2.6000000000000001,3.2000000000000002,3.8999999999999999,4.5999999999999996,5.2000000000000002,6.0999999999999996,7.2000000000000002,8.1999999999999993,8.9000000000000004,9.1999999999999993;
0.,1.3999999999999999,1.7,2.1000000000000001,2.7999999999999998,3.3999999999999999,4.0999999999999996,4.9000000000000004,5.5,6.5,7.7000000000000002,8.6999999999999993,9.4000000000000004,9.6999999999999993;
0.,1.5,1.8,2.2999999999999998,3.,3.7000000000000002,4.4000000000000004,5.2000000000000002,5.9000000000000004,6.7999999999999998,8.1999999999999993,9.1999999999999993,9.9000000000000004,10.199999999999999;
0.,1.5900000000000001,1.97,2.3999999999999999,3.1299999999999999,3.8700000000000001,4.6500000000000004,5.4400000000000004,6.2000000000000002,7.1600000000000001,8.5600000000000005,9.5700000000000003,10.35,10.710000000000001];

sMP.phys.pne.com.Pmech_x_om_rpm = [0.,700.,850.,1000.,1250.,1500.,1800.,2000.,2200.,2550.,3000.,3200.,3400.,3500.];

sMP.phys.pne.com.Pmech_y_dp_bar = [0.,8.,10.,12.5,15.];

sMP.phys.pne.com.Qn_Map_l_min = [0.,35.,43.,51.,68.,85.,109.,128.,144.,178.,221.,250.,275.,287.;
0.,35.,43.,51.,68.,85.,109.,128.,144.,178.,221.,250.,275.,287.;
0.,174.,215.,255.,318.,383.,442.,513.,564.,631.,687.,767.,805.,828.;
0.,174.,215.,255.,318.,383.,442.,513.,564.,631.,687.,767.,805.,828.;
0.,171.,211.,252.,319.,378.,440.,505.,559.,627.,688.,758.,802.,821.;
0.,167.,206.,248.,312.,375.,438.,502.,555.,607.,681.,748.,791.,810.;
0.,162.,202.,241.,308.,369.,433.,495.,549.,597.,677.,742.,783.,800.];

sMP.phys.pne.com.Qn_x_om_rpm = [0.,700.,850.,1000.,1250.,1500.,1800.,2000.,2200.,2550.,3000.,3200.,3400.,3500.];

sMP.phys.pne.com.Qn_y_dp_bar = [0.,2.5,2.7000000000000002,8.,10.,12.5,15.];

sMP.phys.pne.com.Tout_Map_degC = [90.,90.,91.,91.299999999999997,92.099999999999994,93.799999999999997,95.299999999999997,96.,96.599999999999994,99.,101.59999999999999,103.8,106.,107.;
90.,105.2,109.40000000000001,113.40000000000001,118.7,124.8,132.,137.80000000000001,141.80000000000001,149.,160.19999999999999,165.30000000000001,168.19999999999999,169.40000000000001;
90.,107.8,110.90000000000001,115.2,120.7,127.7,136.,141.90000000000001,145.69999999999999,154.59999999999999,164.30000000000001,169.40000000000001,175.40000000000001,177.5;
90.,108.7,112.09999999999999,117.09999999999999,123.,131.30000000000001,139.69999999999999,145.59999999999999,150.5,157.19999999999999,170.90000000000001,177.09999999999999,181.30000000000001,183.30000000000001;
90.,109.2,112.8,117.90000000000001,124.3,133.59999999999999,142.80000000000001,148.59999999999999,154.19999999999999,161.09999999999999,174.19999999999999,180.69999999999999,185.40000000000001,187.69999999999999];

sMP.phys.pne.com.Tout_x_om_rpm = [0.,700.,850.,1000.,1250.,1500.,1800.,2000.,2200.,2550.,3000.,3200.,3400.,3500.];

sMP.phys.pne.com.Tout_y_dp_bar = [0.,8.,10.,12.5,15.];

sMP.phys.pne.veh.axleLoadTractor_kg = [5000.,5000.,0.,0.];

sMP.phys.pne.veh.axleLoadTrailer_kg = [5000.,0.,0.];

sMP.phys.pne.veh.AxleSpringType = [0.,0.,0.,0.];

sMP.phys.pne.veh.pAppCyl_Tractor = [0.29999999999999999,0.29999999999999999,0.,0.];

sMP.phys.pne.veh.pAppCyl_Trailer = [0.,0.,0.];

sMP.phys.pne.veh.rdynTractor = [500.,500.,1000.,1000.];

sMP.phys.pne.veh.rdynTrailer = [1000.,1000.,1000.];

sMP.phys.pne.veh.axleLoadTrailer02_kg = [0.,0.,0.,0.,0.,0.];

sMP.phys.pne.veh.pAppCyl_Trailer02 = [0.,0.,0.,0.,0.,0.];

sMP.phys.pne.veh.rdynTrailer02 = [1000.,1000.,1000.,1000.,1000.,1000.];

sMP.phys.pne.initialTemperatures.initial_wear = [0.,0.,0.,0.,0.,0.,0.];

sMP.phys.pne.initialTemperatures.T_initial_brakes = [25.,25.,25.,25.,25.,25.,25.];

